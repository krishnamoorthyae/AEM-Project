function processPolicyDetailSuccess(detailResponse){

    //storing items for dynamic doc handlebars
    sessionStorage.setItem("partnerId", detailResponse?. partnerId || "");
    sessionStorage.setItem("isoCountry", detailResponse?.detailResponse?. policyDetail?.travelers?.[0]?.addresses?.[0]?.isoCountry || "");
    sessionStorage.setItem("isoState", detailResponse?.detailResponse?.policyDetail?.travelers?.[0]?.addresses?.[0]?.isoStateOrProvince || "");
    sessionStorage.setItem("language", detailResponse?.language);
    sessionStorage.setItem("productCode",detailResponse?.detailResponse?.policyDetail?.productDetail?.productCode || "");
    sessionStorage.setItem("planCode", detailResponse?.detailResponse?.policyDetail?.productDetail?.planCode || "");
  
    //Find and add booking date 
    let contents = (detailResponse?.policyContent) || [];
    if (contents && contents.length > 0) {
        let bookingDate = $.grep(contents, function (content, i) {
            return (content.name === "InitialTripDepositDate");
        });
        if (bookingDate.length > 0) {
            sessionStorage["tripDepositDate"] = formatDateToDateFormat(bookingDate[0]?.value, "MM/DD/YYYY") || "";
        }
    }

     //Add trip details 
     sessionStorage["tripDepartureDate"] = formatDateToDateFormat(detailResponse?.departureDate, "YYYY-MM-DD") || "";
     sessionStorage["tripReturnDate"] = formatDateToDateFormat(detailResponse?.returnDate, "YYYY-MM-DD") || "";
     let locationVals = (detailResponse?.destinations?.locationValue) || [];
     if (locationVals && locationVals.length > 0) {
         let country = $.grep(locationVals, function (val, i) {
             return (val.type === "ISOCountry");
         });
         sessionStorage["destinationCountry_val"] = country.code;
     }
    
    let agencyPhone = $.grep(detailResponse?.detailResponse?.policyDetail?.accountDetail.accountContactDetails, function (contactDetail, i) {
        return (contactDetail.type === "AgencyPhone");
    });
    let callLine = $.grep(detailResponse?.detailResponse?.policyDetail?.accountDetail.accountContactDetails, function (contactDetail, i) {
        return (contactDetail.type === "CallLine");
    });
    sessionStorage.setItem("agencyPhone", agencyPhone?.[0]?.value);
    sessionStorage.setItem("callLine", callLine?.[0]?.value);
    sessionStorage.setItem("agencyPhoneFormatted", agencyPhone?.[0]?.value?.replace(/[+-]/g, ""));
    sessionStorage.setItem("callLineFormatted", callLine?.[0]?.value?.replace(/[+-]/g, ""));

    let replicationList = sessionStorage.getItem("replication-containers-list");
    if (replicationList?.includes("searchPoliciesLoop")) {
        sessionStorage.setItem("replication-containers-list", "searchPoliciesLoop");
        let exclude = ["uuid",
            "replication-containers-list",
            "searchPoliciesLoop",
            "lastName",
            "policyNumber",
            "policyIsSelected",
            "privacypolicy_agreement",
            "policySearch"];
        clearStorageOnPolicySearch(exclude);
    }
}

function processPolicyDetailResponse (response){
    response.detailResponse.policyDetail.productDetail.standardDetails = response?.detailResponse?.policyDetail?.productDetail?.benefitDetails?.filter(function(benefitDetail){
        return benefitDetail.packageType === "Standard" && benefitDetail.useForFulfillment;
    });
    response.detailResponse.policyDetail.productDetail.optionalDetails = response?.detailResponse?.policyDetail?.productDetail?.benefitDetails?.filter(function(benefitDetail){
        return benefitDetail.packageType !== "Standard" && benefitDetail.useForFulfillment;
    });
    sessionStorage.setItem( "policyDetail", JSON.stringify( response ) );
    let modifyBenefitSymbol = JSON.parse(sessionStorage.getItem("policyDetail")),
	    currencySymbol = $( "#currencySymbol" ).attr( "value" ) || "$";

    modifyBenefitSymbol.detailResponse.policyDetail.productDetail.standardDetails = processPayoutLimit(modifyBenefitSymbol?.detailResponse?.policyDetail?.productDetail?.standardDetails);
    modifyBenefitSymbol.detailResponse.policyDetail.productDetail.optionalDetails = processPayoutLimit(modifyBenefitSymbol?.detailResponse?.policyDetail?.productDetail?.optionalDetails);
    
    updateDecimalFields(modifyBenefitSymbol);

    modifyBenefitSymbol?.detailResponse?.policyDetail?.productDetail?.standardDetails?.forEach(function (benefit){
        benefit?.amounts?.forEach(function (amount){
            updateStandardAndOptional(amount.amountValues);
        });
    });
    modifyBenefitSymbol?.detailResponse?.policyDetail?.productDetail?.optionalDetails?.forEach(function (benefit){
        benefit?.amounts?.forEach(function (amount){
            updateStandardAndOptional(amount.amountValues);
        });
    });

    function updateStandardAndOptional(amountValues){
        amountValues.forEach(function (item){
            if (item.type === 'BenefitLimit' || item.type === 'Payout Limit') {
                if(!isNaN(item.value)){
                    item.value = currencySymbol + formatCurrencyAmount("unused-0--,", Number(item.value));
                }
            }
        });
    }
    
    function processPayoutLimit(benefitDetails) {
        return (benefitDetails || []).map(benefit => {
            let hasPayoutLimit = benefit?.amounts?.some(amount => amount?.amountValues?.some(item => item?.type === 'PayoutLimit' && Number(item?.value) == 0) && benefit?.payoutPerRuleDesc === '');
            if (hasPayoutLimit) {
                benefit?.amounts?.forEach(amount => {
                    amount.amountValues = amount?.amountValues?.filter(item => item?.type !== 'PayoutLimit');
                });
                delete benefit?.payoutPerRuleDesc;
            }
            else {
                benefit?.amounts?.forEach(amount => {
                    amount?.amountValues?.forEach(item => {
                        if (item?.type === 'PayoutLimit' && Number(item?.value) != 0) {
                            item.type = 'Payout Limit';
                        }
                    });
                });
            }
            return benefit;
        });
    }
	
    let structuredData = {};

    modifyBenefitSymbol?.detailResponse?.policyDetail?.productDetail?.optionalDetails?.forEach(function(item) {
        if(item.hasOwnProperty('packageDesc')) {
           if(!structuredData[item?.packageDesc]) {
            structuredData[item?.packageDesc] = [];
           }

           structuredData[item?.packageDesc].push(item);
    }
    });

    let groupedData = [];

    for (let packageDesc in structuredData) {
        groupedData.push({"packageDescTitle": packageDesc});
        groupedData = groupedData.concat(structuredData[packageDesc]);
    }

    modifyBenefitSymbol.detailResponse.policyDetail.productDetail.optionalDetails = groupedData;
	
    modifyBenefitSymbol?.detailResponse?.policyDetail?.travelers.forEach(function (traveler) {
        if (traveler?.medicalScore) {
            let medicalExclusionVal = getMedicalExclusion(parseFloat(traveler?.medicalScore));
            traveler.medicalExclusion = medicalExclusionVal;
        }
    });

    sessionStorage.setItem('policyDetail', JSON.stringify(modifyBenefitSymbol));
    let parsePolicy = JSON.parse(sessionStorage.getItem("policyDetail"));
    let parsePolicyDetail = parsePolicy?.detailResponse?.policyDetail;

    sessionStorage.setItem("originalDestination", parsePolicyDetail?.destinations?.[0]?.locationValue?.[0]?.value || '');
    let primaryTravelerFirstName = parsePolicyDetail?.travelers?.[0]?.firstName || "";
    let primaryTravelerLastName = parsePolicyDetail?.travelers?.[0]?.lastName || "";
    sessionStorage.setItem("primaryTravelerName", primaryTravelerFirstName + " " + primaryTravelerLastName);
    sessionStorage.setItem("primaryTravelerTripCost", parsePolicyDetail?.travelers?.[0]?.travelerTripPrice?.value || "");
    sessionStorage.setItem("primaryTravelerAddress3", parsePolicyDetail?.travelers?.[0]?.addresses?.[0]?.street3 || "");

    parsePolicyDetail?.productDetail?.amounts?.forEach(amount => {
        let totalPremium = amount?.amountValues?.find(value => value?.type === "TotalPremium");
        let basePremium = amount?.amountValues?.find(value => value?.type === "BasePremium");
        let assistanceService = amount?.amountValues?.find(value => value?.type === "PremiumFees");

        if (totalPremium) {
            totalPremium = totalPremium?.value;
            sessionStorage.setItem("totalPremium", totalPremium);
        }
        if (basePremium) {
            basePremium = basePremium?.value;
            sessionStorage.setItem("basePremium", basePremium);
        }
        if (assistanceService) {
            assistanceService = assistanceService?.value;
            sessionStorage.setItem("assistanceService", assistanceService);
        }
    });	
	 let policyDates = modifyBenefitSymbol?.detailResponse?.policyDetail,
				tripDepartureDate = moment(policyDates?.departureDate, 'YYYY-MM-DD'),	 
				tripReturnDate = moment(policyDates?.returnDate, 'YYYY-MM-DD'),
				daysDifference = moment.duration(tripReturnDate - tripDepartureDate).asDays() + 1;
			sessionStorage.setItem("tripDuration", daysDifference);

    let policyTravelerAddress = parsePolicyDetail?.travelers?.[0]?.addresses;
        if (policyTravelerAddress.length){          
            let residencyAddressIndex = policyTravelerAddress?.findIndex(b => b?.types.includes('residency')),
                billingAddressIndex   = policyTravelerAddress?.findIndex(b => b?.types.includes('billing')),

                residencyAddress = residencyAddressIndex != -1 ? policyTravelerAddress[residencyAddressIndex]  
                                     :policyTravelerAddress[billingAddressIndex] ;

            sessionStorage.setItem("policyPrimaryTravelerAddress1", residencyAddress?.street1 || '');
            sessionStorage.setItem("policyPrimaryTravelerCity", residencyAddress?.city || '');
            sessionStorage.setItem("policyPrimaryTravelerState", residencyAddress?.isoStateOrProvince || '');
            sessionStorage.setItem("policyPrimaryTravelerPostalcode", residencyAddress?.postalCode || '');
        }
}

function clearStorageOnPolicySearch(exclude) {
    for (var i = 0; i < sessionStorage.length; i++) {
        let key = sessionStorage.key(i);
        let remove = true;
        for (var j = 0; j < exclude.length; j++) {
            if (key.indexOf(exclude[j]) !== -1) {
                remove = false;
            }
        }

        if (remove) {
            sessionStorage.removeItem(key);
        }
    }
}

function getMedicalExclusion(medicalScore) {
    if (medicalScore == 0) {
        return "GE";
    }
    else if (medicalScore >= 10 && medicalScore <= 20) {
        return "ME#1";
    }
    else if (medicalScore >= 30 && medicalScore <= 40) {
        return "ME#2";
    }
    else if (medicalScore >= 50 && medicalScore <= 90) {
        return "ME#2";
    }
    else if (medicalScore >= 100) {
        return "ME#3";
    }
}