(function ($) {
    const   URL = document.location.pathname,
        CFFW = ".coral-Form-fieldwrapper",
        MASTER = "master",
        CFM_EDITOR_SEL = ".content-fragment-editor",
        CMFI = "._coral-Multifield-item",
        CMF_SELECTOR = "[data-granite-coral-multifield-name$='CMF']",
        CMF_SELECTOR_SINGLE = "input[name$='CMF'][data-content-type='text/plain']",
        FIRST_PANEL = '.cfm-Form coral-panelstack coral-panel:first',
        CMF_TEMPLATE = "Template";

    let initialized = false;

    if( !isCFEditor() ){
        return;
    }

    init();

    function init(){
        if(initialized){
            return;
        }

        initialized = true;

        setCustomListeners();

        window.Dam.CFM.Core.registerReadyHandler(() => {
            extendRequestSave();

            const $cmfMultis = $(FIRST_PANEL).find(CMF_SELECTOR),
                $cmfSingles = $(FIRST_PANEL).find(CMF_SELECTOR_SINGLE).closest( CFFW );
            addCMFMultiFieldListener($cmfMultis, $cmfSingles);

            setCMFMutationsObserver();

            Dam.CFM.editor.UI.addBeforeApplyHandler( () => {
                Dam.CFM.EditSession.notifyActiveSession();
                Dam.CFM.EditSession.setDirty(true);
            });
        });
    }

    function setCMFMutationsObserver() {
        let MutationObserver = window.MutationObserver || window.WebKitMutationObserver || window.MozMutationObserver;
        let body             = document.body;
        let observer         = new MutationObserver(function(mutations) {
            mutations.forEach(function(mutation) {
                // needed for IE
                let nodesArray = [].slice.call(mutation.addedNodes);
                if (nodesArray.length > 0) {
                    nodesArray.forEach(function(addedNode) {
                        if( $(FIRST_PANEL)[0]?.contains( addedNode ) ) {
                            if (addedNode.classList?.contains("cfm-multifield-data")) {
                                const $cmfMultis = $(addedNode).find(CMF_SELECTOR),
                                    $cmfSingles = $(addedNode).find(CMF_SELECTOR_SINGLE).closest(CFFW);

                                if ($cmfMultis.length || $cmfSingles.length) {
                                    addCMFMultiFieldListener($cmfMultis, $cmfSingles);
                                }
                            }
                        }
                    });
                }
            });
        });

        observer.observe(body, {
            subtree: true,
            childList: true,
            characterData: true
        });
    }

    function setCustomListeners() {
        $(document).on("click", ".cfm-multifield-chevron.opened", function() {
            $(this).addClass("closed");
            $(this).removeClass("opened");
            let text = "";
            let itemCount = 0;
            $(this).parent().find(".coral-Form-fieldwrapper").each( (idx, item) => {
                if( itemCount < 1 && $(item).is(":visible") ) {
                    let label = $(item).find(".label-wrapper").find("label").text();
                    let value = $(item).find(".label-wrapper").next().find("coral-button-label").text() || $(item).find(".label-wrapper").next().val();
                    if( text ) {
                        text = text + " | ";
                    }
                    text += '<span class="key">' + label + '</span> = <span class="value">' + value + '</span>';
                    itemCount++;
                }
            })
            let header = '<h4 class="cfm-multifield-header">' + text + '</h4>';
            $(this).append( header );
            $(this).parent().find(".cfm-multifield-data").addClass("hide");
        });

        $(document).on("click", ".cfm-multifield-chevron.closed", function() {
            $(this).removeClass("closed");
            $(this).addClass("opened");
            $(this).parent().find(".cfm-multifield-data").removeClass("hide")
            $(this).find(".cfm-multifield-header").remove();
        });
    }

    function addCMFMultiFieldListener($cmfMultis, $cmfSingles){
        createMultiFieldTemplates($cmfMultis, $cmfSingles);

        _.each($cmfMultis, (cmfMulti) => {
            Coral.commons.ready(cmfMulti, splitKeyValueJSONIntoFields);
        })

        _.each($cmfSingles, (cmfSingle) => {
            Coral.commons.ready(cmfSingle, splitKeyValueJSONIntoFieldsSingleContainer);
        })
    }

    function splitKeyValueJSONIntoFieldsSingleContainer(cmfMFField){
        const $cmfMFField = $(cmfMFField),
            cmfMFName = $cmfMFField.find("> input").attr("name"),
            input = $cmfMFField.find("[name=" + cmfMFName + "]"),
            placeholder = input.attr("placeholder") || "",
            jsonData = JSON.parse(input.val() || '{}');

        let html = '<div data-sly-single-container="' + cmfMFName + '" data-sly-template-parent="' + placeholder + '">' + getParkedMFHtml(input) + '</div>';
        if( placeholder && !html.includes("data-sly-template-parent") ) {
            html = '<div data-sly-template-parent="' + placeholder + '">' + html + '</div>';
        }
        $cmfMFField.html(html);

        fillMultiFieldItem( cmfMFField, jsonData )
    }

    function splitKeyValueJSONIntoFields(cmfMFField){
        const $cmfMFField = $(cmfMFField),
            cmfMFName = $cmfMFField.attr("data-granite-coral-multifield-name");

        _.each(cmfMFField.items.getAll(), function(item) {
            const $content = $(item).find("> coral-multifield-item-content"),
                input = $content.find("input"),
                placeholder = input.attr("placeholder") || "";
            let jsonData = $content.find("[name=" + cmfMFName + "]").val();

            if(!jsonData){
                return;
            }

            jsonData = JSON.parse(jsonData);

            let html = '<div class="cfm-multifield-chevron opened"></div><div class="cfm-multifield-data">' + getParkedMFHtml($cmfMFField) + '</div>';
            if( placeholder && !html.includes("data-sly-template-parent") ) {
                html = '<div data-sly-template-parent="' + placeholder + '">' + html + '</div>';
            }
            $content.html(html);

            fillMultiFieldItem(item, jsonData);

            $content.find(".opened").each( (idx, elem) => {
                $(elem).trigger("click");
            })
        });
    }

    function fillMultiFieldItem(mfItem, jsonData){
        _.each(jsonData, function(fValue, fKey){
            const field = mfItem.querySelector("[name='" + fKey + "']");

            if(field == null){
                return;
            }

            if(field.tagName === 'CORAL-DATEPICKER'){
                field.valueAsDate = new Date(fValue);
            }
            else if ( $(field).find("input").attr("type") === "checkbox" ) {
                if( fValue ) {
                    $(field).find("input").attr("checked", true);
                }
            }
            else {
                field.value = fValue;

            }
        });
    }

    function createMultiFieldTemplates($cmfMultis, $cmfSingles){
        _.each($cmfSingles, (cmfSingle) => {
            let $cmfSingle = $(cmfSingle),
                input = $cmfSingle.find("> input"),
                placeholder = input.attr("placeholder") || "";

            $cmfSingle.find("> template").remove();

            // let template = '<template>' + getParkedMFHtml(input) + '</template>';
            // if( placeholder && !template.includes("data-sly-template-parent") ) {
            //     template = template.replace('<template>', '<template><div data-sly-template-parent="' + placeholder + '">');
            //     template = template.replace('</template>', '</div></template>');
            // }

            hideTemplateTab($cmfSingle);

            // $cmfSingle.append(template);
        })

        _.each($cmfMultis, (cmfMulti) => {
            let $cmfMulti = $(cmfMulti),
                cmfMFName = $cmfMulti.attr("data-granite-coral-multifield-name"),
                input = $cmfMulti.find("[name='" + cmfMFName + "']"),
                placeholder = input.attr("placeholder") || "";

            $cmfMulti.find("> template").remove();

            let template = '<template><div class="cfm-multifield-chevron opened"></div><div class="cfm-multifield-data">' + getParkedMFHtml($cmfMulti) + '</div></template>';
            if( placeholder && !template.includes("data-sly-template-parent") ) {
                template = template.replace('<template>', '<template><div data-sly-template-parent="' + placeholder + '">');
                template = template.replace('</template>', '</div></template>');
            }

            hideTemplateTab($cmfMulti);

            $cmfMulti.append(template);
        })
    }

    function getParkedMFHtml($cmfMulti){
        let $tabView = $cmfMulti.closest("coral-tabview");
        return $($tabView.find("coral-panel").get(getTemplateIndex($cmfMulti))).find("coral-panel-content").html();
    }

    function getTemplateIndex($cmfMulti){
        let cmfMultiName = $cmfMulti.attr("data-granite-coral-multifield-name"),
            cmfMultiTemplateName =  cmfMultiName + CMF_TEMPLATE,
            cmfSingleName = $cmfMulti.attr("name"),
            cmfSingleTemplateName =  cmfSingleName + CMF_TEMPLATE,
            $tabView = $cmfMulti.closest("coral-tabview"),
            $tabLabels = $tabView.find('coral-tab-label'),
            templateIndex;

        _.each($tabLabels, (tabLabel, index) => {
            if($(tabLabel).html().trim() === cmfMultiTemplateName && cmfMultiTemplateName){
                templateIndex = index;
            }
            else if($(tabLabel).html().trim() === cmfSingleTemplateName && cmfSingleTemplateName){
                templateIndex = index;
            }
        })

        return templateIndex;
    }

    function hideTemplateTab($cmfMulti){
        let $tabView = $cmfMulti.closest("coral-tabview");
        $($tabView.find("coral-tab").get(getTemplateIndex($cmfMulti))).hide();
    }

    function getCompositeMultiFieldsData(){
        const $cmfMultis = $(FIRST_PANEL).find(CMF_SELECTOR),
            allData = {};

        _.each($cmfMultis, (cmfMulti) => {
            let $cmfMulti = $(cmfMulti),
                kevValueData = [],
                cmfName = $cmfMulti.attr("data-granite-coral-multifield-name");

            _.each(cmfMulti.items.getAll(), function(item) {
                const $fields = $(item.content).find("[name]"),
                    cmfData = {};

                _.each($fields, function(field){
                    if(canBeSkipped(field, cmfName)){
                        return;
                    }

                    let value = field.value;
                    if( $(field).attr("type") === "checkbox" ) {
                        value = $(field).is(":checked") ? value : "";
                    }
                    cmfData[field.getAttribute("name")] =  value;
                });

                kevValueData.push(JSON.stringify(cmfData));
            });

            allData[cmfName] = kevValueData;
        })

        return allData ;
    }

    function getCompositeSingleFieldsData(){
        const $cmfSingle = $("[data-sly-single-container]"),
            allData = {};

        _.each($cmfSingle, (cmfSingle) => {
            let $cmfSingle = $(cmfSingle),
                cmfName = "",
                kevValueData = [];

            if( !$(cmfSingle).closest( CMFI ).length ) {
                cmfName = $cmfSingle.attr("data-sly-single-container");

                const $fields = $(cmfSingle).find("[name]"),
                    cmfData = {};

                _.each($fields, function(field){
                    if(canBeSkipped(field, cmfName)){
                        return;
                    }

                    let value = field.value;
                    if( $(field).attr("type") === "checkbox" ) {
                        value = $(field).is(":checked") ? value : "";
                    }
                    cmfData[field.getAttribute("name")] =  value;
                });

                kevValueData.push(JSON.stringify(cmfData));

                allData[cmfName + "@ContentType"] = "text/plain"
                allData[cmfName] = kevValueData;
            }
        })

        return allData ;
    }

    function canBeSkipped(field, name){
        return (($(field).attr("type") === "hidden") || !field.value || $(field).attr("name") === name);
    }

    function extendRequestSave(){
        const CFM = window.Dam.CFM,
            orignFn = CFM.editor.Page.requestSave;

        CFM.editor.Page.requestSave = requestSave;

        function requestSave(callback, options) {
            orignFn.call(this, callback, options);

            const kvData = getCompositeMultiFieldsData();
            const singleData = getCompositeSingleFieldsData();

            const url = CFM.EditSession.fragment.urlBase + ".cfm.content.json",
                variation = getVariation(),
                createNewVersion = (options && !!options.newVersion) || false;

            if(!_.isEmpty(kvData)){
                let data = {
                    ":type": "multiple",
                    ":newVersion": createNewVersion,
                    "_charset_": "utf-8"
                };

                if(variation !== MASTER){
                    data[":variation"] = variation;
                }

                const request = {
                    url: url,
                    method: "post",
                    dataType: "json",
                    data: _.merge(data, kvData),
                    cache: false
                };

                CFM.RequestManager.schedule({
                    request: request,
                    type: CFM.RequestManager.REQ_BLOCKING,
                    condition: CFM.RequestManager.COND_EDITSESSION,
                    ui: (options && options.ui)
                })
            }
            if(!_.isEmpty(singleData)){
                let data = {
                    ":type": "multiple",
                    ":newVersion": createNewVersion,
                    "_charset_": "utf-8"
                };

                if(variation !== MASTER){
                    data[":variation"] = variation;
                }

                const request = {
                    url: url,
                    method: "post",
                    dataType: "json",
                    data: _.merge(data, singleData),
                    cache: false
                };

                CFM.RequestManager.schedule({
                    request: request,
                    type: CFM.RequestManager.REQ_BLOCKING,
                    condition: CFM.RequestManager.COND_EDITSESSION,
                    ui: (options && options.ui)
                })
            }

        }
    }

    function getVariation(){
        var variation = $(CFM_EDITOR_SEL).data('variation');

        variation = variation || "master";

        return variation;
    }

    function isCFEditor(){
        return ((URL.indexOf("/editor.html") == 0)
            ||  (URL.indexOf("/mnt/overlay/dam/cfm/admin/content/v2/fragment-editor.html") == 0) )
    }
}(jQuery));
