(function ($) {
    const URL = document.location.pathname,
        CFFW = ".coral-Form-fieldwrapper",
        CFS = ".coral-Form-field._coral-Dropdown",
        CFS_RADIO = ".coral-Form-field.coral-RadioGroup",
        MASTER = "master",
        CFM_EDITOR_SEL = ".content-fragment-editor",
        CMF_SELECTOR = "[type=text][data-type=string][data-element$='GenericList']",
        CMF_ITEM = "._coral-Multifield-item",
        FIRST_PANEL = '.cfm-Form coral-panelstack coral-panel:first',
        CMF_TEMPLATE = "Dropdown",
        CMF_RADIO_TEMPLATE = "RadioGroup";

    let initialized = false;

    if( !isCFEditor() ){
        return;
    }

    init();

    function init(){
        if(initialized){
            return;
        }

        initialized = true;

        window.Dam.CFM.Core.registerReadyHandler(() => {
            extendGenericListRequestSave();

            const $cmfMultis = $(FIRST_PANEL).find(CMF_SELECTOR);
            addCMFMultiFieldListener($cmfMultis);

            setCFGenericListMutationsObserver();

            Dam.CFM.editor.UI.addBeforeApplyHandler( () => {
                Dam.CFM.EditSession.notifyActiveSession();
                Dam.CFM.EditSession.setDirty(true);
            });
        });
    }

    function addCMFMultiFieldListener($cmfMultis){
        hideTemplateInput($cmfMultis)

        _.each($cmfMultis, (cmfMulti) => {
            Coral.commons.ready(cmfMulti, getGenericListJson);
        })
    }

    function setCFGenericListMutationsObserver() {
        let MutationObserver = window.MutationObserver || window.WebKitMutationObserver || window.MozMutationObserver;
        let body             = document.body;
        let observer         = new MutationObserver(function(mutations) {
            mutations.forEach(function(mutation) {
                // needed for IE
                let nodesArray = [].slice.call(mutation.addedNodes);
                if (nodesArray.length > 0) {
                    nodesArray.forEach(function(addedNode) {
                        if( $(FIRST_PANEL)[0]?.contains( addedNode ) ) {
                            const $cmfMultis = $(addedNode).find(CMF_SELECTOR);

                            if( $cmfMultis.length ) {
                                addCMFMultiFieldListener($cmfMultis);
                            }
                        }
                    });
                }
            });
        });

        observer.observe(body, {
            subtree: true,
            childList: true,
            characterData: true
        });
    }

    function getGenericListJson(cmfMFField){
        const $cmfMFField = $(cmfMFField),
            cmfMFName = $cmfMFField.attr("name"),
            cmfPlaceholder = $cmfMFField.attr("placeholder");

        $.ajax({
            url: '/bin/foundation/generic-list',
            type: 'GET',
            data: {
                "list": cmfPlaceholder
            },
            success: function (resp) {
                addCoralSelectItems( resp, $cmfMFField, cmfMFName );
                addCoralRadioGroupItems( resp, $cmfMFField, cmfMFName );
            },
            error: function () {}
        });
    }

    function addCoralSelectItems( resp, $cmfMFField, cmfMFName ) {
        let coralSelect = $cmfMFField.closest( CMF_ITEM ).find(CFS + "[name='" + cmfMFName + CMF_TEMPLATE + "']")[0];

        if( !coralSelect ) {
            coralSelect = $(FIRST_PANEL).find(CFS + "[name='" + cmfMFName + CMF_TEMPLATE + "']")[0];
        }

        if( coralSelect ) {
            //Clear any existing options
            coralSelect.items.clear();

            //adding an empty option
            const emptyItem = new Coral.Select.Item();
            coralSelect.items.add( emptyItem );

            //populate the Coral Select with options
            resp.forEach( option => {
                const selectItem = new Coral.Select.Item();
                selectItem.value = option.value;
                selectItem.content.textContent = option.title
                coralSelect.items.add( selectItem );
            })
            coralSelect.value = $cmfMFField.val()
            $(coralSelect).on("change", function() {
                const val = $(this).val();
                let parent = $(this).closest( CMF_ITEM );
                if( !parent.length ) {
                    parent = $(this).closest( "coral-panel" );
                }

                const name = $(this).attr("name").split( CMF_TEMPLATE )[0] || "gibberish";

                parent.find(`[name="${name}"]`).val( val )
            })
            $(coralSelect).find("select").trigger("change")
        }
    }

    function addCoralRadioGroupItems( resp, $cmfMFField, cmfMFName  ) {
        let coralRadioGroup = $cmfMFField.closest( CMF_ITEM ).find(CFS_RADIO + "[data-element='" + cmfMFName + CMF_RADIO_TEMPLATE + "']")[0];

        if( !coralRadioGroup ) {
            coralRadioGroup = $(FIRST_PANEL).find(CFS_RADIO + "[name='" + cmfMFName + CMF_RADIO_TEMPLATE + "']")[0];
        }

        if( coralRadioGroup ) {
            //Clear any existing options
            while( coralRadioGroup.firstChild ) {
                coralRadioGroup.removeChild( coralRadioGroup.firstChild );
            }

            //populate the Coral Select with options
            resp.forEach( option => {
                const radio = new Coral.Radio();
                radio.value = option.value;
                radio.label.textContent = option.title
                radio.setAttribute("name", cmfMFName + CMF_RADIO_TEMPLATE);

                coralRadioGroup.appendChild( radio );

                $(radio).on("click", function() {
                    const val = $(this).val();
                    let parent = $(this).closest( CMF_ITEM );
                    if( !parent.length ) {
                        parent = $(this).closest( "coral-panel" );
                    }

                    const name = $(this).attr("name").split( CMF_RADIO_TEMPLATE )[0] || "gibberish";

                    parent.find(`[name="${name}"]`).val( val )
                })
                if( $cmfMFField.val() === option.value ) {
                    // radio.setAttribute('checked', true);
                    // manageContainerVisibility(tooltipText, option.value);
                    $(radio).trigger("click")
                }
            })
        }
    }

    function hideTemplateInput($cmfMulti){
        let $fieldWrapper = $cmfMulti.closest(CFFW);
        $($fieldWrapper).hide();
    }

    function isCFEditor(){
        return ((URL.indexOf("/editor.html") == 0)
            ||  (URL.indexOf("/mnt/overlay/dam/cfm/admin/content/v2/fragment-editor.html") == 0) )
    }

    function getVariation(){
        var variation = $(CFM_EDITOR_SEL).data('variation');

        variation = variation || "master";

        return variation;
    }

    function extendGenericListRequestSave(){
        const CFM = window.Dam.CFM,
            orignFn = CFM.editor.Page.requestSave;

        CFM.editor.Page.requestSave = requestSave;

        function requestSave(callback, options) {
            orignFn.call(this, callback, options);

            const kvData = getGenericListValues();

            if(_.isEmpty(kvData)){
                return;
            }

            const url = CFM.EditSession.fragment.urlBase + ".cfm.content.json",
                variation = getVariation(),
                createNewVersion = (options && !!options.newVersion) || false;

            let data = {
                ":type": "multiple",
                ":newVersion": createNewVersion,
                "_charset_": "utf-8"
            };

            if(variation !== MASTER){
                data[":variation"] = variation;
            }

            const request = {
                url: url,
                method: "post",
                dataType: "json",
                data: _.merge(data, kvData),
                cache: false
            };

            CFM.RequestManager.schedule({
                request: request,
                type: CFM.RequestManager.REQ_BLOCKING,
                condition: CFM.RequestManager.COND_EDITSESSION,
                ui: (options && options.ui)
            })
        }
    }

    function getGenericListValues(){
        const $cmfMultis = $(FIRST_PANEL).find(CMF_SELECTOR), allData = {};

        _.each($cmfMultis, (cmfMulti) => {
            let $cmfMulti = $(cmfMulti),
                cmfName = $cmfMulti.attr("name"),
                coralSelect = $(CFS + "[name='" + cmfName + CMF_TEMPLATE + "']")[0],
                coralRadio = $(CFS_RADIO + "[data-element='" + cmfName + CMF_RADIO_TEMPLATE + "']").find("input:is(:checked)")[0];

            allData[cmfName] = coralSelect?.value || coralRadio?.value;
        })

        return allData ;
    }
}(jQuery));