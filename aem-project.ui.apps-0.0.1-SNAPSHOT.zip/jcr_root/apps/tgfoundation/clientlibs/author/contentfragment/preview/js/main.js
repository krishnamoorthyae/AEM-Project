(function ($) {
    const URL = document.location.pathname;

    let initialized = false;

    if( !isCFEditor() ){
        return;
    }

    init();

    function init(){
        if(initialized){
            return;
        }

        initialized = true;

        window.Dam.CFM.Core.registerReadyHandler(() => {
            addPreviewLinkListener();

            Dam.CFM.editor.UI.addBeforeApplyHandler( () => {
                Dam.CFM.EditSession.notifyActiveSession();
                Dam.CFM.EditSession.setDirty(true);
            });
        });
    }

    function addPreviewLinkListener() {
        $(document).on("click", ".preview", function (event) {
            const $target = $(event.currentTarget),
                contentFragmentSelector = $target.parent().find("[data-foundation-validation='cfm.validation.contenttype.contentfragment']"),
                val = contentFragmentSelector.find("input").val();

            console.log("preview click")
            if( contentFragmentSelector.length && val ) {
                window.open("/editor.html" + val, '_blank').focus();
            }
        });
    }


    function isCFEditor(){
        return ((URL.indexOf("/editor.html") == 0)
            ||  (URL.indexOf("/mnt/overlay/dam/cfm/admin/content/v2/fragment-editor.html") == 0) )
    }
}(jQuery));