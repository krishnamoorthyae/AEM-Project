(function ($) {
    const URL = document.location.pathname,
        CFFW = ".coral-Form-fieldwrapper",
        CI = "._coral-Icon[icon='infoCircle']",
        CMFI = "._coral-Multifield-item",
        CPS = "._coral-PanelStack",
        CMFIC = "coral-multifield-item-content",
        FIRST_PANEL = '.cfm-Form coral-panelstack coral-panel:first',
        TOOLTIP_SELECTOR = "._coral-Tooltip-label:contains(ShowHide)";

    let initialized = false;

    if( !isCFEditor() ){
        return;
    }

    init();

    function init(){
        if(initialized){
            return;
        }

        initialized = true;

        window.Dam.CFM.Core.registerReadyHandler(() => {
            addCFShowHideListener();

            Dam.CFM.editor.UI.addBeforeApplyHandler( () => {
                Dam.CFM.EditSession.notifyActiveSession();
                Dam.CFM.EditSession.setDirty(true);
            });
        });
    }

    function addCFShowHideListener(){
        _.each($(FIRST_PANEL).find( TOOLTIP_SELECTOR ), (tooltip) => {
            Coral.commons.ready(tooltip, hideTooltips);
        })

        addCFShowHideMutationsObserver();

        hideShowHideContainers( FIRST_PANEL );
        addShowHideEventHandler( FIRST_PANEL );
    }

    function addShowHideEventHandler( node ) {
        $(node).on("change", "input, ._coral-Dropdown", function() {
            const value = $(this).val(),
                fieldWrapper = $(this).closest( CFFW ),
                tooltip = fieldWrapper.find(TOOLTIP_SELECTOR);

            if( tooltip.length ) {
                manageContainerVisibility( this, tooltip.text().trim(), value);
            }
        })
    }

    function addCFShowHideMutationsObserver() {
        let MutationObserver = window.MutationObserver || window.WebKitMutationObserver || window.MozMutationObserver;
        let body             = document.body;
        let observer         = new MutationObserver(function(mutations) {
            mutations.forEach(function(mutation) {
                // needed for IE
                let nodesArray = [].slice.call(mutation.addedNodes);
                if (nodesArray.length > 0) {
                    nodesArray.forEach(function(addedNode) {
                        if( $(FIRST_PANEL)[0]?.contains( addedNode ) ) {
                            const $tooltip = $(addedNode).find(TOOLTIP_SELECTOR);
                            if ($tooltip.length && $tooltip.text().includes("ShowHide")) {
                                hideTooltips($tooltip[0]);
                                manageContainerVisibility(addedNode, $tooltip.text().trim());
                            }
                            else if ($(addedNode).attr('data-sly-template-parent')?.length) {
                                let allTooltips;

                                if ($(addedNode).closest(CMFI).length) {
                                    allTooltips = $(addedNode).closest(CMFI).find(TOOLTIP_SELECTOR);
                                }
                                else {
                                    allTooltips = $(addedNode).closest(CPS).find(TOOLTIP_SELECTOR);
                                }

                                _.each(allTooltips, (tooltip) => {
                                    hideTooltips(tooltip);
                                    let text = $(tooltip).text().trim(),
                                        name = text.split("ShowHide")[0],
                                        parent = $(tooltip).closest(CFFW);

                                    if( !parent.length ) {
                                        parent = $(tooltip).closest( "coral-panel" );
                                    }

                                    let val = parent.find(`[name="${name}"]`).val() || "";
                                    manageContainerVisibility(addedNode, text, val);
                                })
                            }

                            hideShowHideContainers(addedNode);
                            addShowHideEventHandler(addedNode);
                        }
                    });
                }
            });
        });

        observer.observe(body, {
            subtree: true,
            childList: true,
            characterData: true
        });
    }

    function hideTooltips( tooltip ) {
        let $tooltip = $(tooltip);
        $tooltip.closest( CFFW ).find( CI ).addClass("hide");

        manageContainerVisibility( tooltip, $tooltip.text().trim() );
    }

    function hideShowHideContainers( node ) {
        _.each($(node).find('[data-sly-template-parent][data-sly-template-parent!=""]'), (container) => {
            let $container = $(container);
            $container.closest( CFFW ).hide();
        })
    }

    function manageContainerVisibility( node, text, value) {
        const $node = $(node);
        let searchContainer = $node.closest( CMFI ).find('[data-sly-template-parent^="' + text + '"]'),
            multifieldItemContent = $node.hasClass( "_coral-Multifield-item" ) ? $node :  $node.closest( CMFIC );

        if( !searchContainer.length && multifieldItemContent.length ) {
            searchContainer = multifieldItemContent.find('[data-sly-template-parent^="' + text + '"]');
        }
        else if( !searchContainer.length ) {
            searchContainer = $node.closest( CPS ).find('[data-sly-template-parent^="' + text + '"]');
        }

        _.each(searchContainer, (container) => {
            let $container = $(container);
            $container.closest( CFFW ).hide();

            if( value && $container.attr("data-sly-template-parent").endsWith( value ) ) {
                $container.closest( CFFW ).show();
            }
        })
    }

    function isCFEditor(){
        return ((URL.indexOf("/editor.html") == 0)
            ||  (URL.indexOf("/mnt/overlay/dam/cfm/admin/content/v2/fragment-editor.html") == 0) )
    }
}(jQuery));