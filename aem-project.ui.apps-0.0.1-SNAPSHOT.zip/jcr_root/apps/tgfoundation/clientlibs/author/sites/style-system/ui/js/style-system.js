function createStyleSystemUI( path, clickEvent ) {
	$.ajax({
		type: "GET",
		url: "/bin/style-system/style",
		async: true,
		dataType: "json",
		data: { path },
		success: (response) => {
			response.path = path;
			generateStyleSystem( response, path );
		},
		error: (error) => {
			console.log( "failute" );
			console.log( error )
		}
	})
}

function generateStyleSystem( config, path ) {
	let popover = $("#ContentScrollView #editor-StyleSystem--component");

	popover.attr( "data-path", path );

	let name = $(`.cq-Overlay--component.is-active[data-path="${config.path}"] > .cq-Overlay--component-name`).text() || "Component";
	popover.find("._coral-Dialog-title .editor-StyleSystem-title").text( name );
	console.log("name");

	let form = popover.find("#style-system-toolbar-icon");
	form.find("coral-selectlist").remove();
	form.find("template").remove();
	form.find(".building-block-item").remove();

	styleSystemAddBuildingBlocks( config, popover );
	styleSystemAddShortcuts( config, popover );

	styleSystemPopoverListeners( popover, config );

	styleSystemSetupBuildingBlocks( config, popover );
}

function styleSystemSetupBuildingBlocks( config, popover ) {
	let styles = [];
	if( config.appliedStyles.includes("\n\r") ) {
		styles = config.appliedStyles?.split("\n");
	}
	else {
		styles = config.appliedStyles?.split("\n");
	}

	styles?.forEach( (item, idx) => {
		if( !item ) return;

		let indArr = item.split("{");

		popover.find("[icon=AddCircle]").trigger("click")

		setTimeout(function() {
			let section = popover.find(".style-building-block-section"),
				buildingBlockItem = $(section.find(".building-block-item")[idx] ),
				media = buildingBlockItem.find(".media-query ._coral-Dropdown"),
				target = buildingBlockItem.find(".target ._coral-Dropdown"),
				property = buildingBlockItem.find(".style-property ._coral-Dropdown"),
				value = buildingBlockItem.find(".style-value ._coral-Dropdown");

			let part0 = indArr[0]?.trim(),
				part1 = indArr[1]?.trim(),
				part2 = indArr[2]?.trim();

			if( part0.trim().startsWith("@media") ) {
				media.val( part0 + " {" );
				target.val( part1 + " {" );

				let left = part2?.split(":")[0].trim(),
					right = part2?.split(":")[1].split("}")[0].split(";")[0].trim();

				property.val( left );
				property.trigger("change");
				setTimeout( function() {
					value.val( right );
				}, 10)
			}
			else {
				media.val( "" );
				target.val( part0 + " {" );

				let left = part1?.split(":")[0].trim(),
					right = part1?.split(":")[1].split("}")[0].split(";")[0].trim();

				property.val( left );
				property.trigger("change");
				setTimeout( function() {
					value.val( right );
				}, 10)
			}
		})
	})
}

function styleSystemAddBuildingBlocks( config, popover ) {
	let mediaQuery = new Coral.Select(),
		targets = new Coral.Select(),
		cssProperty = new Coral.Select(),
		cssValues = new Coral.Select(),
		template = $('<div class="building-block-item"></div>'),
		form = popover.find("#style-system-toolbar-icon");

	mediaQuery.setAttribute( "class", "style-media-query" );
	targets.setAttribute( "class", "style-target" );
	cssProperty.setAttribute( "class", "style-property" );
	cssValues.setAttribute( "class", "style-value" );

	config.groups.forEach( group => {
		let media = group.media;
		Object.keys( media ).forEach( item => {
			const selectItem = new Coral.Select.Item();
			selectItem.value = media[item];
			selectItem.content.textContent = item
			selectItem.selected = false;
			mediaQuery.items.add( selectItem );
		})

		let targetConfig = group.target;
		Object.keys( targetConfig ).forEach( item => {
			const selectItem = new Coral.Select.Item();
			selectItem.value = targetConfig[item]?.replaceAll( "{dynamic}", "." + config.id );
			selectItem.content.textContent = item
			selectItem.selected = false;
			targets.items.add( selectItem );
		})

		let options = group.options,
			optionKeys = Object.keys( options );
		optionKeys.sort();
		optionKeys.forEach( item => {
			const selectItem = new Coral.Select.Item();
			selectItem.value = item
			selectItem.content.textContent = item
			selectItem.selected = false;
			cssProperty.items.add( selectItem );
		})

		let styleOptions = options[ optionKeys[0] ];
		styleOptions.sort();
		styleOptions.forEach( item => {
			const selectItem = new Coral.Select.Item();
			selectItem.value = item.value
			selectItem.content.textContent = item.title
			selectItem.selected = false;
			cssValues.items.add( selectItem );
		})
	})

	template.append("<div class='toggle-collapse expanded'><div class='remove-item'>X</div></div>");

	template.append("<div class='building-block-section media-query'></div>");
	template.find(".media-query").append("<label>Media Query</label>")
	template.find(".media-query").append( $(mediaQuery) );

	template.append("<div class='building-block-section target'></div>");
	template.find(".target").append("<label>Target</label>")
	template.find(".target").append( targets );

	template.append("<div class='building-block-section style-property'></div>");
	template.find(".style-property").append("<label>Property</label>")
	template.find(".style-property").append( $(cssProperty) );

	template.append("<div class='building-block-section style-value'></div>");
	template.find(".style-value").append("<label>Value</label>")
	template.find(".style-value").append( $(cssValues) );

	form.append(`<template id="building-block-template">${template[0].outerHTML}</template>`);

	popover.find(".style-building-block-section").remove();

	let section = $('<div class="style-building-block-section"><div class="add-icon"></div></div>'),
		icon = new Coral.Icon();

	icon.icon = "AddCircle";
	icon.size = Coral.Icon.size.SMALL;

	section.find(".add-icon").append( icon );

	form.append( section )
}

function styleSystemAddShortcuts( config, popover ) {
	let shortcutSelect = new Coral.SelectList(),
		form = popover.find("#style-system-toolbar-icon");

	shortcutSelect.multiple = true;

	shortcutSelect.setAttribute( "id", "styleSystemShortcuts" );

	config.shortcuts.forEach( group => {
		let selectGroup = new Coral.SelectList.Group();
		selectGroup.label = group.name;
		selectGroup.setAttribute( "data-path", group.path );

		group.shortcuts.forEach( shortcut => {
			let option = new Coral.SelectList.Item();
			option.value = shortcut.value;
			option.textContent = shortcut.name;
			option.setAttribute( "data-path", shortcut.path);
			option.setAttribute( "data-id", shortcut.title);

			if( config?.selectedShortcuts?.includes( shortcut.title ) ) {
				option.selected = true;
			}

			selectGroup.appendChild( option );
		})

		shortcutSelect.appendChild( selectGroup );
	})

	form.append( shortcutSelect );
}

function styleSystemPopoverListeners ( popover, config ) {
	let form = popover.find("form"),
		path = popover.data("path"),
		component = $($("#ContentFrame")[0].contentWindow.document).find(`cq[data-path="${path}"]`).parent(),
		currentShortcutList = config?.selectedShortcuts,
		shortcuts = [];

	popover.addClass( "is-open" );
	positionStyleSystem( popover );

	//opening and closing individual building blocks
	popover.on("click", ".toggle-collapse", function(event) {
		let $target = $(event.target);

		if( $target.hasClass("expanded") ) {
			$target.removeClass("expanded")
			$target.addClass("collapsed")

			$target.parent().find(".building-block-section").hide();
		}
		else if( $target.hasClass("collapsed") ) {
			$target.removeClass("collapsed")
			$target.addClass("expanded")

			$target.parent().find(".building-block-section").show();
		}
	})

	//opening and closing building blocks
	popover.find(".style-building-block-section").on("click", function(event) {
		openCloseAccordionFunctionality( event );
	})

	//opening and closing groups
	popover.find("coral-selectlist-group").on("click", function(event) {
		openCloseAccordionFunctionality( event );
	})

	popover.on("change", ".building-block-item ._coral-Dropdown", function(event) {
		setTimeout( updateStyleSystemLink, 10)
	})

	//adding additional building blocks
	popover.find("[icon=AddCircle]").on("click", function(event) {
		let $target = $(event.target),
			iconParent = $target.parent(),
			section = $target.closest(".style-building-block-section"),
			form = section.closest("form"),
			template = form.find("template");

		iconParent.before( document.importNode(template[0].content, true) );

		setTimeout( updateStyleSystemLink, 10)
	})

	//removing building block
	popover.on("click", ".remove-item", function( event ) {
		let $target = $(event.target);
		$target.closest(".building-block-item").remove();

		setTimeout( updateStyleSystemLink, 10)
	})

	//updating style system values
	popover.on("change", "coral-select.style-property", function(event) {
		let $target = $(event.target),
			parent = $target.closest(".building-block-item"),
			valueSelect = parent.find("coral-select.style-value")[0];

		valueSelect.items.clear();
		config.groups.forEach( group => {
			let styleOptions = group.options[ $target.val() ];
			styleOptions.sort();
			styleOptions.forEach( item => {
				const selectItem = new Coral.Select.Item();
				selectItem.value = item.value
				selectItem.content.textContent = item.title
				selectItem.selected = false;
				valueSelect.items.add( selectItem );
			})
		})
	})

	//updating shortcut selections and adding them to the page for preview
	popover.find("#styleSystemShortcuts coral-selectlist-item" ).on("click", function(event) {
		setTimeout( updateStyleSystemLink, 10)
	});

	//closing the popover and removing added styles
	popover.find('.editor-StyleSystem-action[icon="close"]').on("click", function() {
		shortcuts = [];
		component.find("> link[style-system]").remove();
		popover.removeClass("is-open");
	})

	//submitting the selected styles
	window.styleSystemSubmitted = false;
	popover.find('.editor-StyleSystem-action[icon="check"]').on("click", function() {
		console.log("submitting");
		component.find("> link[style-system]").removeAttr("style-system");
		if( !window.styleSystemSubmitted ) {
			window.styleSystemSubmitted = true;

			let buildingBlocks = "";
			popover.find(".style-building-block-section .building-block-item").each( (idx, elem) => {
				let media = $(elem).find(".media-query ._coral-Dropdown").val(),
					target = $(elem).find(".target ._coral-Dropdown").val(),
					property = $(elem).find(".style-property ._coral-Dropdown").val(),
					value = $(elem).find(".style-value ._coral-Dropdown").val(),
					cssValue = media + " " + target + " " + property + ": " + value + " }";

				if( media !== "" ) {
					cssValue += " }\n\r";
				}
				else {
					cssValue += "\n\r";
				}
				buildingBlocks += cssValue;
			})

			$.ajax({
				type: "POST",
				url: "/bin/style-system/style",
				async: true,
				data: {
					id: config.id,
					path: path,
					shortcuts: JSON.stringify( shortcuts ),
					buildingBlocks: buildingBlocks
				},
				success: (response) => {
				},
				error: (error) => {
					component.find("> link[style-system]").remove();
					alert("something went wrong when saving your style selections")
				}
			})
		}
	})

	function updateStyleSystemLink( ) {
		let removedClasses = [],
			tempAddList = [],
			cssContent = "";
		shortcuts = [];

		popover.find("#styleSystemShortcuts .is-selected").each( (idx, elem) => {
			$elem = $(elem);

			tempAddList.push( $elem.data("id") );

			cssContent += $elem.attr("value") + "\n\r";

			shortcuts.push({
				id: $elem.data("id"),
				value: $elem.attr("value"),
				group: $elem.parent().attr("label")
			})
		})

		currentShortcutList.forEach( shortcut => {
			if( !tempAddList.includes( shortcut ) ) {
				removedClasses.push( shortcut );
			}
		})

		currentShortcutList = JSON.parse( JSON.stringify( tempAddList ) );

		removedClasses.forEach( item => {
			component.removeClass( item );
		})

		currentShortcutList.forEach( item => {
			if( !component.hasClass( item ) ) {
				component.addClass( item );
			}
		})

		popover.find(".style-building-block-section .building-block-item").each( (idx, elem) => {
			let media = $(elem).find(".media-query ._coral-Dropdown").val(),
				target = $(elem).find(".target ._coral-Dropdown").val(),
				property = $(elem).find(".style-property ._coral-Dropdown").val(),
				value = $(elem).find(".style-value ._coral-Dropdown").val(),
				cssValue = media + " " + target + " " + property + ": " + value + " }";

			if( media !== "" ) {
				cssValue += " }\n\r";
			}
			cssContent += cssValue;
		})

		component.find("> link[style-system]").remove();

		let cssBlob = new Blob([cssContent], {type: 'text/css'} ),
			blobURL = URL.createObjectURL( cssBlob );

		component.append( $(`<link style-system href="${blobURL}" rel="stylesheet" />`) );
	}
}

function openCloseAccordionFunctionality( event ) {
	let target = $(event.target);

	if( target.hasClass("is-open") ) {
		target.removeClass("is-open");
	}
	else {
		target.addClass("is-open");
	}
	event.preventDefault();
}

function positionStyleSystem( popover ) {
	let scrollView = $("#Content #ContentScrollView"),
		toolbar = scrollView.find("#EditableToolbar")
	button =  scrollView.find("button[title='Style System']");

	popover[0].style.top = Number( toolbar[0].style.top.split("p")[0] ) + toolbar.height() + 15 + "px"
	popover[0].style.left = (button.offset().left - popover.width() / 2) + "px";
}
