(function ($, ns, channel, window) {
    "use strict";
    var popover;
    var EditorFrame = ns.EditorFrame;
    var ACTION_ICON = "coral-Icon--wand";
    var ACTION_TITLE = "Style System";
    var ACTION_NAME = "StyleSystem";

   /**
    * Represents the MYACTION action (opens a popover relative to the toolbar of the selected editable) that could be performed on the current {@link Granite.author.Editable}
    *
    * @memberOf Granite.author.edit.ToolbarActions
    * @type Granite.author.ui.ToolbarAction
    * @alias MYACTION
    */

    var MyCustomAction = new ns.ui.ToolbarAction ({
        name: ACTION_NAME,
        text: Granite.I18n.get(ACTION_TITLE),
        icon: ACTION_ICON,
        render: function ($el) {
            if (popover) {
                popover.target = $el[0];
            }
            return $el;
        },
        execute: function () {
            // just ensure we don't close the toolbar
            return false;
        },
        condition: function (editable) {
			let styleSystem = $("#ContentScrollView #editor-StyleSystem--component"),
				path = styleSystem.data("path"),
				component = $($("#ContentFrame")[0].contentWindow.document).find(`cq[data-path="${path}"]`).parent();

	        styleSystem.removeClass("is-open");
			component.find("> link[style-system]" ).remove();
            return !!(editable && editable.dom);
        },
        isNonMulti: true
    });

    channel.on('cq-layer-activated', function(event) {
        popover = document.getElementById('editor-styleSystem--component');
        if (event.layer === "Edit") {
            EditorFrame?.editableToolbar?.registerAction(ACTION_NAME, MyCustomAction);

			EditorFrame?.editableToolbar?.dom?.on("click", "button[title='Style System']", function (event) {
				createStyleSystemUI( $(event.currentTarget).attr("data-path"), event );
			})
        }
    });

}(jQuery, Granite.author, jQuery(document), this));

