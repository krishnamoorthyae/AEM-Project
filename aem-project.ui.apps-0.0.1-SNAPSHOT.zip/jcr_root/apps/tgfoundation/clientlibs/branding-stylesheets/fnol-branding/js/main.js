$(function () {
    $("button[name='searchForClaimDocuments']").on("click", function() {
        let claimId = $("input[name='documentSearchClaimId']").val();
        if( claimId ) {
            //Changes uuid on cookie for the active tab
            document.cookie = "uuid=" + sessionStorage.getItem("uuid") + ";path=/";
            $.ajax({
                url: '/bin/claims/document/recovery',
                type: 'POST',
                data: {
                    'data': claimId,
                },
                dataType: "json",
                success: function ( response ) {
                    // redirect to thank you page
                },
                error: function () {
                }
            });
        }
    });
});
