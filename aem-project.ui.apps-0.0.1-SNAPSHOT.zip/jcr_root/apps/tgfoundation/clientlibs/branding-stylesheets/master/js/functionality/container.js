/***********************************************************************
 *                                                                     *
 *  This file converts all .svg images into an <svg> html tag          *
 *  This helps in better scaling and styling of svg files              *
 *                                                                     *
 ***********************************************************************/

//converts any .svg file into an html <svg>
$(document).ready(function() {
    $('.cmp-container').each( (idx, elem) => {
        let styles = $(elem).attr("style")?.split(";"),
            newStyles = "";

        styles?.forEach( value => {
            if(value.includes("background-color") || value.includes("background-image")) {
                newStyles += value + "; "
            }
        })

        if(newStyles) {
            $(elem).attr("style", newStyles);
        }
        else {
            $(elem).removeAttr("style");
        }
    })
})

