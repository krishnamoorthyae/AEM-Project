/***********************************************************************
 *                                                                     *
 *  This file converts all .svg images into an <svg> html tag          *
 *  This helps in better scaling and styling of svg files              *
 *                                                                     *
 ***********************************************************************/

//converts any .svg file into an html <svg>
$(document).ready(function() {
    $(".image .cmp-image .cmp-image__image[src$='.svg']").each(function () {
        let imageCmp = $(this);

        if (imageCmp.parent().children(":first")[0] === imageCmp[0]) {
            if( dataBase ) {
                dataBase.get("SVG", "SVG", "svg_path", 1, imageCmp.attr("src") )
                    .then( response => {
                        if( response?.svg ) {
                            insertSVG( $( response.svg ), imageCmp );
                        }
                        else {
                            getSVG( imageCmp );
                        }
                    })
                    .catch( err => {
                        getSVG( imageCmp );
                    })
            }
            else {
                getSVG(imageCmp);
            }
        }
        else {
            imageCmp.remove();
        }
    });

    function insertSVG( $svg, imageCmp ) {
        imageCmp.parent().find('svg').remove();
        $svg.insertAfter(imageCmp);
        imageCmp.hide();
        $svg.on("click", () => imageCmp.trigger("click") );
    }

    function getSVG(imageCmp) {
        $.get(imageCmp.attr("src"), function (data) {
            let $svg = $(data).find('svg');
            $svg.attr("class", imageCmp.attr("class"));
            $svg.attr("id", imageCmp.attr("id"));
            $svg.attr("data-cmp-sizing", imageCmp.attr("data-cmp-sizing"));
            $svg.removeAttr('xmlns:a');

            insertSVG( $svg, imageCmp );

            if( dataBase ) {
                dataBase.put("SVG", "SVG", 1, {path: imageCmp.attr("src"), item: $svg[0].outerHTML} );
            }
        }, 'xml');

    }
})

