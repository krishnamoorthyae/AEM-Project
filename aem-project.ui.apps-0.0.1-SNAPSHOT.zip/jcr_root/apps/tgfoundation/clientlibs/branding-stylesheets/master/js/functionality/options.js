//be cautious of running/loading this multiple times IF it was to be loaded INSIDE of the form options component!
//feel free to tweak/improve as needed, works but meant as an example idea
function checkInputButtonsStatus( $inputButtons, onReload ){//parse through all input types=radio/checkbox to ensure all corresponding are up-to-date
    $inputButtons.each(function() {
		let fieldName = $(this).attr('name'),
			currentVal = $(this).val(),
			fieldVal = sessionStorage.getItem(fieldName + "_val");
		if(onReload){				
            if (fieldVal === currentVal) {
                this.checked = true;
            }else if(fieldVal && currentVal && fieldVal !== currentVal){
                this.checked = false;
            }
		}
        $(this).parents("label:first").toggleClass('inputIsChecked', this.checked);
        $(this).parents("label:first").toggleClass('inputIsDisabled', this.disabled);
    });
}

$(document).ready(function() {
    let $inputButtons = $('input[type="radio"].cmp-form-options__field.cmp-form-options__field--radio, input[type="checkbox"].cmp-form-options__field.cmp-form-options__field--checkbox');

    setTimeout( function () {
        checkInputButtonsStatus( $inputButtons,true );//init on page load to style any inherited browser history setting checked values or values already set to checked
    }, 100)

    $inputButtons.change(function() {//use onchange instead of onclick event to capture events when checked attribute is set w code
        checkInputButtonsStatus( $inputButtons,false );
    });

    $('input[type="hidden"][name$="Label"]').each( (idx, inp) => {
        let val = $(inp).val() || "";
        val = val?.replaceAll(/(<p[^>]+?>|<p>|<\/p>)/g, "")?.trim();
        $(inp).val( val.trim() );
    });
})
