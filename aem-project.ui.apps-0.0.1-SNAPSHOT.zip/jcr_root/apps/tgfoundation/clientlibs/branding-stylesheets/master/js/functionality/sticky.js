$(document).ready(function() {
    makeSticky();
});

function makeSticky() {
    let prevScrollpos = window.pageYOffset;
    $(window).on("scroll", function () {
        let currentScrollPos = window.pageYOffset;
        if( currentScrollPos < 1 ) {
            //remove sticky
            $('.sticky-header-functionality > .cmp-container').removeClass('sticky-header');
            $('.sticky-header-mobile-functionality > .cmp-container').removeClass('sticky-header-mobile');
            $('.sticky-header-desktop-functionality > .cmp-container').removeClass('sticky-header-desktop');
            $('.sticky-header-functionality').css({'padding-top': 0});
            $('.sticky-header-mobile-functionality').css({'padding-top': 0});
            $('.sticky-header-desktop-functionality').css({'padding-top': 0});

            $('.sticky-header-functionality').find('.sticky-show-hide-on-scroll').removeClass("sticky-show-on-scroll-up");
            $('.sticky-header-functionality').find('.sticky-show-hide-on-scroll').removeClass("sticky-hide-on-scroll-down");
            $('.sticky-header-mobile-functionality').find('.sticky-show-hide-on-scroll').removeClass("sticky-show-on-scroll-up");
            $('.sticky-header-mobile-functionality').find('.sticky-show-hide-on-scroll').removeClass("sticky-hide-on-scroll-down");
            $('.sticky-header-desktop-functionality').find('.sticky-show-hide-on-scroll').removeClass("sticky-show-on-scroll-up");
            $('.sticky-header-desktop-functionality').find('.sticky-show-hide-on-scroll').removeClass("sticky-hide-on-scroll-down");
        }
        else {
            //add sticky
            let globalHeader = $('.sticky-header-functionality'),
                desktopHeader = $('.sticky-header-desktop-functionality'),
                mobileHeader = $('.sticky-header-mobile-functionality');
            globalHeader.css({'padding-top': globalHeader.height() || globalHeader.css("padding-top")});
            globalHeader.find('> .cmp-container').addClass('sticky-header');
            if( window.innerWidth <= 767 ) {
                mobileHeader.css({'padding-top': mobileHeader.height() || mobileHeader.css("padding-top")});
                mobileHeader.find('> .cmp-container').addClass('sticky-header-mobile');
            }
            else {
                desktopHeader.css({'padding-top': desktopHeader.height() || desktopHeader.css("padding-top")});
                desktopHeader.find('> .cmp-container').addClass('sticky-header-desktop');
            }

            let globalSticky = $('.sticky-header'),
                desktopSticky = $('.sticky-header-desktop'),
                mobileSticky = $('.sticky-header-mobile')

            if (prevScrollpos > currentScrollPos) {
                //scrolling up
                //show the header class on scroll up
                globalSticky.find('.sticky-show-hide-on-scroll').addClass("sticky-show-on-scroll-up");
                globalSticky.find('.sticky-show-hide-on-scroll').removeClass("sticky-hide-on-scroll-down");
                desktopSticky.find('.sticky-show-hide-on-scroll').addClass("sticky-show-on-scroll-up");
                desktopSticky.find('.sticky-show-hide-on-scroll').removeClass("sticky-hide-on-scroll-down");
                mobileSticky.find('.sticky-show-hide-on-scroll').addClass("sticky-show-on-scroll-up");
                mobileSticky.find('.sticky-show-hide-on-scroll').removeClass("sticky-hide-on-scroll-down");
            }
            else {
                //scrolling down
                //hide the header class on scroll down
                globalSticky.find('.sticky-show-hide-on-scroll').removeClass("sticky-show-on-scroll-up");
                globalSticky.find('.sticky-show-hide-on-scroll').addClass("sticky-hide-on-scroll-down");
                desktopSticky.find('.sticky-show-hide-on-scroll').removeClass("sticky-show-on-scroll-up");
                desktopSticky.find('.sticky-show-hide-on-scroll').addClass("sticky-hide-on-scroll-down");
                mobileSticky.find('.sticky-show-hide-on-scroll').removeClass("sticky-show-on-scroll-up");
                mobileSticky.find('.sticky-show-hide-on-scroll').addClass("sticky-hide-on-scroll-down");
            }
        }
        prevScrollpos = currentScrollPos;
    })
}
