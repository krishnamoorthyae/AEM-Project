// returns date in YYYY-MM-DD format
function formatDateToYYYYMMDD(inputDate) {
	return moment(moment(inputDate, languageFormatDate())).format("YYYY-MM-DD");
}

function formatAgeToDOB(age) {
	return formatDateToYYYYMMDD(moment().subtract(age, "years").subtract(1, "days"));
}

function updateOffsetTime(inputDate, isStartOfDay) {
	let date = new Date(),
		hours = date.getUTCHours() + 9;
	if (hours >= 24) {
		hours = hours - 24;
	}
	if (hours < 10) {
		hours = "0" + hours;
	}
	let minutes = date.getUTCMinutes();
	if (date.getUTCMinutes() < 10) {
		minutes = "0" + date.getUTCMinutes();
	}
	let seconds = date.getUTCSeconds();
	if (date.getUTCSeconds() < 10) {
		seconds = "0" + date.getUTCSeconds();
	}

	// We will eventually need to do this for all partners, but starting with Qantas for now
	if ( sessionStorage.getItem("sendOffsetForDates") ) {
		let isInputToday = inputDate === moment().format('YYYY-MM-DD'),
			timeOffset = '';

		if (isInputToday) {
			timeOffset = (isStartOfDay) ? moment().add(5, 'minutes').format('THH:mm:ssZ') : "T23:59:59" + moment().format('Z');
		}
		else {
			timeOffset = (isStartOfDay) ? "T00:00:00" : "T23:59:59" + moment().format('Z');
		}

		return inputDate + timeOffset;
	}
	else if ( getOffsetValue() ) {
		return inputDate + "T" + hours + ":" + minutes + ":" + seconds + getOffsetValue() + ":00";// This was already there
	}
	else {
		return inputDate;
	}
}

function languageFormatDate( ) {
	let selectedLanguage = $("#pagePropSelectLanguage").attr("value");
	switch (selectedLanguage) {
		case "it":
			return getDateFormat()?.replaceAll("G", "D")?.replaceAll("A", "Y") || "DD/MM/YYYY";
		default:
			return getDateFormat();
	}
}

function formatDateToDateFormat( inputDate, format ) {
	return moment( inputDate, format ).format( getDateFormat() )
}

function getOffsetValue() {
	return $("#offSetValue").attr("value");
}

function getDateFormat() {
	return $('#date-format').attr("value") || "MM/DD/YYYY";
}
