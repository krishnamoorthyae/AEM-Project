/****************************************************************************
 *                                                                          *
 *  This function helps to format a currency amount                         *
 *                                                                          *
 ****************************************************************************/

// uses handlebar patterns in order to allow author to decide the format of the currency
// the format is as follows:
//    {{handlebarName-decimalPlaces-decimalSeparator-thoursandsSeparator}}
//  ex.
//    {{TotalPremium-2-,-.}}
//      TotalPremium = 24589.493
//      The function would return 24.589,49

function formatCurrencyAmount(pattern, amount){
  let patternArr = pattern.split("-");

  amount = (parseInt(patternArr[1])) ? amount.toFixed(parseInt(patternArr[1])) : amount;
  amount = amount.toString();
  if(patternArr[2]){
    amount = amount.replace(".", patternArr[2]);
  }
  if(patternArr[3]){
    let whole, decimal;
    if(patternArr[2]){
      whole = amount.split(patternArr[2])[0];
      decimal = patternArr[2] + amount.split(patternArr[2])[1];
    }
    else{
      whole = amount.split(".")[0];
      decimal = "." + amount.split(".")[1];
    }
    if(patternArr[1] === "0" || !patternArr[1]){
      decimal = "";
    }

    let temp = "";
    for(let i = 0; i < whole.length; i++){
      if(i && !(i%3)){
        temp = patternArr[3] + temp;
      }
      temp = whole.charAt(whole.length - 1 - i) + temp;
    }
    amount = temp + decimal;
  }
  return amount;
}

//Updating amount values upto 2 decimal
function updateDecimalFields(obj) {
  $.each(obj, function (key, value) {
    if (value !== null || value !== undefined) {
      if ($.isPlainObject(value) || $.isArray(value)) {
        updateDecimalFields(value);
      } else if (!isNaN(value) && value != null) {
        let tempDecStr = value.toString();
        if (tempDecStr.includes(".") && /\.\d{3,}/.test(tempDecStr)) {
          obj[key] = formatCurrencyAmount("-2--,", Number(value));
        }
      }
    }
  });
}