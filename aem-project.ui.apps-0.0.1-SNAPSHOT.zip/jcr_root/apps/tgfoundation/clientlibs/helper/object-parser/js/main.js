/****************************************************************************
 *                                                                          *
 *  This function helps get a specific property from an object              *
 *  User must provide object and a string path that they wish to retrieve   *
 *                                                                          *
 ****************************************************************************/

function getObjectProperty(obj, propertyName) {
	if (!obj || !propertyName) return null;

	let parts = propertyName.split(".");

	for (let i = 0; i < parts.length; i++) {
		let currentPart = parts[i];

		if( currentPart.includes("[") ) {
			obj = searchThroughObjectArray( obj, currentPart );
		}
		else {
			obj = obj?.[ currentPart ];
		}
	}
	return obj;
}

function searchThroughObjectArray( obj, path ) {
	let inside = path.substring(1, path.length - 1 );
	if( objectParserIsIndex( inside ) ) {
		obj = obj?.[ inside ];
	}
	else {
		let searchObj = inside.substring(1, inside.length - 1 ),
			searchParam = searchObj.split("=")[0],
			searchVal = searchObj.split("=")[1];

		if( searchVal === "true" ){
			searchVal = true;
		}
		else if ( searchVal === "false" ) {
			searchVal = false;
		}

		if( obj?.constructor === Array ){
			let temp = null
			obj.forEach( itrObj => {
				if( itrObj[ searchParam ] === searchVal ) {
					temp = itrObj;
				}
			})
			obj = temp;
		}
		else {
			return null;
		}
	}

	return obj;
}

function objectParserIsIndex( item ) {
	return !( item.includes("{") && item.includes("}") );
}