function handleShowSpinner() {
	// Spinner HTML requred when service calls are triggered
	let spinnerHTML = '<div class="spinnerBg"></div><div class="spinner"><p class="spnHdg"></p><div class="loader" aria-label="loading"></div></div>';
	$('body').prepend(spinnerHTML);
}

function handleHideSpinner() {
	$(".spinnerBg").remove();
	$(".spinner").remove();
}


