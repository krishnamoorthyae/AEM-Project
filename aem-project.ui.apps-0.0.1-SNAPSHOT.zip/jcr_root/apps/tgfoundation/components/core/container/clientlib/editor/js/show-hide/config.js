let showHideConfig = {
  "inputTypes": (inputType, comparison, name, value) => {
    switch (inputType) {
      case "select":
        switch (comparison) {
          case "eq":
            return `!!$('select[name="${name}"] option[value="${value}"]:selected').length`;
          case "ne":
            return `!!$('select[name="${name}"] option:selected:not([value="${value}"])').length`;
          case "c":
            return `!!$('select[name="${name}"] option:selected:contains("${value}")').length`;
          case "nc":
            return `!!$('select[name="${name}"] option:selected:not(:contains("${value}"))').length`;
          default:
            return null;
        }
      case "input": //input covers both checkbox and radio inputs
        switch (comparison) {
          case "eq":
            return `!!$('input[name="${name}"][value="${value}"]:checked').length`;
          case "ne":
            return `!!$('input[name="${name}"][value="${value}"]:not(:checked)').length`;
          case "c":
            return `$('input[name="${name}"]:checked').siblings().text().includes("${value}")`;
          case "nc":
            return `!$('input[name="${name}"]:checked').siblings().text().includes("${value}")`;
          default:
            return null;
        }
      case "textarea":
        switch (comparison) {
          case "eq":
            return `$('textarea[name="${name}"]').val().toLowerCase() === "${value}".toLowerCase()`;
          case "ne":
            return `$('textarea[name="${name}"]').val().toLowerCase() !== "${value}".toLowerCase()`;
          case "c":
            return `$('textarea[name="${name}"]').val().toLowerCase().includes("${value}".toLowerCase())`;
          case "nc":
            return `!$('textarea[name="${name}"]').val().toLowerCase().includes("${value}".toLowerCase())`;
          case "gt":
            return `$('textarea[name="${name}"]').val().toLowerCase() > "${value}".toLowerCase()`;
          case "lt":
            return `$('textarea[name="${name}"]').val().toLowerCase() < "${value}".toLowerCase()`;
          case "gte":
            return `$('textarea[name="${name}"]').val().toLowerCase() >= "${value}".toLowerCase()`;
          case "lte":
            return `$('textarea[name="${name}"]').val().toLowerCase() <= "${value}".toLowerCase()`;
          default:
            return null;
        }
      case "text":
        switch (comparison) {
          case "eq":
            return `$('input[name="${name}"]').val().toLowerCase() === "${value}".toLowerCase()`;
          case "ne":
            return `$('input[name="${name}"]').val().toLowerCase() !== "${value}".toLowerCase()`;
          case "c":
            return `$('input[name="${name}"]').val().toLowerCase().includes("${value}".toLowerCase())`;
          case "nc":
            return `!$('input[name="${name}"]').val().toLowerCase().includes("${value}".toLowerCase())`;
          case "gt":
            return `$('input[name="${name}"]').val().toLowerCase() > "${value}".toLowerCase()`;
          case "lt":
            return `$('input[name="${name}"]').val().toLowerCase() < "${value}".toLowerCase()`;
          case "gte":
            return `$('input[name="${name}"]').val().toLowerCase() >= "${value}".toLowerCase()`;
          case "lte":
            return `$('input[name="${name}"]').val().toLowerCase() <= "${value}".toLowerCase()`;
          default:
            return null;
        }
      default:
        return null;
    }
  },
  "concatenators": {
    "AND": "&&",
    "OR": "||"
  }
}