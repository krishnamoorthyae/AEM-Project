async function handleAuthorContainerShowHide(canvas, object){
	setupFromPrevious(canvas, object);

	setupMutationsShowHideMutationsObserver( canvas, object );
}

function setupMutationsShowHideMutationsObserver( canvas, object ) {
	let MutationObserver = window.MutationObserver || window.WebKitMutationObserver || window.MozMutationObserver;
	let body             = document.body;
	let observer         = new MutationObserver(function(mutations) {
		mutations.forEach(function(mutation) {
			// needed for IE
			let nodesArray = [].slice.call(mutation.addedNodes);
			if (nodesArray.length > 0) {
				nodesArray.forEach(function(addedNode) {
					if( $(addedNode).hasClass("_coral-Multifield-item") ) {
						$(addedNode).prev().find(".and-or").removeClass("hide")
						handleSelectionInputValueSetup( $(addedNode), object )
						setupFromPrevious( canvas , object);
					}
				});
			}
			let removedNodes = [].slice.call(mutation.removedNodes);
			if (removedNodes.length > 0) {
				removedNodes.forEach(function(removeNode) {
					if( $(removeNode).hasClass("_coral-Multifield-item") && $(removeNode).find(".and-or").length ) {
						canvas.find(".and-or").last().addClass("hide");
					}
				});
			}
		});
	});

	observer.observe(body, {
		subtree: true,
		childList: true,
		characterData: true
	});
}


function handleSelectionInputValueSetup(node, pageInp){
	let coralSelect = node.find('.coral-Form-field._coral-Dropdown[name$="./source"]')[0];

	//populate the Coral Select with options
	Object.keys( pageInp ).forEach( key => {
		const option = pageInp[key],
			selectItem = new Coral.Select.Item();

		selectItem.value = option.name;
		selectItem.content.textContent = option.name
		coralSelect.items.add( selectItem );
	})

	$(coralSelect).on("change", function(event) {
		let select = $(event.currentTarget);

		select.closest("coral-multifield-item-content").find(".cmp-form-options-source-val").val( select.val() )
		handleShowHideSourceSelection( select, pageInp );
		setTimeout( function() {
			setupFromPrevious( node.closest("coral-panel") , pageInp);
		}, 10)
	})
}

function handleShowHideSourceSelection( source, pageInp ) {
	const selected = source.val();

	let targetSelect = source.closest("coral-multifield-item-content").find(".page-input-select"),
		targetText = source.closest("coral-multifield-item-content").find(".page-input-text");

	if( pageInp[ selected ] && pageInp[ selected ].value ) {
		let coralSelect = targetSelect.find(".coral-Form-field._coral-Dropdown")[0]
		coralSelect.items.clear();

		//populate the Coral Select with options
		pageInp[ selected ].value.forEach( option => {
			let selectItem = new Coral.Select.Item();

			selectItem.value = option.value;
			selectItem.content.textContent = option.name
			coralSelect.items.add( selectItem );
		})

		$(coralSelect).on("change", function(event) {
			handleShowHideValueSelect( $(event.currentTarget) );
			setTimeout( function() {
				setupFromPrevious( node.closest("coral-panel") , pageInp);
			}, 10)
		})

		targetSelect.removeClass("hide");
		targetText.addClass("hide")
	}
	else {
		targetSelect.addClass("hide");
		targetText.removeClass("hide")

		targetSelect.closest("coral-multifield-item-content").find(".page-input-select-val").val( "" );
	}
}

function handleShowHideValueSelect( select ) {
	let value = select.val();

	select.closest("coral-multifield-item-content").find(".page-input-select-val").val( value );
}
