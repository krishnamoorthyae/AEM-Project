/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 ~ Copyright 2019 Adobe
 ~
 ~ Licensed under the Apache License, Version 2.0 (the "License");
 ~ you may not use this file except in compliance with the License.
 ~ You may obtain a copy of the License at
 ~
 ~     http://www.apache.org/licenses/LICENSE-2.0
 ~
 ~ Unless required by applicable law or agreed to in writing, software
 ~ distributed under the License is distributed on an "AS IS" BASIS,
 ~ WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 ~ See the License for the specific language governing permissions and
 ~ limitations under the License.
 ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
/* global jQuery */
(function ($) {
  "use strict";
  
  let selectors = {
    dialogContent: ".cmp-container__editor"
  };
  
  $(document).on("dialog-loaded", function (e) {
	  setTimeout( function () {
		  console.log("hello");
		  let target = e.dialog.find(selectors.dialogContent),
			  $dialog = $( target.length > 0 ? target[0] : target.context ),
			  tab = $("._coral-Tabs-itemLabel:contains(Show Hide)").closest("._coral-Tabs-item");

		  if( tab.length ) {
			  let coralPanel = $dialog.find(`#${tab.attr("aria-controls")}`),
				  page = null;

			  let html = $( $("#ContentFrame").contents()[0] )?.find("body")?.clone();
			  initialSetup(html).then(res => {
				  handleAuthorContainerShowHide(coralPanel, res);
			  });
		  }
	  }, 100 );
  });

})(jQuery);
