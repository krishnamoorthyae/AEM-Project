//Gets the Page Inputs and stores them within the page variable
//Stores them in a way that is accessible for the dialog to use
async function initialSetup(page) {
	let inpObj = {}
    if(page) {
        //get all inputs that are not hidden
        let pageInp = page.find("input:not([type='hidden']), select, textarea");

        //setup inputs in a desired way
        //this helps with radio and checkboxes as well as selects
        $(page.find("div")[0]).prepend("<div class='temporary-needed-to-filter'></div>");
        pageInp.each( (key, current) => {
            current = $(current);

			let type = current.attr("type"),
	            name = current.attr('name');

			if( current[0].tagName?.toLowerCase() === "select" ) {
				type = "dropdown"
			}

            if(type === "radio" || type === "checkbox") {
				let inputLabel = page.find(`input[value="${current.attr("value")}"][name="${name}"]`).parent(),
                    optionValue = inputLabel.find("input").attr("value"),
                    optionText = `(${optionValue}) ${inputLabel.find("span").text()}`;

				if( Object.keys( inpObj ).includes( name ) ) {
					inpObj[ name ].value.push( {
						name: optionText,
						value: optionValue
					})
				}
				else {
					inpObj[ name ] = {
						type: type,
						name: name,
						value: [ {
							name: optionText,
							value: optionValue
						} ]
					}
				}
            }
	        else if(type === "dropdown") {
				let valArr = [];
				current.find("option").each( (idx, elem) => {
					let $elem = $(elem);

					valArr.push({
						name: `(${$elem.attr("value")}) ${$elem.text()}`,
						value: $elem.attr("value")
					})
				});
	            inpObj[ name ] = {
		            type: "dropdown",
		            name: name,
		            value: valArr
	            }
            }

	        if( !Object.keys( inpObj ).includes( name ) ) {
		        inpObj[ name ] = {
			        type: "text",
			        name: name,
		        }
	        }
        });
    }

	return inpObj
}

function setupFromPrevious(canvas, object){
	canvas.find("._coral-Multifield-item").each( (idx, elem) => {
		handleSelectionInputValueSetup( $(elem), object )

		setTimeout( function () {
			let coralSelect = $(elem).find('.coral-Form-field._coral-Dropdown[name$="./source"]'),
				sourceVal = coralSelect.closest("coral-multifield-item-content").find(".cmp-form-options-source-val").val();

			coralSelect.val( sourceVal )

			if( sourceVal !== "clientSession" && sourceVal !== "" ) {
				$(elem).find("[data-showhidetargetvalue='clientSession']").addClass( "hide" );
			}
			else {
				$(elem).find("[data-showhidetargetvalue='clientSession']").removeClass( "hide" );
			}

			handleShowHideSourceSelection( coralSelect, object );

			let pageSelectParent = $(elem).find(".page-input-select"),
				dataDropdown = pageSelectParent.find(".coral-Form-field._coral-Dropdown"),
				value = dataDropdown.closest("coral-multifield-item-content").find(".page-input-select-val").val( );

			dataDropdown.val( value );
		}, 10)
	})

	canvas.find(".and-or").last().removeClass("hide")
}

