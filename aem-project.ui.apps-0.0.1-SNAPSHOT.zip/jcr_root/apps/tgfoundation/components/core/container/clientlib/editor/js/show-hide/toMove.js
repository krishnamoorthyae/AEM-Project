async function waitToPopulate(leftHand, section, val1, val2, args){
  section.find(".show-hide-comparator-options").val(val1);
  section.find(".comparison-value").val(val2);
  
  if(section.find(".show-hide-comparator-options").val() !== val1 ||
    section.find(".comparison-value").val() !== val2 || (leftHand.val() === "fromSession" && !leftHand.parent().find(".fromSession").length)) {
    setTimeout(function(){
      leftHand.trigger("change", false);
      waitToPopulate(leftHand, section, val1, val2, args).then(() => recalculateAndOrOperation(args) );
    }, 100);
  }
  
}

function getShowHideComparator(){
    return '<div class="show-hide-comparison-parent">' +
        '<select class="show-hide-comparator-options">' +
        '<option value="eq">=</option>' +
        '<option value="gt">&#62;</option>' +
        '<option value="lt">&#60;</option>' +
        '<option value="gte">&#8807;</option>' +
        '<option value="lte">&#8806;</option>' +
        '<option value="ne">!=</option>' +
        '<option value="c">Contains</option>' +
        '<option value="nc">Does Not Contain</option>' +
        '<option value="in">Exists</option>' +
        '</select>' +
        '</div>'
}

function handleRemoveSection(chosen, args){
    chosen.closest(".parent-section-to-delete").remove();

    if(!args.canvas.find(".parent-section-to-delete").length){
        let dialog = args.canvas.find("#author-show-hide-capability");
        let addButton = getButtonHTML("+ ADD CONDITION", newConditionSection, args, "dialog-author-and-or-button");
        dialog.append(addButton);
    }
    else{
        let buttonSection = $(args.canvas.find(".parent-section-to-delete")).last().find(".author-show-hide-button-section");
        buttonSection.find("button").each(function(){
            $(this).removeClass("not-selected-comparison-button");
            $(this).removeClass("selected-comparison-button");
            $(this).removeAttr("disabled");
        })
    }

    recalculateAndOrOperation(args);
}

function recalculateAndOrOperation(args){
    let choices = args.canvas.find(".parent-section-to-delete");
    let saveValue = "";

    choices.each(function(idx){
        let concatenator = $(this).find(".selected-comparison-button");
        let leftHand = $(this).find(".show-hide-input-selection-name option:selected");
        if(leftHand.attr("inputType") === "fromSession") {
            leftHand = $(this).find(".show-hide-selection-parent .fromSession")
        }
        let input = leftHand.attr("inputType");
        let inputName = leftHand.attr("value") || leftHand.val();
        let comparator = $(this).find(".show-hide-comparator-options option:selected").attr("value");
        let compareVal = $(this).find(".comparison-value").val();

        //The separator ..-. is used to separate between all the parts of the equation
        saveValue += ( showHideConfig.inputTypes(input, comparator, inputName, compareVal) || input ) +
            `?name=${inputName}&value=${compareVal}&operator=${comparator}&inputType=${input}`;

        if(concatenator.length){
            saveValue += showHideConfig.concatenators[concatenator.text()];
        }
    })

    args.canvas.find("input[name='./displayCondition']").attr("value", saveValue);
}

function authorChangedComparator(button, args) {
    if(button) {
        let sibling = (button.text().trim() === "AND") ? button.next() : button.prev();

        button.removeClass("not-selected-comparison-button");
        button.addClass("selected-comparison-button");
        button.attr("disabled", true);
        sibling.addClass("not-selected-comparison-button");
        sibling.removeClass("selected-comparison-button");
        sibling.removeAttr("disabled");

        recalculateAndOrOperation(args)
    }
}

function handleSelectionInputValues(chosen, args, recalculate){
    let selectionParent = chosen.closest(".author-show-hide-section");
    selectionParent.find(".author-show-hide-container-comparison-values").parent().remove();
    selectionParent.find(".authoring-show-hide-textfield").remove();
    let htmlInp;
    args.inputList.each( (key, value) => {
        let name = $(value).attr("name");
        if(name === chosen.attr("value")){
            htmlInp = $('<div class="show-hide-selection-parent"></div>');
            htmlInp.append($(value).clone().removeAttr("id"));
            return false;
        }
    })

    if(htmlInp){
        if(htmlInp.find("option").length){
            htmlInp.find("select").removeClass().addClass("author-show-hide-container-comparison-values comparison-value")
        }
        else {
            htmlInp = '<div class="authoring-show-hide-textfield">' +
                '<input type="text" value="" placeholder="please enter a value" class="authoring-show-hide-textfield-input comparison-value"></div>'
        }
    }
    selectionParent.find(".author-comparator-show-hide-main-tool").append(htmlInp);

    //for session storage values
    let selectParent = chosen.closest(".show-hide-selection-parent");
    if(chosen.attr("inputType") === "fromSession") {
        selectParent.find("select").addClass("hide");
        selectParent.find('.fromSession').remove();
        selectParent.append($('<input class="fromSession" placeholder="Session Name" inputType="fromSession" type="text" id="fromSession" name="fromSession">'));
        selectParent.find(".fromSession").on("change", function() {
            recalculateAndOrOperation(args);
        })
    }
    else {
        selectParent.find('.fromSession').remove();
    }
    //end of for session storage values

    if(recalculate !== false){
        recalculateAndOrOperation(args);
    }
}

