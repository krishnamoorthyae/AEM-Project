function handleHandlebarReplacement() {
// placeholder functionality ,  {{textName}} is authored then it is replaced with sessionStorage.getItem("textName");
	$('.container [data-handlebar-replace]').each(function () {
		clearHiddenLabelText();
		recursiveReplaceHandlebarsfromSession($(this).parent());
		addHiddenLabelText();
	});
}

function recursiveReplaceHandlebarsfromSession(root){
	root.children().each(function(){
		handlebarArrayReplacement( $(this) );
		let item = $(this);

		let text = item.html().replaceAll("{<!-- -->{", "{{");
		text = text.replaceAll("%7B%7B", "{{");
		text = text.replaceAll("%7D%7D", "}}");
		if(text.indexOf('{{') !== -1 && text.indexOf('}}') !== -1 ) {
			recursiveReplaceHandlebarsfromSession( item );

			text = item.html().replaceAll("{<!-- -->{", "{{");
			text = text.replaceAll("%7B%7B", "{{");
			text = text.replaceAll("%7D%7D", "}}");
			while (text.indexOf('{{') !== -1 && text.indexOf('}}') !== -1 && !item.find("[data-cmp-data-layer]").length) {
				text = replaceHandlebarLogic( text.split('{{')[1].split('}}')[0], text, item );
			}
		}
	})
}

function replaceHandlebarLogic(replaceHandlebar, text, item) {
	let sessionValue = (replaceHandlebar in sessionStorage) ? sessionStorage.getItem(replaceHandlebar) : "";
	sessionValue = (replaceHandlebar.endsWith("_noSpan") && replaceHandlebar.split("_noSpan")[0] in sessionStorage) ? sessionStorage.getItem(replaceHandlebar.split("_noSpan")[0]) : sessionValue;

	if( replaceHandlebar.includes(".") || replaceHandlebar.includes("[") ) {
		sessionValue = getHandleberSessionObject( replaceHandlebar, JSON.parse( sessionStorage.getItem(replaceHandlebar.split(".")[0]) ) );
	}

	if( sessionValue?.startsWith("[") && !replaceHandlebar.endsWith("]") ) {
		sessionValue = JSON.parse( sessionValue )[0];
	}

	if (sessionValue) {
		if (typeof sessionValue === 'string' && item.closest(".product-display").find("[data-superscript]").length && sessionValue.includes(".")) {
			sessionValue = sessionValue.split(".")[0] + "<sup>." + sessionValue.split(".")[1] + "</sup>";
		}
		if (replaceHandlebar.endsWith("_noSpan")) {
			text = text.replaceAll('{{' + replaceHandlebar + '}}', sessionValue);
		}
		else if (replaceHandlebar.endsWith("_date")) {
			text = text.replaceAll('{{' + replaceHandlebar + '}}', formatDateToDateFormat(sessionValue) );
		}
		else if (replaceHandlebar.split("-").length > 1  && !replaceHandlebar.includes("_input_") && !isNaN( sessionValue ) ) {
			if( typeof sessionValue === 'string' ) {
				sessionValue = sessionValue.split(",").join("");
			}
			let neg = false;
			if (sessionValue < 0) {
				neg = true;
				sessionValue *= -1;
			}
			if (sessionValue) {
				sessionValue = formatCurrencyAmount(replaceHandlebar,
					parseFloat(sessionValue));
			}
			else {
				sessionValue = sessionValue ? sessionValue : formatCurrencyAmount(replaceHandlebar, 0);
			}
			if (neg) {
				sessionValue = "-" + sessionValue;
			}
		}
		else {
			text = text.replaceAll('{{' + replaceHandlebar + '}}', `<span class="handlebar-recursive-replacement ${replaceHandlebar}">${sessionValue}</span>`);
		}
	}

	if (replaceHandlebar.includes("sub(")) {
		let argumentList = replaceHandlebar.trim().split("(")[1].split(")")[0].split(","),
			subtraction = 0;
		argumentList.forEach((name, idx) => {
			name = name.trim();
			if (name in sessionStorage && !isNaN(sessionStorage.getItem(name))) {
				if (idx === 0) {
					subtraction = parseFloat(sessionStorage.getItem(name));
				} else {
					subtraction -= parseFloat(sessionStorage.getItem(name));
				}
			}
		});
		sessionValue = subtraction;
	}
	if (replaceHandlebar.split("-").length > 1 && (/-\d-{2,},$/.test(replaceHandlebar))) {
		sessionValue = !sessionValue ?
			(replaceHandlebar.split("-")[0] in sessionStorage ?
				Number(sessionStorage.getItem(replaceHandlebar.split("-")[0])).toString() : "") : sessionValue || "";

		let neg = false;
		if (sessionValue < 0) {
			neg = true;
			sessionValue *= -1;
		}
		if (sessionValue) {
			if( typeof sessionValue === 'string') sessionValue = sessionValue.replaceAll(",","")
			sessionValue = formatCurrencyAmount(replaceHandlebar,
				parseFloat(sessionValue) );
		} else {
			sessionValue = sessionValue ? sessionValue : formatCurrencyAmount(replaceHandlebar, 0);
		}
		if (neg) {
			sessionValue = "-" + sessionValue;
		}
	}
	let replacedText = "";
	if (replaceHandlebar.endsWith("_noSpan")) {
		replacedText = (replaceHandlebar === 'api-error-msg') ? "" :
			text.replaceAll('{{' + replaceHandlebar + '}}', sessionValue);
	}
	else if (replaceHandlebar.endsWith("_date")) {
		replacedText = (replaceHandlebar === 'api-error-msg') ? "" :
			text.replaceAll('{{' + replaceHandlebar + '}}', formatDateToDateFormat(sessionValue) );
	}
	else {
		replacedText = (replaceHandlebar === 'api-error-msg') ? "" :
			text.replaceAll('{{' + replaceHandlebar + '}}', `<span class="handlebar-recursive-replacement ${replaceHandlebar}">${sessionValue}</span>`);
	}
	if (item.find("cq").length || item.prop("tagName") === "cq") {
		text = replacedText;
	}
	else {
		item.html(replacedText);
		text = item.html();
	}
	return text;
}

function getHandleberSessionObject( replaceHandlebar, obj, beginningStart ) {
	replaceHandlebar.split(".").forEach( (value1, index1) => {
		if(index1 > 0 || beginningStart ) {
			value1 = value1.includes("[") ? value1.split("[")?.[1]?.split("]")?.[0] : value1;
			if( value1.endsWith("_date" ) ) {
				value1 = value1.substring(0, value1.length - 5 );
			}
			else if( value1.endsWith("_noSpan" ) ) {
				value1 = value1.substring(0, value1.length - 7 );
			}
			value1 = value1.split("-")[0];
			obj = obj?.[`${value1}`];
		}
	})
	return obj;
}

function clearHiddenLabelText() {
	$('input[type="hidden"][name$="Label"]').each( (idx, inp) => {
		if( $(inp).val().includes("{{") && $(inp).val().includes("}}") ) {
			$(inp).val("");
			$(inp).next()?.remove();
		}
	});
}

function addHiddenLabelText() {
	$('input[type="hidden"][name$="Label"]').each( (idx, inp) => {
		if( !$(inp).val() ) {
			let val = $(inp)?.parent()?.find("label")?.text();
			if( !val.includes("{{") && !val.includes("}}") ) {
				$(inp).val( val );
			}
		}
	});
}

function handlebarArrayReplacement( html ) {
	let wcmmode = document.cookie.split("; wcmmode=").pop().split(";")[0];
	if( wcmmode !== 'edit' ) {
		let elements = html.closest(".container").find("[data-array-handlebar-name]");
		elements = removeHandlebarElementsWithParent(elements);
		recursiveHandlebarArrayReplacement(elements, "");
	}
}

function removeHandlebarElementsWithParent( elements ) {
	for( let i = elements.size() - 1; i >= 0; i-- ) {
		let container = $(elements[ i ]).parent();
		if( repeatableHasParent(container) ) {
			elements.splice( i, 1 );
		}
	}
	return elements;
}

function recursiveHandlebarArrayReplacement( elements, sessionName ) {
	let compilation = [];
	elements.each( (elemIdx, elem) => {
		let newSessionName = sessionName;
		if( !newSessionName.length ) {
			newSessionName = $(elem).attr("value");
		}
		else {
			newSessionName += "." + $(elem).attr("value");
		}

		let idx = 0,
			indexer = ".[" + idx++ + "]",
			objArray = getHandleberSessionObject(newSessionName + indexer, JSON.parse( sessionStorage.getItem((newSessionName + indexer).split(".")[0]) ) );

		let container = $(elem).parent();
		container.find("> [data-array-handlebar-name]").remove();

		while( objArray ) {
			let children = container.find("[data-array-handlebar-name]");
			children = removeHandlebarElementsWithParent( children );
			if( children.length ) {
				recursiveHandlebarArrayReplacement( children, newSessionName + indexer );
			}
			let template = container.clone(true, true);
			let text = template.html();
			text = text.replaceAll("{<!-- -->{", "{{");
			text = text.replaceAll("%7B%7B", "{{");
			text = text.replaceAll("%7D%7D", "}}");
			while (text.indexOf('{{') !== -1 && text.indexOf('}}') != -1) {
				let handlebar = text.split('{{')[1].split('}}')[0],
					value = objArray[ handlebar ];

				if( handlebar.includes(".") ) {
					value = getHandleberSessionObject(handlebar, objArray, true);
				}
				if (handlebar.endsWith("_date")) {
					value = objArray[ handlebar.split("_date")[0] ];
					value = formatDateToDateFormat(value);
				}
				else if (handlebar.split("-").length > 1) {
					let neg = false;
					if (value < 0) {
						neg = true;
						value *= -1;
					}
					if (value) {
						if( typeof value === 'string' ) value = value.replaceAll(",","")
						value = formatCurrencyAmount(handlebar,
							parseFloat(value));
					}
					else {
						handlebar = handlebar ? handlebar : formatCurrencyAmount(handlebar, 0);
					}
					if (neg) {
						value = "-" + value;
					}
				}
				text = text.replaceAll("{{" + handlebar + "}}", value || "" );
			}
			template.html( text );

			container.before( template );
			indexer = ".[" + idx++ + "]"
			objArray = getHandleberSessionObject(newSessionName + indexer, JSON.parse( sessionStorage.getItem((newSessionName + indexer).split(".")[0]) ) );
		}

		container.remove();
	})
}

function repeatableHasParent( element ) {
	let hasParent = false,
		temp = element;
	while( temp.parent().length ) {
		temp = temp.parent().closest(".container");
		if( temp.find("> [data-array-handlebar-name]").length ){
			hasParent = true;
			break;
		}
	}
	return hasParent;
}

$(document).on("ready", function() {
	handleHandlebarReplacement()
})

