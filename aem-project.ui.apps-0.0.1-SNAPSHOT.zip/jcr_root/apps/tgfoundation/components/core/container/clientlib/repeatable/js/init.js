let originalRepetitionTemplate = {};

const repeatableContainerInit = () => {
	let setupAlreadyList = [];
	$('.numberOfDuplicates').each(function () {
		if (!$(this).parent().find("> .indexContainer").length) {
			setupAlreadyList = initializeRepeatableContainer($(this), setupAlreadyList);
		}
	});

	if (sessionStorage.getItem("replication-containers-list")) {
		let containersList = sessionStorage.getItem("replication-containers-list").split(",");
		for (let i = 0; i < containersList.length; i++) {
			if (setupAlreadyList.includes(containersList[i])) {
				continue;
			}
			let parentList = $(`#startIndex[data-cmp-name=${containersList[i]}`).closest(".container");
			if (!parentList.length) continue;

			parentList.each((idx, parentElem) => {
				let parentContainer = $(parentElem),
					numberofRepetitions = parseInt(parentContainer.find("> .numberOfDuplicates").attr("value"));
				if (!numberofRepetitions) {
					let iterationName = (parentContainer.find("> .cmp-container").attr("id") || "default") + "-replication-index";
					let iterations = sessionStorage.getItem(iterationName);
					parentContainer.attr("data-cmp-duplicate", true);
					originalRepetitionTemplate[iterationName.split("-")[0]] = parentContainer.clone(true, true);
					repetitionSetupFromSessionStorage(parentContainer, iterations, false, iterationName, true, true)
				}
			})
		}
	}
}

function initializeRepeatableContainer(dupeCount, setupAlreadyList = [], iterationIdx) {
	let parentContainer = dupeCount.closest(".container"),
		ignoreTravelerLoop = parentContainer.find('#ignoreTravelerLoop').attr("value") === "true",
		containerId = parentContainer.find('> .cmp-container').attr('id'),
		sessIgnoreTravelerLoop = sessionStorage.getItem("ignoreTravelerLoop") || '';
	if (ignoreTravelerLoop && containerId) {
		if (sessIgnoreTravelerLoop) {
			if (!sessIgnoreTravelerLoop.includes(containerId)) {
				sessIgnoreTravelerLoop = `${sessIgnoreTravelerLoop},${containerId}`;
			}
		} else {
			sessIgnoreTravelerLoop = containerId;
		}
		sessionStorage.setItem('ignoreTravelerLoop', sessIgnoreTravelerLoop);
	}
	let hidden = parentContainer.find('> #hideFirst').attr("value") === "true";
	if (parseInt(dupeCount.attr("value")) > 1 || (parseInt(dupeCount.attr("value")) === 1 && hidden)) {
		if (parentContainer.find("> .indexContainer").length) {
			let oldid = parentContainer.find("> .cmp-container").attr("id"),
				newid = oldid + "-" + iterationIdx;
			parentContainer.find("> .cmp-container").attr("id", newid);
			let cloneContainer = originalRepetitionTemplate[oldid].clone(true, true);
			cloneContainer.find("> .cmp-container").attr("id", newid);
			originalRepetitionTemplate[newid] = cloneContainer.clone(true, true);
		}
		let iterationName = (parentContainer.find("> .cmp-container").attr("id") || "default") + "-replication-index",
			iterations = sessionStorage.getItem(iterationName),
			numberofRepetitions = parseInt(dupeCount.attr('value'));

		if (sessionStorage.getItem("replication-containers-list")) {
			let replicationList = sessionStorage.getItem("replication-containers-list").split(",");
			if (replicationList.indexOf(iterationName.split("-replication")[0]) === -1) {
				replicationList.push(iterationName.split("-replication")[0]);
				sessionStorage.setItem("replication-containers-list", replicationList);
			}
		}
		else {
			sessionStorage.setItem("replication-containers-list", iterationName.split("-")[0]);
		}
		storeHiddenInput("replication-containers-list", sessionStorage.getItem("replication-containers-list"))

		if (numberofRepetitions > 0 || (hidden && numberofRepetitions === 1)) {
			parentContainer.attr("data-cmp-duplicate", true);
			originalRepetitionTemplate[iterationName.split("-")[0]] = parentContainer.clone(true, true);

			if (parentContainer.find("> .cmp-container .indexContainer").length) {
				let indexedContainer = parentContainer.find("> .cmp-container .indexContainer").closest(".container");
				originalRepetitionTemplate[indexedContainer.find("> .cmp-container").attr("id")] = indexedContainer.clone(true, true);
			}
			if (iterations) {
				setupAlreadyList.push(iterationName.split("-")[0])
				repetitionSetupFromSessionStorage(parentContainer, iterations, hidden, iterationName, false);
			}
			else {
				repetitionInitialSetup(parentContainer, hidden, iterationName, numberofRepetitions);
			}
		}
		if (hidden) {
			parentContainer.find("> .cmp-container").hide();
		}
	}
	else if (parseInt(dupeCount.attr("value")) === -1) {
		let parentContainer = dupeCount.closest(".container");
		parentContainer.attr("data-cmp-duplicate", true);
		parentContainer.find("input, textarea, select, button").each((idx, elem) => {
			let repInputId = parentContainer.find("> .cmp-container").attr("id") + "-replication-index-iteration_2_input_" + $(elem).attr("name")
			//if dialog selected for loop indexing
			//then add parent loop index
			$(elem).attr("data-cmp-duplication-input-id", repInputId);
			if (repInputId in sessionStorage) {
				if ($(elem).attr("type") === "radio" || $(elem).attr("type") === "checkbox") {
					if ($(elem).val() === sessionStorage.getItem(repInputId)) {
						$(elem).attr("checked", true);
					}
					else {
						$(elem).attr("checked", false);
					}
				}
				else {
					$(elem).val(sessionStorage.getItem(repInputId));
				}
			}
		});
		sessionStorageHandler(parentContainer, "data-cmp-duplication-input-id");
		let multitravelerLoop = sessionStorage.getItem("multipleTravelerLoopNames") || '';
		let loopid = parentContainer.find('> .cmp-container').attr('id');
		if (loopid && !multitravelerLoop.includes(loopid)) {
			multitravelerLoop = (multitravelerLoop) ?
				`${multitravelerLoop},${loopid}` : loopid;
			sessionStorage.setItem("multipleTravelerLoopNames", multitravelerLoop);
			sessionStorage.setItem(loopid + "-replication-index", "2");
		}
	}
	return setupAlreadyList;
}

function repetitionSetupFromSessionStorage(insertBeforeContainer, iterations, firstHidden, iterationName, hideButtons, show) {
	let startElem = insertBeforeContainer.find("> #startIndex"),
		startIdx = parseInt(startElem.attr("value")),
		id = insertBeforeContainer.find("> .cmp-container").attr("id"),
		endIdx = parseInt(startElem.attr("data-cmp-endIndex")),
		startCount = parseInt(startElem.attr("data-cmp-count"));

	for (let key in sessionStorage) {
		if (key.indexOf(iterationName + "-iteration_1") === 0) {
			startIdx = 1;
		}
	}
	if (startIdx > 1) {
		startIdx = startIdx - (startCount || 0);
	}
	let repetitionNum = parseInt(iterations) + (startIdx || 1) - 1;
	startIdx = parseInt(insertBeforeContainer.find("> #startIndex").attr("value"));
	if (repetitionNum === 0) {
		repetitionInitialSetup(insertBeforeContainer, firstHidden, iterationName);
		return;
	}
	if (!isNaN(endIdx)) {
		repetitionNum = endIdx;
	}
	else if (!isNaN(startCount) && repetitionNum < startCount) {
		repetitionNum = startCount;
	}
	for (let i = 0 + (startIdx || 1) - 1; i < repetitionNum; i++) {
		if (originalRepetitionTemplate?.[id]) {
			let parentContainer = originalRepetitionTemplate[id].clone(true, true),
				hideRemoveButton = parentContainer.find('> #hideRemoveButton').attr("value");
			insertBeforeContainer.before(parentContainer);
			let removeButton = getButtonHTML("Remove", i + 1, removeContainer, parentContainer, iterationName, true);

			if (parentContainer.find("> .cmp-container .indexContainer").length) {
				let indexedContainer = parentContainer.find("> .cmp-container .indexContainer").closest(".container");
				originalRepetitionTemplate[indexedContainer.find("> .cmp-container").attr("id")] = indexedContainer.clone(true, true);
			}
			repetitionInputSetup(parentContainer, i + 1, true, iterationName);
			sessionStorageHandler(parentContainer, "data-cmp-duplication-input-id");

			updateRemainingCounter(parentContainer, -(i + 1));
			placementOfRepeatableContainerButtons(parentContainer, removeButton);

			let remainingRepetitions = parseInt(parentContainer.find('> .numberOfDuplicates').attr("value"));

			if ((i + 1) === repetitionNum && remainingRepetitions && !hideButtons) {
				let addButton = getButtonHTML("Add", (i + 1), replicateContainer, parentContainer, iterationName);
				let addedAddButton = parentContainer.find('> #hideAddButton').attr("value");
				if (addedAddButton === undefined) {
					removeButton.find("button").before(addButton);
				}
			}

			parentContainer.find("input:not([type=hidden]), textarea, select, button").each(function () {
				let storedVal = sessionStorage.getItem(iterationName + "-iteration_" + (i + 1) + "_input_" + $(this).attr("name"));
				if (storedVal) {
					if ($(this).attr("type") === "radio" || $(this).attr("type") === "checkbox") {
						if ($(this).val() === storedVal) {
							$(this).attr("checked", true);
						}
						else {
							$(this).attr("checked", false);
						}
					}
					else {
						$(this).val(storedVal);
					}
				}
				$(this).focusout();
			});

			if ((repetitionNum === (startIdx || 1) && !firstHidden) || hideButtons || hideRemoveButton) {
				removeButton.find("button[id^='remove-container-button__']").remove();
			}

			parentContainer.show();
		}
	}

	insertBeforeContainer.remove();
}

function updateRemainingCounter(parentContainer, changeValue) {
	let numberOfRepetitions = parentContainer.find('> .numberOfDuplicates');
	let repetitionsRemaining = parseInt(numberOfRepetitions.attr("value")) + changeValue;
	numberOfRepetitions.attr("value", repetitionsRemaining);
}

function repetitionInitialSetup(parentContainer, isHidden, iterationName, iterations) {
	let startIdx = parseInt(parentContainer.find("#startIndex").attr("value")),
		index = (isHidden ? 0 : 1) + (startIdx || 1) - 1,
		addButton = getButtonHTML("Add", index, replicateContainer, parentContainer, iterationName, true),
		addedAddButton = parentContainer.find('#hideAddButton').attr("value"),
		startCount = parseInt(parentContainer.find("#startIndex").attr("data-cmp-count"));

	if (isHidden) {
		if (addedAddButton === undefined) {
			placementOfRepeatableContainerButtons(parentContainer, addButton);
		}
		parentContainer.find("select, input:not([type=hidden]), textarea, button").each(function (idx) {
			if ($(this).attr('required')) {
				$(this).removeAttr('required');
				sessionStorage.setItem(iterationName + "-index-" + idx + "-required", true);
			}
		});
	}
	else {
		updateRemainingCounter(parentContainer, -1);
		if (iterations > 1) {
			if (addedAddButton === undefined) {
				placementOfRepeatableContainerButtons(parentContainer, addButton);
			}
		}
	}
	repetitionInputSetup(parentContainer, index, true, iterationName);
	sessionStorageHandler(parentContainer, "data-cmp-duplication-input-id");
	//this dicates how many repetitions are on the page
	sessionStorage.setItem(iterationName, index);

	for (let i = startIdx; i < startCount; i++) {
		$("body").find(".cmp-repeatable-container--addButton").last().trigger("click");
	}
}

function placementOfRepeatableContainerButtons(parentContainer, button) {
	if (parentContainer.find("#displayButtonsOnSide").length) {
		parentContainer.parent().find("> .cmp-repeatable-container-buttons").remove();
		parentContainer.parent().append(button);
	}
	else if (button.find("button").attr("id").endsWith("_0")) {
		parentContainer.append(button);
	}
	else {
		parentContainer.find('> .cmp-container').append(button);
	}
}

function getButtonHTML(type, idx, clickFunction, parentContainer, iterationName, addParent) {
	let dialogValue = parentContainer.find("#duplication" + type + "ButtonName").attr("value");
	//if no value is set up then it defaults to type
	let valueText = dialogValue ? dialogValue : type;
	let parentDiv = $('<div class="cmp-repeatable-container-buttons"></div>');
	if (parentContainer.find("#hideAddButtonName").length) {
		valueText = "";
	}
	let button = $('<button class="cmp-repeatable-container--' + type.toLowerCase() + 'Button"' + 'id="' +
		type.toLowerCase() + '-container-button__' + idx + '" type="button">' + valueText + '</button>').on("click", function repeatableButtonEventHandler() { console.log("Pressed the button"); clickFunction($(this), parentContainer, iterationName) });

	let returnElem;
	if (addParent) {
		returnElem = parentDiv;
		returnElem.append(button);
	}
	else {
		returnElem = button;
	}
	return returnElem;
}

function recursiveReplaceHandlebars(root, replaceValue, handlebar) {
	root.children().each(function () {
		let container = $(this);

		recursiveReplaceHandlebars(container, replaceValue, handlebar);

		let text = container.html();
		if (text.indexOf(handlebar) !== -1) {
			let handlebarText = handlebar.substring(2, handlebar.length - 2),
				replacedText,
				before = text.indexOf(handlebar) - 1,
				after = before + handlebar.length + 1;
			if (before >= 0 && text.substr(before, 1) === text.substr(after, 1)) {
				replacedText = text.replaceAll(handlebar, replaceValue);
				if (text.substr(0, before + 1).includes("{{") && !text.substr(0, before + 1).includes("}}") &&
					!text.substr(after).includes("{{") && text.substr(after).includes("}}")) {
					let newHandlebar = replacedText.substring(replacedText.indexOf("{{"), replacedText.indexOf("}}") + 2),
						newHandlebarText = newHandlebar.substring(2, newHandlebar.length - 2),
						newValue = sessionStorage.getItem(newHandlebarText) || "";
					replacedText = replacedText.replaceAll(newHandlebar, '<span class="handlebar-recursive-replacement ' + newHandlebarText + '">' + newValue + '</span>');
				}
			}
			else {
				replacedText = text.replaceAll(handlebar, '<span class="handlebar-recursive-replacement ' + handlebarText + '">' + replaceValue + '</span>');
			}
			container.html(replacedText);
		}
	})
}

function recreateDatePicker(input, index) {
	let type = input.attr("data-cmp-type");

	if (type === "date") {
		dateMain();
	}
	input.datepicker("destroy");
	input.removeClass("hasDatepicker")
		.removeData("datepicker")
		.attr("id", "form-text-" + Math.random())
		.unbind();
	switch (input.attr("data-cmp-type")) {
		case cmpType.dateOfBirth:
			dob_ip_validation(input, index);
			break;
		case cmpType.date:
			dob_ip_validation(input, index);
			break;
		case cmpType.tripDepartureDate:
			tripDepartureDateSetup(input);
			setTripReturnDate(input, index);
			break;
	}
}

function repetitionInputSetup(parentContainer, iterationidx, clearFlag, iterationName) {
	recursiveReplaceHandlebars(parentContainer, iterationidx, "{{number}}");

	parentContainer.find("input:not([type='hidden']), textarea, select, button").each(function (idx) {
		//setting unique ids for each new input
		let idxElem = parentContainer.find("> .indexElements"),
			oldName = $(this).attr("name") || "",
			name = oldName,
			dupName = `${iterationName}-iteration_${iterationidx}_input_`,
			splitName = oldName.split("-");

		if (splitName.length > 1 && !isNaN(splitName[splitName.length - 1])) {
			name = oldName.slice(0, oldName.lastIndexOf("-"));
		}
		recursiveReplaceHandlebars(parentContainer, iterationidx, `{{${dupName + name}}}`);
		if (idxElem.length && idxElem.attr("value") === "true") {
			name += "-" + iterationidx;
		}
		dupName += name;

		$(this).attr("data-cmp-duplication-input-id", dupName);
		recursiveReplaceHandlebars(parentContainer, iterationidx, `{{${dupName}}}`);

		if (clearFlag) {
			//removing any previous errors and values
			$(this).next("div").remove();
			$(this).parent().removeClass("fldErr");
			$(this).removeAttr("style");

			if ($(this).attr("type") !== "radio" && $(this).attr("type") !== "checkbox") {
				$(this).val('');
			}
			else if ($(this).is(":checked") && !(dupName in sessionStorage)) {
				sessionStorage.setItem(dupName, $(this).val());
			}
			else if ($(this).is(":checked") && dupName in sessionStorage && $(this).val() === sessionStorage.getItem(dupName)) {
				sessionStorage.setItem(dupName, $(this).val());
			}
			else if (!$(this).is(":checked") && dupName in sessionStorage && $(this).val() === sessionStorage.getItem(dupName)) {
				$(this).attr("checked", true);
			}
			else {
				$(this).attr("checked", false);
			}

			if ($(this).hasClass("dob-ip-date")) {
				recreateDatePicker($(this), iterationidx + "" + idx);
			}
		}

		if (idxElem.length && idxElem.attr("value") === "true") {
			parentContainer.find(".containerDisplayCondition").each((idx, elem) => {
				if ($(elem).attr("value").includes(oldName) && !$(elem).attr("value").includes(name)) {
					$(elem).attr("value", $(elem).attr("value").replaceAll(oldName, name));

					let oldResourceName = $(elem).parent().find(".resourceName").attr("value"),
						oldIdx = "";
					if (splitName.length > 1 && !isNaN(splitName[splitName.length - 1])) {
						oldIdx = oldName.slice(oldName.lastIndexOf("-") + 1)
					}
					let resourceName = oldResourceName.substring(0, oldResourceName.length - oldIdx.length) + iterationidx,
						oldSessionName = `show-hide-${oldResourceName}-container-html`,
						newSessionName = `show-hide-${resourceName}-container-html`;

					if (oldSessionName in sessionStorage) {
						sessionStorage.setItem(newSessionName, sessionStorage.getItem(oldSessionName));
						sessionStorage.removeItem(oldSessionName);
					}
					$(elem).parent().find(".resourceName").attr("value", resourceName);
				}
			})

			$(this).attr("name", name);
		}
		if (($(this).attr("name") === "beneficiaryDistribution") && (`${iterationName}`).includes('beneficiary')) {
			if (iterationidx == 1 && sessionStorage.getItem(`${iterationName}`) == '1') {
				$(this).val('100');
				sessionStorage.setItem(($(this).attr('data-cmp-duplication-input-id')), '100');
			} else if (iterationidx != 1) {
				let attrVal = `${iterationName}-iteration_1_input_beneficiaryDistribution`;
				if ($('input[data-cmp-duplication-input-id="' + attrVal + '"]').val() == '100') {
					$('input[data-cmp-duplication-input-id="' + attrVal + '"]').val('');
					sessionStorage.removeItem(attrVal);
				}
			}
		}

	});

	parentContainer.find(".containerDisplayCondition").each((idx, elem) => {
		setTimeout(function () {
			let value = $(elem).attr("value");
			if (value) {
				parseShowHideArgs($(elem).closest(".container"), value);
			}
		}, 100)
	});

	parentContainer.find("> .cmp-container").each((idx, elem) => {
		let setupAlreadyList = [];
		$(elem).find('.numberOfDuplicates').each(function () {
			setupAlreadyList = initializeRepeatableContainer($(this), setupAlreadyList, iterationidx);
		});
	})
}

function sessionStorageHandler(parentContainer, attrKey) {
	setTimeout(function () {
		$("body").find(parentContainer).find("input:not([type=hidden]), textarea, select").each((idx, elem) => {
			["change", "keyup"].forEach(item => {
				if (!hasHandler(elem, item, "repeatableCheck")) {
					$(elem).on(item, function repeatableCheck(idx) {
						let key = $(this).attr(attrKey),
							val = (($(this).attr('type') == 'checkbox' && $(this).is(':checked')) || ($(this).attr('type') != 'checkbox')) ? $(this).val() : '';

						if (key) {
							sessionStorage.setItem(key, val);
							if (val) {
								storeHiddenInput(key, val);
							}
						}
					});
				}
			})
		});
	}, 1000)
}

function storeHiddenInput(name, value) {
	let elem = $('#new_form').find(`input[type="hidden"][name="${name}"]`);
	if (elem.length) {
		elem.attr("value", sessionStorage.getItem(name))
	}
	else {
		$('#new_form').append(`<input type="hidden" name="${name}" value="${value}"/>`);
	}
}

function replicateContainer(addButton, parentContainer, iterationName) {
	//obtaining the index number
	let splitId = addButton.attr("id").split("_");
	let dupidx = parseInt(splitId[splitId.length - 1]),
		addedRmvButton = parentContainer.find('#hideRemoveButton').attr("value");
	sessionStorage.setItem(iterationName, dupidx + 1);
	storeHiddenInput(iterationName, dupidx + 1);

	if (!parentContainer.find("button[id^='remove-container-button__']").length) {
		if (addedRmvButton === undefined) {
			let removeButton = getButtonHTML("Remove", dupidx, removeContainer, parentContainer, iterationName);
			addButton.after(removeButton);
		}
	}

	/*duplicating the container*/
	let id = parentContainer.find("> .cmp-container").attr("id");
	let duplicateParent = originalRepetitionTemplate[id].clone(true, true);
	parentContainer.after(duplicateParent);
	let duplicateAdd = getButtonHTML("Add", dupidx + 1, replicateContainer, duplicateParent, iterationName, true);
	let duplicateRemove = getButtonHTML("Remove", dupidx + 1, removeContainer, duplicateParent, iterationName);
	repetitionInputSetup(duplicateParent, dupidx + 1, true, iterationName);
	sessionStorageHandler(duplicateParent, "data-cmp-duplication-input-id");
	placementOfRepeatableContainerButtons(duplicateParent, duplicateAdd);
	if (addedRmvButton === undefined) {
		duplicateAdd.find("button").after(duplicateRemove);
	}

	//updating the number of iterations left
	let repetitions = parentContainer.find('.numberOfDuplicates');
	let repetitionsLeft = parseInt(repetitions.attr("value")) - 1;
	duplicateParent.find(".numberOfDuplicates").attr("value", repetitionsLeft);

	//determining if we have reached the max number of duplicates
	if (repetitionsLeft === 0) {
		duplicateAdd.find("button[id^='add-container-button__']").remove();
	}

	//remove add button from previous
	addButton.remove();

	//remove hidden container
	if (dupidx === 0) {
		parentContainer.remove();
		duplicateParent.find("select, input:not([type=hidden]), textarea").each(function (idx) {
			if (sessionStorage.getItem(iterationName + "-index-" + idx + "-required")) {
				$(this).attr('required', true);
				sessionStorage.removeItem(iterationName + "-index-" + idx + "-required");
			}
		});
	}

	displayCustomTooltip();
	if (typeof buildOptions === "function") {
		buildOptions(duplicateParent);
	}
}

function sessionStorageUpdateAfterRemove(parentContainer, attrKey, updateFlag, iterationIndex, iterationName) {
	$(parentContainer).find("select, input:not([type=hidden]), textarea, button").each(function (idx) {
		let key = $(this).attr(attrKey);
		if (updateFlag) {
			let value = sessionStorage.getItem(key);
			if (value) {
				if ($(this)?.attr("name")?.includes("-")) {
					sessionStorage.setItem(iterationName + "-iteration_" + iterationIndex + "_input_" + $(this).attr("name").split("-")[0] + "-" + iterationIndex, value);
				} else {
					sessionStorage.setItem(iterationName + "-iteration_" + iterationIndex + "_input_" + $(this).attr("name"), value);
				}
			}
		}
		sessionStorage.removeItem(key);
	});
}

function removeContainer(removeButton, parentContainer, iterationName) {
	//index of the removed item
	let id = parentContainer.find("> .cmp-container").attr("id"),
		splitId = removeButton.attr("id").split("_"),
		removeidx = parseInt(splitId[splitId.length - 1]),
		hideFirst = parentContainer.find('#hideFirst').attr("value") === "true",
		startIdx = parseInt(parentContainer.find("#startIndex").attr("value"));

	sessionStorageUpdateAfterRemove(parentContainer, "data-cmp-duplication-input-id", false, removeidx, iterationName);
	let duplicateContainers = $(`.container[data-cmp-duplicate='true'] #${id}`).parent();

	parentContainer.find("input:not([type=hidden]), textarea, select, button").each((idx, elem) => {
		if ($(elem).attr("name")) {
			if ($(elem).attr("type") !== 'radio' && $(elem).attr("type") !== 'checkbox') {
				$(elem).val("");
			}
			addUpTotalsHandler($(elem))
		}
	});
	if (removeidx === 1 && duplicateContainers.length === 1 && hideFirst) {
		//hiding first container
		let hiddenContainer = originalRepetitionTemplate[id].clone(true, true);
		hiddenContainer.find('> .cmp-container').hide();
		parentContainer.before(hiddenContainer);
		repetitionInitialSetup(hiddenContainer, true, iterationName);
		parentContainer.remove();
	}
	else {
		parentContainer.remove();
		//get a list of all the remaining duplicates
		duplicateContainers = $(`.container[data-cmp-duplicate='true'] #${id}`).parent();
		sessionStorage.setItem(iterationName, duplicateContainers.length);
		let lastIdx = duplicateContainers.length - 1;

		duplicateContainers.each(function (index) {
			let currentButton = $(this).find("button[id^='remove-container-button__']");
			let splitId = currentButton.attr("id").split("_");
			let buttonIdx = parseInt(splitId[splitId.length - 1]);

			if (buttonIdx >= removeidx) {
				//decrease the button index by 1
				buttonIdx = buttonIdx - 1;

				sessionStorageUpdateAfterRemove($(this), "data-cmp-duplication-input-id", true, buttonIdx, iterationName);
				$(this).find(".handlebar-recursive-replacement").text(buttonIdx);

				repetitionInputSetup($(this), buttonIdx + (startIdx || 1) - 1, false, iterationName);

				currentButton.attr("id", "remove-container-button__" + buttonIdx);

				//increment the number of remaining duplicates
				updateRemainingCounter($(this), 1);

				//if add button exists, decrement its index
				$(this).find("button[id^='add-container-button__']").attr("id", "add-container-button__" + buttonIdx);
			}

			if (lastIdx === index && $(this).find('button[id^="add-container-button__"]').length === 0) {
				//add an "Add" button if the last element doesn't already contain one
				let addButton = getButtonHTML("Add", buttonIdx, replicateContainer, $(this), iterationName);
				let addedAddButton = parentContainer.find('#hideAddButton').attr("value");
				if (addedAddButton === undefined) {
					currentButton.before(addButton);
				}
			}

			if (lastIdx === 0 && !hideFirst) {
				currentButton.remove();
			}
		});
	}
	if (sessionStorage.getItem(iterationName) == 1 && iterationName.includes('beneficiary')) {
		let attrVal = `${iterationName}-iteration_1_input_beneficiaryDistribution`;
		if ($('input[data-cmp-duplication-input-id="' + attrVal + '"]').val() != '100') {
			$('input[data-cmp-duplication-input-id="' + attrVal + '"]').val('100');
			sessionStorage.setItem(`${iterationName}-iteration_1_input_beneficiaryDistribution`, 100);
		}
	}
}
