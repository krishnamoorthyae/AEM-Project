$(function () {
	startShowHide();
	setupShowHideMutationsObserverFunctionality();
});

function setupShowHideMutationsObserverFunctionality( ) {
	let MutationObserver = window.MutationObserver || window.WebKitMutationObserver || window.MozMutationObserver;
	let body             = document.body;
	let observer         = new MutationObserver(function(mutations) {
		mutations.forEach(function(mutation) {
			// needed for IE
			let nodesArray = [].slice.call(mutation.addedNodes);
			if (nodesArray.length > 0) {
				nodesArray.forEach(function(addedNode) {
					if( $(addedNode).find("[data-show-hide-condition]").length ) {
						startShowHide( $(addedNode) );
					}
				});
			}
		});
	});

	observer.observe(body, {
		subtree: true,
		childList: true,
		characterData: true
	});
}

function startShowHide( node, inpName ){
	if( node?.length ) {
		handleShowHide( node );
	}
	else if( inpName ) {
		$(`body [data-show-hide-condition*="${inpName}"]`).each(function(idx) {
			handleShowHide($(this).closest(".container"));
		});
	}
	else {
		$("body [data-show-hide-condition]").each(function(idx) {
			handleShowHide($(this).closest(".container"));
		});
	}
}

function handleShowHide( container ) {
	let id = generateConfigurationUniqueId(),
		condition = container.find("[data-show-hide-condition]"),
		value = condition.attr("data-show-hide-condition");

	if( !condition.attr("data-show-hide-id") ) {
		condition.attr("data-show-hide-id", id);
	}

	if(value) {
		parseShowHideArgs( container, value);
	}
}

function parseShowHideArgs(container, authoredVal){
    let equations = authoredVal.split("[["),
	    evaluation = "";

	equations.forEach((value, index) => {
		if( !value.includes("~~") ){
			evaluation += value;
		}
		else {
			let splitVal = value.split("]]"),
				left = (splitVal[0]).trim().split("~~"),
				operand = (splitVal[1]).trim().split('~~'),
				right = (splitVal[2]).trim().split('~~');

			if( operand[1] === "nin" ) {
				evaluation += "!";
			}

			if( left[0] === "clientSession") {
				evaluation += `"${handleShowHideGetSessionItem( left[1] )}"`;
			}
			else {
				let inp = $(`[name="${left[1]}"]`),
					type = inp.attr("type") || inp[0].tagName?.toLowerCase();

				if( ["checkbox", "radio"].includes( type ) ) {
					inp = $(`[name="${left[1]}"]:checked`);
				}
				evaluation += `"${inp.val()}"`;

				function repreocessShowHide() {
					startShowHide( null, left[1] );
				}

				if( !hasHandler( inp[0], "change", "repreocessShowHide") ) {
					inp.on( "change input", repreocessShowHide);
				}
			}

			//add operands
			evaluation += getShowHideOperand( operand[1] );

			if( operand[1] !== "exists" ) {
				//add compare value
				evaluation += `"${right[1]}"`;
			}


			if( operand[1] === "nin" || operand[1] === "in" ) {
				evaluation += ")";
			}
		}
	});

	calculate(container, evaluation);
}

function hasHandler(element, eventName, handlerName){
	let found = false;
	if($._data(element, "events")?.[eventName]) {
		$._data(element, "events")[eventName].forEach(handler => {
			if (handler.handler.toString().includes( handlerName )) {
				found = true;
				return false;
			}
		});
	}

	return found;
}

function getShowHideOperand( key ) {
	switch (key) {
		case "eq":
			return "===";
		case "ne":
			return "!==";
		case "lt":
			return "<";
		case "lte":
			return "<=";
		case "gt":
			return ">";
		case "gte":
			return ">=";
		case "in":
			return ".includes(";
		case "nin":
			return ".includes(";
		default:
			return "";
	}
}

function handleShowHideGetSessionItem( searchName ) {
	let objPath = null;

	if( searchName.includes(".") ) {
		let arr = searchName.split(".");
		searchName = arr.shift();
		objPath = arr.join(".");
	}

	let sessionValue = sessionStorage.getItem( searchName );
	if( objPath ) {
		sessionValue = getObjectProperty( JSON.parse( sessionValue ), objPath );
	}
	return sessionValue;
}

function calculate(container, authoredVal){
	let id = container.find("> [data-show-hide-id]").attr("data-show-hide-id");

	if(eval(authoredVal)) {
		if( container.hasClass("hide") ) {
			container.removeClass("hide");

			let child =  $( window[id] );
			if ( container.find("> [data-show-hide-keep-html]").length) {
				container.find("> .cmp-container").removeClass("hide");
				container?.find("input:not([type='hidden']), textarea, select").each((idx, input) => {
					if ($(input).prop("data-required")) {
						$(input).removeProp("data-required");
						$(input).prop("required");
					}
				})
			}
			else {
				container.append( child );
			}
		}
	}
	else if ( container.is(":visible") || container.closest(".cmp-accordion__item:not([data-cmp-expanded])").length) {
		container.addClass("hide");

		beforeHideManageHTMLData( container );

		let child = container.find("> .cmp-container");
		if( child.length ) {
			if ( container.find("> [data-show-hide-keep-html]").length) {
				child.addClass("hide");
			}
			else {
				window[id] = child?.[0]?.outerHTML;
				child.remove();
			}
		}
	}
}

function beforeHideManageHTMLData( container ) {
	//removing all errors from the inputs
	container.find(".customErr").each((idx, elem) => {
		$(elem).remove();
		$(elem).closest(".fldErr").removeClass("fldErr");
	});

	container?.find("input:not([type='hidden']), textarea, select").each( (idx, input) => {
		if( $(input).attr("type") === "checkbox" || $(input).attr("type") === "radio" ) {
			$(input).removeAttr("checked");
			$(input).parent().removeClass("inputIsChecked");
		}
		else if($(input).attr("type")?.toLowerCase() === "text") {
			$(input).val("");
		}

		if($(input).prop("required")) {
			$(input).prop("data-required", true);
			$(input).removeProp("required");
		}
	});
}
