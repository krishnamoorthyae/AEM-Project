$(document).on('dialog-ready', function() {
	const featureDropDown = document.querySelector('coral-select[name = "./feature"]'),
		  actionTypeDropdown = document.querySelector('coral-select[name = "./actionType"]'),
		  actionTypeFFW = actionTypeDropdown?.closest('div.coral-Form-fieldwrapper');
    
	if(featureDropDown?.value){
		updateActionTypeDropdown(featureDropDown.value);
		
		if('sessionTransfer' !== featureDropDown.value) {
			setActionTypeDropdown();
		}
		
		featureDropDown.addEventListener('change', function(){
			updateActionTypeDropdown(featureDropDown.value);
		});
	}
	else {
		console.error('Error occurred: Features dropdown not found');
	}
	
	/*
	 * function updateActionTypeDropdown(featureValue) updates the actionType dropdown
	 * based on the selection of the features dropdown
	 * 
	 * @param featureValue a String object that contains the selected value from the features dropdown
	 * @return void
	 */

	function updateActionTypeDropdown(featureValue){
		if('sessionTransfer' === featureValue) {
			$(actionTypeFFW).hide();
		} 
		else {
			$(actionTypeFFW).show();
			executeGenericList(featureValue);
		}
	}
	
	/*
	 * function setActionTypeDropdown() will get the stored value from JCR and set it to
	 * the actionType dropdown on page load. This is needed as the options on the actionType 
	 * dropdown are populated dynamically after the dialog has loaded
	 *
	 * @param
	 * @return void
	 */
	function setActionTypeDropdown() {
		let currentComponentPath = document.querySelector('form.cq-dialog').getAttribute('action');
			
		$.ajax({
            url: currentComponentPath + '.1.json',
            type: 'GET',
            success: function (data) {
                actionTypeDropdown.value = data?.actionType;
            },
            error: function (error) {
				console.error('Error occurred: ', error.responseText);
			}
        });
	}
	
	/*
	 * function executeGenericList(featureValue) will make a call to get the values from the 
	 * respective generic list based on the selection of the features dropdown and populate 
	 * the options on the actionType dropdown from that. 
	 * 
	 * @param featureValue a String object that contains the selected value from the features dropdown
	 * @return void
	 */ 
	function executeGenericList(featureValue){
		let genericListUrl = '/bin/foundation/generic-list?list=/content/dam/generic-lists/config/dialog/form/container/action-types/'+featureValue;
        
		$.ajax({
            url: genericListUrl,
            type: 'GET',
            success: function (data) {
	            $(actionTypeFFW).show();
				actionTypeDropdown?.items?.clear();
		        data?.forEach(option => {
		        	const selectItem = new Coral.Select.Item();
		            selectItem.value = option?.value;
		            selectItem.content.textContent = option?.title
		            actionTypeDropdown?.items?.add(selectItem);
		        });
            },
            error: function (error) {
	            $(actionTypeFFW).hide();
				console.error('Error occurred: ', error.responseText);
			}
        });
	}
});