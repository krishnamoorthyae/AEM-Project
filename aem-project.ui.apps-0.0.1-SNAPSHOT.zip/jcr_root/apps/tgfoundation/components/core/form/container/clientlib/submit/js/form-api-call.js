function handleFormApiCall(currentForm) {
	let configId = currentForm.attr("data-api-config-id"),
		config = window[ configId ];

	if( config ) {
		const data = generateAjaxDataObject( config );
		data.selectors = $("#selectors")?.attr("value") || "";

		setTimeout( function() {
			$.ajax({
				type: config.method,
				url: config.endpoint,
				async: config.async || false,
				dataType: "json",
				data: data,
				success: (response) => {
					handleAjaxAfterSendFunctionCalls( config?.success, response );

					handleRedirection( currentForm );

					setTimeout( function() {
						window?.handleHideSpinner?.();
					}, 2000 );
				},
				error: (error) => {
					handleAjaxAfterSendFunctionCalls( config?.error, error );

					serviceErrorHandler( currentForm );

					window?.handleHideSpinner?.();
				}
			})
		}, 10)
	}
	else {
		window?.handleHideSpinner?.();
	}
}

function handleAjaxAfterSendFunctionCalls( config, variable ) {
	config?.forEach( item => {
		let parameters = [];
		item?.parameters?.split(",")?.forEach( param => {
			let type = param?.split(":")?.[0],
				val = param?.split(":")?.[1];

			if( "number" === type ) {
				parameters.push( Number( val ) );
			}
			else if ( "var" === type ) {
				parameters.push( variable );
			}
			else if ( "bool" === type ) {
				parameters.push( val === "true" );
			}
			else {
				parameters.push( val );
			}
		})
		window?.[item.function]?.(...parameters);
	})
}

function serviceErrorHandler( currentForm, messageNumber ) {
	let apiErrorSection = currentForm?.find("#api-error") || $('#api-error'),
		apiErrors = JSON.parse( sessionStorage.getItem( 'serviceAPIError' ) || '{}'),
		apiErrorLowerCase = {};

	messageNumber = messageNumber?.toString()?.toLowerCase() || "0";
	Object.keys(apiErrors).forEach(key => apiErrorLowerCase[key.toString().toLowerCase()] = apiErrors[key]);

	(messageNumber && apiErrorLowerCase.hasOwnProperty(messageNumber)) ?
		apiErrorSection.text(apiErrorLowerCase[messageNumber]) : apiErrorSection.text(apiErrors["0"]);

	let systemErrorParent = currentForm?.find("#systemError")?.closest(".container");
	systemErrorParent.removeClass('hide');

	apiErrorSection?.[0]?.scrollIntoView({behavior: "smooth", block: "center"});
}

function generateAjaxDataObject( config ) {
	let data = {
		"configFile": config.configFile,
		"jwt": config.jwt,
		"proxy": config.proxyPath,
	}

	if( config?.data?.length ) {
		data = createCustomApiDataParameters( data, config);
	}

	return data;
}

function createCustomApiDataParameters( data, config ) {
	config?.data?.forEach( item => {
		if( !item.isArrayTemplate ) {
			item?.object?.forEach( obj => {
				let topLevelObj = {
					[obj.key]: {}
				}

				obj?.value?.properties?.forEach( value => {
					let valObj = {}

					value?.value?.sessionNames?.forEach( sessItem => {
						if( sessItem in sessionStorage ) {
							valObj[ value.key ] = JSON.parse( sessionStorage.getItem( sessItem ) )?.[0] || "";
							return false;
						}
					})

					topLevelObj[ obj.key ] = {
						...topLevelObj[ obj.key ],
						...valObj
					}
				})

				if( typeof topLevelObj[ obj.key ] === typeof {} || typeof topLevelObj[ obj.key ] === typeof [] ) {
					topLevelObj[ obj.key ] = JSON.stringify( topLevelObj[ obj.key ] );
				}

				data = {
					...data,
					...topLevelObj
				}
			})
		}
	})

	return data;
}

function addSessionItem( name, value ) {
	sessionStorage.setItem( name, value );
}

function removeItem( name ) {
	sessionStorage.removeItem( name );
}
