function handleFormConfigurationJson() {
	$("form").each( (idx, form) => {
		let $form = $(form),
			parent = $form.parent(),
			apiConfig = parent.find("[data-api-config]");

		if( apiConfig.length ) {
			let configId = generateConfigurationUniqueId();

			window[ configId ] = JSON.parse(apiConfig.attr("data-api-config"));

			$form.attr("data-api-config-id", configId );
			apiConfig.remove();
		}
	});
}

