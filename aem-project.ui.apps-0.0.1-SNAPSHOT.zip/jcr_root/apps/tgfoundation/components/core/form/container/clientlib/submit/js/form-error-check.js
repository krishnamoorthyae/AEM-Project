function formHasErrors( currentForm ) {
	// Focus on the first field error on form
	if ( currentForm.find(".customErr").length ) {
		const element = currentForm.find(".customErr");
		let parentAccordion = element.closest(".cmp-accordion");
		if( parentAccordion.length && !parentAccordion.find("> .cmp-accordion__item[data-cmp-expanded]").length) {
			parentAccordion.find("> .cmp-accordion__item > .cmp-accordion__header > .cmp-accordion__button").trigger("click");
		}
		element?.[0]?.parentElement?.scrollIntoView({behavior: "smooth"});

		window?.handleHideSpinner?.();
		return true;
	}
	return false
}

function setAPIErrorList( currentForm ) {
	var errorMap = {};
	currentForm.find("select[name='service-api-error']").find('option').each(function () {
		errorMap[$(this).text().trim()] = $(this).val();
	});
	if(Object.keys(errorMap).length){
		sessionStorage.setItem("serviceAPIError", JSON.stringify(errorMap));
	}
}

function handleFormInputValidation( currentForm, componentList ) {
	//Running all Default validations
	componentList.forEach( item => {
		window?.[`handleDefault${item}Validation`]?.(currentForm);
	})

	//Running all custom validations
	componentList.forEach( item => {
		window?.[`handleCustom${item}Validation`]?.(currentForm);
	})
}
