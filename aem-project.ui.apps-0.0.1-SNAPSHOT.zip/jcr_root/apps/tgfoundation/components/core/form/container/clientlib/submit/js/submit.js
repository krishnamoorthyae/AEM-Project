$(document).on("ready", function() {
	handleFormConfigurationJson();

	handleFormSubmit();
})

function handleFormSubmit() {
	$('[type="submit"]').on("click", function(event) {
		event.preventDefault();

		setupPurchasePathCookie()

		let currentForm = $(event.target).closest("form");

		let componentList = ["Hidden", "Text", "Date", "Dropdown", "Checkbox", "Radio", "MultiSelect", "Currency", "Email", "Tel", "Password", "Number"]

		setAPIErrorList( currentForm );

		window?.handleShowSpinner?.();

		handleFormInputValidation( currentForm, componentList );

		if( !formHasErrors( currentForm ) ) {
			handleItemsToSessionStorage( currentForm, componentList );

			handleFormApiCall(currentForm);
		}
	})
}

function handleItemsToSessionStorage( currentForm, componentList ) {
	//Running all Default storage
	componentList.forEach( item => {
		window?.[`handleDefault${item}SessionStorage`]?.(currentForm);
	})

	//Running all custom storage
	componentList.forEach( item => {
		window?.[`handleCustom${item}SessionStorage`]?.(currentForm);
	})
}

function handleRedirection( currentForm ){
	let currentPage = $("#current-page-path").attr("value");
	sessionStorage.setItem(currentPage, "done");
	sessionStorage.setItem("form-handler", "true");
	currentForm?.submit(); 
}

