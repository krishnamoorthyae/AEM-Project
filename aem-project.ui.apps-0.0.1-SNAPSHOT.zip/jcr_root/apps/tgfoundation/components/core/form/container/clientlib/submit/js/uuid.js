function setupPurchasePathCookie() {
	let uuid = sessionStorage['uuid'] ||
		'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
			let r = Math.random()*16|0, v = c === 'x' ? r : (r&0x3|0x8);
			return v.toString(16);
		});

	sessionStorage.setItem("uuid", uuid);
	if( !("uuid" in sessionStorage) ) {
		window.isOriginal = true;
	}
	document.cookie="uuid=" + uuid + ";path=/";

	// code below can be used to get a specific cookie
	// document.cookie.match("(^|[^;]+)\s*" + "uuid" + "\s*=\s*([^;]+)")[2]

	//Changes uuid on cookie for the active tab
	$(window).on("click focus blur", function() {
		if( !document.hidden && localStorage.getItem("uuidTGCommonCookieLock") !== "true") {
			document.cookie = "uuid=" + sessionStorage.getItem("uuid") + ";path=/";
		}
	})
}
