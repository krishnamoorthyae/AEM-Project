function handleDefaultHiddenSessionStorage(form) {
	form.find('input[type="hidden"]').each( (idx, elem) => {
		let $elem = $(elem),
			name = $elem.attr("name"),
			id = $elem.attr("id");

		if( name === "form-custom-hidden" ) {
			sessionStorage.setItem( id, $elem.attr("value") );
		}
	});
}
