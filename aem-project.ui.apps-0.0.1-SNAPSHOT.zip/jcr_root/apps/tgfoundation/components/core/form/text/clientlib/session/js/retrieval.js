$(document).on("ready", function() {
	handleFormTextSessionRetrieval();
})

function handleFormTextSessionRetrieval() {
	$('.text input').each( (idx, elem) => {
		let $elem = $(elem),
			name = $elem.attr( "name" );

		if ( name in sessionStorage ) {
			let values = JSON.parse( sessionStorage.getItem( name ) ),
				inputs = $(`[name="${name}"]`);

			values.forEach( (val, index) => {
				inputs.eq(index).val( val );
			})
		}
	});
}
