function handleDefaultTextSessionStorage(form) {
	let nameCheck = [];

	form.find('input[type="text"]:visible').each( (idx, elem) => {
		let $elem = $(elem),
			name = $elem.attr("name"),
			id = $elem.attr("id");

		if( !nameCheck.includes( name ) ) {
			nameCheck.push( name );

			let valueArr = generateArrayForSessionStorage( name, form );

			sessionStorage.setItem(name, JSON.stringify( valueArr ) );
			sessionStorage.setItem(name + "_label", $(`label[for="${id}"]`).text());
		}
	});
}

function generateArrayForSessionStorage( name, form ) {
	let itemList = form.serializeArray().filter( item => item.name === name ),
		inputList = form.find(`[type="text"][name="${name}"]:visible`),
		valueArr = [];

	itemList.forEach( item => {
		let includeVal = false;

		inputList.each( (idx, elem) => {
			if( $(elem).val() === item.value ) {
				includeVal = true;
				return false;
			}
		})

		if( includeVal ) {
			valueArr.push( item.value );
		}
	})

	return valueArr;
}
