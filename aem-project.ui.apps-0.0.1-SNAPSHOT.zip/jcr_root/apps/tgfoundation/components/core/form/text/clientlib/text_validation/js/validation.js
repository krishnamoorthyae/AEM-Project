$(document).on("ready", function() {
	removeAllTextInputErrors();
})

function removeAllTextInputErrors( ) {
	$(document).find("input[type='text']").each( (idx, elem) => {
		let $elem = $(elem),
			parent = $elem.parent('.cmp-form-text');

		removeFormTextError( parent );
	});
}

function handleDefaultTextValidation( form ) {
	form.find("input[type='text']").each( (idx, elem) => {
		let $elem = $(elem);

		if ( $elem.attr('required') && $elem.is(":visible")  ) {
			let parent = $elem.parent('.cmp-form-text'),
				requiredMsg = parent.attr('data-cmp-required-message') || "",
				val = $elem.val(),
				name = $elem.attr("name");

			// Remove customer errors before validation checks
			removeFormTextError( parent );

			if (!val) {
				addFormTextError(parent, $elem, requiredMsg);
			}

			if ( name === "confirmEmailAddress" && form.find("[name='email']").val() !== val ) {
				addFormTextError(parent, $elem, requiredMsg);
			}
		}
	});
}
