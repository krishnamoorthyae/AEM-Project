function removeFormTextError (elem) {
	elem.find('.customErr').remove();
	elem.removeClass('fldErr');
}

function addFormTextError(parent, elem, requiredMsg) {
	parent.addClass('fldErr');
	$('<div class="customErr">' + requiredMsg + '</div>').insertAfter( elem );
}
