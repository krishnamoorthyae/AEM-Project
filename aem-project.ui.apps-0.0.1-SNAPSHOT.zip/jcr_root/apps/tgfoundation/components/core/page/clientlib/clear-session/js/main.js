$(document).on("ready", function() {
	sessionStorageClearFunctionality();
})

function sessionStorageClearFunctionality() {

    let timeOutVal = getTimeOutValue();
    setTimeout(function () {
        //clear session storage according to exclude and include list 
        clearSessionStorage ();
      }, timeOutVal)
    
}

function getTimeOutValue(){
    return ($("#schemeName").attr("value")) ? ($("#schemeName").attr("value")) : 0; 
}


function clearSessionStorage (){

    if (!checkIfClearFieldsList() && !checkIfExcludeList()){
        clearAllSession();
    }

    if(checkIfClearFieldsList()){
        clearSpecificFieldsFromSession();
    }

    if(checkIfExcludeList()){
        excludeValuesFromSessionClear();
    }
    
}

function clearAllSession (){
    sessionStorage.clear();
}

function checkIfClearFieldsList(){
    return ($("#clearSessionFields").attr("value"));
}

function checkIfExcludeList(){
    return ($("#excludeFieldsFromClearing").attr("value"));
}

function clearSpecificFieldsFromSession(){
    
    let include = true; 
    helperClearListFunction ("#clearSessionFields", include);

}

function excludeValuesFromSessionClear(){ 
    
    let exclude = false;
    helperClearListFunction ("#excludeFieldsFromClearing", exclude)
}

function helperClearListFunction (listName, includeOrNot){
    for (const elem of $("#" + listName).attr("value").split(',')) { 
        let value = elem.split('=');
        for(let field in sessionStorage){
            if(helperIncludeOrNotFunction(field, value[0], includeOrNot)){
                sessionStorage.removeItem(field); 
            }
        }
    }
}

function helperIncludeOrNotFunction(field, value, includeOrNot){
   return (includeOrNot)? (field.includes(value)) : (!field.includes(value));
}

