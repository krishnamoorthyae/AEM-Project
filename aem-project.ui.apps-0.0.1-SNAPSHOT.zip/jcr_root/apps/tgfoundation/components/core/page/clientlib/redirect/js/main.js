$(document).on("ready", function() {
	progressRedirect();
})


function progressRedirect() {
    duplicateTabRedirect();
    /** Purchase Path Redirect based on Progress -----------------------------------------------------------------------*/
    let queryParams = sessionStorage.getItem("queryParams"),
	    pageInProgress = 'In Progress',
	    currentPage = $("#current-page-path").attr("value"),
	    currentPageStatus = sessionStorage.getItem(currentPage),
	    mainLandingPage = $('#pagePropLandingPage').attr("value");

    if (sessionStorage.getItem("form-handler") === "true") {
        pageInProgress = currentPage;
        sessionStorage.setItem("In Progress", pageInProgress);
    }
    if (mainLandingPage && currentPage !== mainLandingPage) {
        if (!pageInProgress) {
            window.location.href = (queryParams != null && queryParams !== "null") ?
                addHtmlExtension(mainLandingPage) + "?" + queryParams : addHtmlExtension(mainLandingPage);
        }
        else if (currentPageStatus !== "done" && pageInProgress !== currentPage && !currentPage.endsWith(pageInProgress)) {
            window.location.href = (queryParams != null && queryParams !== "null") ?
                addHtmlExtension(pageInProgress) + "?" + queryParams : addHtmlExtension(pageInProgress);
        }
    }
}


function addHtmlExtension(urlPath) {
	return (urlPath.startsWith("/content/") && !urlPath.endsWith(".html")) ? urlPath + ".html" : urlPath;
}

function duplicateTabRedirect() {
	if( "uuid" in sessionStorage ) {
		const broadcast = new BroadcastChannel(sessionStorage.getItem("uuid"))
		broadcast.addEventListener("message", function listener(event) {
			if (event.data === `I am First`) {
				broadcast.postMessage(`Sorry! Already open`);
			}
			if (event.data === `Sorry! Already open`) {
				if ($('input[type="hidden"][name="duplicateTabMessage"]').length) {
					alert($('input[type="hidden"][name="duplicateTabMessage"]').val());
				}
				sessionStorage.clear();
				broadcast.close();
				progressRedirect();
			}
		});
		broadcast.postMessage('I am First');
	}
}
