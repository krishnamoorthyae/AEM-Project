$(document).on("ready", function() {
	// setupSelectorsCo0kie();
})

function setupSelectorsCo0kie() {
	let selectors = $("#selectors").attr("value");

	if( selectors ) {
		document.cookie = "selectors=" + selectors + ";path=/";
	}
	else {
		document.cookie = "selectors=;path=/;expires=Thu, 01 Jan 1970 00:00:01 GMT";
	}
}

