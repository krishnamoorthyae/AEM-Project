$(document).on("ready", function() {
	sessionStorageCheck();
})


function sessionStorageCheck() {
    let modal = $('meta[name="sessionModal"]'),
        timeoutModal = $('meta[name="timeoutModal"]'),
        time = $('meta[name="modalTime"]'),
        sessionTimeout = $('meta[name="sessionTimeout"]'),
        modalId = modal.attr("value"),
        cookieParts = document.cookie.split("; wcmmode="),
        cookie = cookieParts[0];

    if (cookieParts.length === 2) {
        cookie = cookieParts.pop().split(';').shift()
    }

    if (modal.length && time.length && sessionTimeout.length && cookie !== "edit") {
        let timeVal = time.attr("value"),
            sessionTimeoutVal = sessionTimeout.attr("value");
        sessionStorage.removeItem("serverTimeoutFunc");

        if (!isNaN(timeVal) && !isNaN(sessionTimeoutVal)) {
            setTimeout(function () {
                // This is a possible solution for modal check
                // let oldModal = $('.modal.fade.in');
                // oldModal.each( (idx, elem) => $(elem).modal("hide") );
                // $(`#${modalId}`).on('hidden.bs.modal', function() {
                //     $(`#${modalId}`).off('hidden.bs.modal');
                //     oldModal.each( (idx, elem) => $(elem).modal())
                // });

                $(`#${modalId}`).modal();
                // $(`#${modalId}`).css({"z-index":100000});
                // $(".modal-backdrop.fade.in").last().css({"z-index":99999});

                let timeoutFunc = setTimeout(function () {
                    $(`#${modalId}`).modal("hide");
                    resetSessionStorage();
                }, (parseInt(sessionTimeoutVal) - parseInt(timeVal)) * 1000);

                sessionStorage.setItem("serverTimeoutFunc", timeoutFunc);
                $(`#${modalId} [name="sessionRefresh"], #${modalId} [id="sessionRefresh"]`).on("click", function () {
                    $(`#${modalId} [name="sessionRefresh"], #${modalId} [id="sessionRefresh"]`).off("click");
                    clearTimeout(timeoutFunc);
                    serverSessionAction("refresh");
                });
            }, parseInt(timeVal) * 1000)
        }
    }

    function resetSessionStorage() {
        serverSessionAction("reset").then(unused => {
            let queryParams = sessionStorage.getItem("queryParams");
            sessionStorage.clear();

            if (timeoutModal.length) {
                let timeoutModalId = timeoutModal.attr("value");
                $(`#${timeoutModalId}`).modal();
                // $(`#${timeoutModalId}`).css({"z-index":100000});
                // $(".modal-backdrop.fade.in").last().css({"z-index":99999});
                $(`#${timeoutModalId}`).on('hidden.bs.modal', function () {
                    $(`#${timeoutModalId}`).off('hidden.bs.modal');
                    window.location.href = (queryParams != null && queryParams !== "null") ?
                        mainLandingPage + ".html?" + queryParams : mainLandingPage + ".html";
                });
            }
            else {
                window.location.href = (queryParams != null && queryParams !== "null") ?
                    mainLandingPage + ".html?" + queryParams : mainLandingPage + ".html";
            }
        });
    }

    function serverSessionAction(action) {
        //Changes uuid on cookie for the active tab
        document.cookie = "uuid=" + sessionStorage.getItem("uuid") + ";path=/";
        return $.ajax({
            url: '/bin/common/session-checker',
            type: 'POST',
            data: {
                'action': action,
            },
            success: function (response) {
                $(`#${modalId}`).modal("hide");
                if (action !== "reset") {
                    sessionStorageCheck();
                }
            },
            error: function () {
            }
        });
    }

    $(document).on('hidden.bs.modal', '.modal',
        () => $('.modal:visible').length && $(document.body).addClass('modal-open'));

    $(document).on('show.bs.modal', '.modal', function () {
        let stickyZIndex = 0;
        if( $('.sticky-header-functionality, .sticky-header-mobile-functionality, .sticky-header-desktop-functionality').length ) {
            stickyZIndex = 100000000;
        }
        const zIndex = stickyZIndex + 1040 + 10 * $('.modal:visible').length;
        $(this).css('z-index', zIndex);
        setTimeout(() => $('.modal-backdrop').not('.modal-stack').css('z-index', zIndex - 1).addClass('modal-stack'));
    });
}