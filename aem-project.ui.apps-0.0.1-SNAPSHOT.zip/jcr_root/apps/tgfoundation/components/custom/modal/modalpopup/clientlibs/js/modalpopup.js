function setCookie(cname, cvalue, exdays) {
  var expires = "";
  if (exdays) {
    var d = new Date();
    d.setTime(d.getTime() + (exdays * 24 * 60 * 60 * 1000));
    expires = "expires=" + d.toUTCString() + "; ";
  }
  document.cookie = cname + "=" + cvalue + "; " + expires + "path=/";
}

function getCookie(cname) {
  var name = cname + "=";
  var ca = document.cookie.split(';');
  for (var i = 0; i < ca.length; i++) {
    var c = ca[i];
    while (c.charAt(0) == ' ') {
      c = c.substring(1);
    }
    if (c.indexOf(name) == 0) {
      return c.substring(name.length, c.length);
    }
  }
  return "";
}

function removeCookie(cname) {
  setCookie(cname, '', 0);//clears value and will expire session close
}

try {
  //~doc.ready isn't available yet (doesn't work in older IEs)
  document.addEventListener('DOMContentLoaded', function () {
    try {
      //setup cookie onclick events
      //sessionStorage doesn't support new tabs
      //localStorage doesn't suport expires functionality

      $('.modal[data-modal-single-view]').each(function (i) {
        var temp = $(this);

        temp.find('.data-modal-single-view-button').click(function (e) {
          if (temp.attr('data-modal-cookie-duration') != 0) {
            setCookie(temp.attr('data-modal-single-view'), 'shown', temp.attr('data-modal-cookie-duration'));
          }
          else {
            setCookie(temp.attr('data-modal-single-view'), 'shown');
          }
        });
        //show on page load:
        //use logic to search for Granite and omit edit pages
        if (getCookie(temp.attr('data-modal-single-view')).toLowerCase() != "shown" && (typeof Granite == "undefined" || typeof Granite.author === "undefined")) {
          temp.modal('show');
        }
      });
      $('button[data-modal-single-view-clear], a[data-modal-single-view-clear]').click(function (i) {
        removeCookie($(this).attr('data-modal-single-view-clear'));
      });

    } catch (err) {
      console.log('covid modal addEventListener error: ' + err);
    }
  }, false);
} catch (err) {
  console.log('covid modal error: ' + err);
}

