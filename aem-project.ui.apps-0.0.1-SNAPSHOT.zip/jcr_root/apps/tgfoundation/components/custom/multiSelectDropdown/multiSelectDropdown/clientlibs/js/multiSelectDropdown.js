$(document).ready(function() {
	let elements = {
		fetch: function(selector, index) {
			let myMulti = document.querySelectorAll(selector)[index];
			this.init(myMulti);
			return myMulti;
		},
		get: function(selector, index) {
			let ele = document.querySelectorAll('#myMulti');
			let eleOptions = ele[index].querySelectorAll('option');
			for (let i = 0; i < eleOptions.length; i++) {
				this.init(eleOptions[i]);
			}
			return eleOptions;
		},
		template: function(html) {
			let template = document.createElement('div');
			template.innerHTML = html.trim();
			return this.init(template.childNodes[0]);
		},
		init: function(ele) {
			ele.on = function(event, func) {
				this.addEventListener(event, func);
			}
			return ele;
		}
	};

	//Build the plugin
	let drop = function(info) {
		let o = {
			options: info.options,
			selected: info.selected || [],
			preselected: info.preselected || [],
			open: false,
			html: {
				select: elements.fetch(info.selector, info.multiIndex),
				options: elements.get(info.selector + ' option', info.multiIndex),
				parent: undefined,
			},
			init: function() {
				//Setup Drop HTML
				this.html.parent = elements.fetch(info.selector, info.multiIndex).parentNode
				this.html.drop = elements.template('<div class="drop"></div>')
				this.html.dropDisplay = elements.template('<div class="drop-display">Display</div>')
				this.html.dropOptions = elements.template('<div class="drop-options" id="valueList"">Options</div>')
				this.html.dropScreen = elements.template('<div class="drop-screen"></div>')

				this.html.parent.insertBefore(this.html.drop, this.html.select)
				this.html.drop.appendChild(this.html.dropDisplay)
				this.html.drop.appendChild(this.html.dropOptions)
				this.html.drop.appendChild(this.html.dropScreen)
				//Hide old select
				this.html.drop.appendChild(this.html.select);

				//Core Events
				let that = this;
				this.html.dropDisplay.on('click', function() {
					this.parentElement.classList.add("open");
				});
				this.html.dropScreen.on('click', function() {
					that.toggle()
				});
				//Run Render
				this.load()
				this.preselect()
				this.render();
				//this.filterFunction();
			},
			toggle: function() {
				this.html.drop.classList.remove('open');
                if(this.html.drop.querySelectorAll('#cmp-Input')[0].value.length > 0){
                    this.html.drop.querySelectorAll('#cmp-Input')[0].value = '';
                    this.html.drop.querySelectorAll('.drop-options a').forEach(anchorOption => { anchorOption.removeAttribute('style'); });

                }
			},
			addOption: function(e, element) {
				let index = Number(element.dataset.index),
				 	maxSelected = this.html.parent.parentElement.children[0].children[1].children[0].attributes[1].value,
				 	optAdd = this.html.dropDisplay.querySelectorAll('span[id="optadd"]'),
					optAddlength = optAdd.length,
                    optAddCountryCode = (optAddlength != 0) ? optAdd[0].getAttribute("selectedCountryCode") : null,
                    opt = this.html.dropDisplay.querySelectorAll('span[id="opt"]'),
					optLength = opt.length,
                    lastElement = optLength > 0 ? opt[opt.length - 1] : null,
                    lastElementCountryCode = lastElement ? lastElement.getAttribute('selectedcountrycode') : null,
                    $noOfValuesSelected = optAddlength + optLength + 1,
                    validate = optAddCountryCode ? optAddCountryCode : lastElementCountryCode,
                    thisParent = this.html.drop.parentElement,
                    domesticList = this.html.drop.parentElement.querySelectorAll('[name = "multi-selected-list"]')[0].value,
					selectedCountryCode = element.getAttribute("selectedCountryCode");

                if (maxSelected == 1){
					$('.drop').removeClass("open");
                    if ($noOfValuesSelected>1){  
                           this.swapCase(e, element);
                           $('.drop').removeClass("open");
							return false;
                    }
                }

				if ($noOfValuesSelected > maxSelected) {
					 $(thisParent).each(function() {
							$(this).find('.customErr').remove();
						let limitedDisplayMsg = $(this).find('select').attr('data-select-limitedDisplay-message');
						$(this).addClass('fldErr');
						$('<div class="customErr">' + limitedDisplayMsg + '</div>').appendTo($(this));
						$('.drop').removeClass("open");
						})
					return false;
				}

				$(thisParent).find('.customErr').remove();
				$(thisParent).removeClass('fldErr');

				if ($noOfValuesSelected > 1) {

					let cbChk = false,
						req = false;

					if ((domesticList.includes(selectedCountryCode) && !(domesticList.includes(validate))) || (!(domesticList.includes(selectedCountryCode)) && (domesticList.includes(validate)))) {
						cbChk = true;
						$(thisParent).each(function() {
							$(this).find('.customErr').remove();

							if ($(this).find('select[multiple]').attr('errorCheck')) req = true;
							let nullMsg = $(this).find('select').attr('data-select-custom-error-message');

							if (req == true && cbChk == true) {
								$(this).addClass('fldErr');
								$('<div class="customErr">' + nullMsg + '</div>').appendTo($(this));
								$('.drop').removeClass("open");
							}
						})
						return false;
					}
				}
				this.clearStates()
				this.selected.push({
					index: Number(index),
					state: 'add',
					removed: false
				})
				this.options[index].state = 'remove';
                if (maxSelected != 1){
				$(element).parents('.multiSelectDropdown').find('#myMulti')[0].options[index].selected = true;
                }
				this.render()
				this.removeplaceholder()
			},
			removeOption: function(e, element) {
				e.stopPropagation();
				this.clearStates()
				let index = Number(element.dataset.index);
				this.selected.forEach(function(select) {
					if (select.index == index && !select.removed) {
						select.removed = true
						select.state = 'remove'
					}
				})
				this.options[index].state = 'add'
				$(element).parents('.multiSelectDropdown').find('#myMulti')[0].options[index].selected = false;
				this.render()
				this.addplaceholder()
				let thisParent = this.html.drop.parentElement;
				$(thisParent).find('.customErr').remove();
				$(thisParent).removeClass('fldErr');
			},
			load: function() {
				this.options = [];
				for (let i = 0; i < this.html.options.length; i++) {
					let option = this.html.options[i]
					this.options[i] = {
						html: option.innerHTML,
						value: option.value,
						selected: option.selected,
						state: ''
					}
				}
			},
            swapCase: function(e,element) {
				this.clearStates()
                let index = Number(element.dataset.index);
                this.selected.forEach(function(select) {
					if (select.index != index && !select.removed) {
						select.removed = true
						select.state = 'remove'
					}
                });
				this.options.forEach(function(select) {
					if (select.index != index  && !select.removed) {
						select.removed = false
						select.state = 'add'
					}
                }); 
				$(element).parents('.multiSelectDropdown').find('#myMulti')[0].options[index].selected = true;               
				this.render()				
				this.addOption(e, element)
			},
			preselect: function() {
				let that = this;
				this.selected = [];
				this.preselected.forEach(function(pre) {
					that.selected.push({
						index: pre,
						state: 'add',
						removed: false
					})
					that.options[pre].state = 'remove';
				})
			},
			render: function() {
				this.renderDrop()
				this.renderOptions()
			},
			renderDrop: function() {
				let that = this,
					parentHTML = elements.template('<div></div>'),
					inputTag = elements.template('<input type="text" id="cmp-Input" class="inputField">'),
					placehold = this.html.parent.parentElement.children[0].children[1].children[0].attributes[2].value;
				this.selected.forEach(function(select, index) {
					let option = that.options[select.index],
						childHTML = elements.template('<span id = "opt' + select.state + '" tabindex="-1" class="item ' + select.state + '" selectedCountryCode="' + option.value + '">' + option.html + '</span>'),
						childCloseHTML = elements.template(
						'<i class="material-icons btnclose" data-index="' + select.index + '">X</i></span>');
					childCloseHTML.on('click', function(e) {
						that.removeOption(e, this)
					})
					childHTML.addEventListener('keydown', function(e) {
						let key = e.key;
						if (key == "Delete") {
							that.removeOption(e, this.querySelector('i'));
							let dropDisplay = document.querySelectorAll('.drop-display')[info.multiIndex],
								dropDisplaySelected = dropDisplay.querySelectorAll('span:not([class*="hide"]):not([class*="remove"])');
							if (dropDisplaySelected.length > 0) {
								dropDisplaySelected[dropDisplaySelected.length - 1].focus();
							}
						} else if (key == "ArrowLeft") {
							let currentDataIndex = this.querySelector('i').getAttribute('data-index'),
								dropDisplay = document.querySelectorAll('.drop-display')[info.multiIndex],
								currValue = dropDisplay.querySelectorAll('span:not([class*="hide"]):not([class*="remove"]) i[data-index = "' + currentDataIndex + '"]');
							currValue.forEach(span => {
								let parentSpan = span.parentNode,
									previousElement = parentSpan.previousElementSibling;
								while (previousElement) {
									if (!previousElement.classList.contains('hide') && !previousElement.classList.contains('remove')) {
										previousElement.focus();
										break;
									}
									previousElement = previousElement.previousElementSibling;
								}
							});
						} else if (key == "ArrowRight") {
							let currentDataIndex = this.querySelector('i').getAttribute('data-index'),
								dropDisplay = document.querySelectorAll('.drop-display')[info.multiIndex],
								currValue = dropDisplay.querySelectorAll('span:not([class*="hide"]):not([class*="remove"]) i[data-index = "' + currentDataIndex + '"]');
							currValue.forEach(span => {
								let parentSpan = span.parentNode,
									nextElement = parentSpan.nextElementSibling;
								while (nextElement) {
									if (!nextElement.classList.contains('hide') && !nextElement.classList.contains('remove')) {
										nextElement.focus();
										break;
									}
									nextElement = nextElement.nextElementSibling;
								}
							});
						}
						if (key === "ArrowDown") {
							e.preventDefault();
							let dropOptions = document.querySelectorAll('.drop-options')[info.multiIndex],
								dropOptionsAnchor = dropOptions.querySelectorAll('a:not([class*="remove"]):not([class*="hide"]):not([style*="display: none"])');
							dropOptionsAnchor[0].focus();
						}
						if (key === "ArrowUp") {
							e.preventDefault();
						}
					});
					childHTML.appendChild(childCloseHTML)

					parentHTML.appendChild(childHTML)

				})

				this.html.dropDisplay.innerHTML = '';
				parentHTML.appendChild(inputTag);
				this.html.dropDisplay.appendChild(parentHTML)

				if (that.selected.length === 0) {
					this.html.dropDisplay.getElementsByClassName('inputField')[0].setAttribute("placeholder", placehold);
				} else {
					this.html.dropDisplay.getElementsByClassName('inputField')[0].setAttribute("placeholder", "");
				}
			},
			renderOptions: function() {
				let that = this,
					parentHTML = elements.template('<div></div>')
				this.options.forEach(function(option, index) {
					let childHTML = elements.template('<a data-index="' + index + '" tabindex="-1" class="' + option.state + '" selectedCountryCode="' + option.value + '">' + option.html + '</a>');
					childHTML.on('click', function(e) {
						that.addOption(e, this)
					})
					childHTML.addEventListener('keydown', function(e) {
						let key = e.key;
						if (key == "Enter") {
							e.preventDefault();
							that.addOption(e, this);
							let dropDisplay = document.querySelectorAll('.drop-display')[info.multiIndex],
								dropDisplaySpan = dropDisplay.querySelectorAll('span');
							if (dropDisplaySpan.length > 0) {
								dropDisplaySpan[dropDisplaySpan.length - 1].focus();
							}
						}

						if (key === "ArrowDown") {
							event.preventDefault();
							let dropOptions = document.querySelectorAll('.drop-options')[info.multiIndex],
								dropOptionsAnchor = dropOptions.querySelectorAll('a:not([class*="remove"]):not([class*="hide"]):not([style*="display: none"])'),
								currentIndex = Array.from(dropOptionsAnchor).findIndex(option => option === document.activeElement),
								nextIndex = currentIndex === dropOptionsAnchor.length - 1 ? 0 : currentIndex + 1;
							dropOptionsAnchor[nextIndex].focus();
						}
						if (key === "ArrowUp") {
							event.preventDefault();
							let dropOptions = document.querySelectorAll('.drop-options')[info.multiIndex],
								dropOptionsAnchor = dropOptions.querySelectorAll('a:not([class*="remove"]):not([class*="hide"]):not([style*="display: none"])'),
								currentIndex = Array.from(dropOptionsAnchor).findIndex(option => option === document.activeElement),
								previousIndex = currentIndex === 0 ? dropOptionsAnchor.length - 1 : currentIndex - 1;
							if (currentIndex == 0) {
								let dropDisplay = document.querySelectorAll('.drop-display')[info.multiIndex],
									dropOptionsInputTag = dropDisplay.querySelectorAll('input')[0];
								dropOptionsInputTag.focus();
							} else {
								dropOptionsAnchor[previousIndex].focus();
							}
						}
						if (event.key === "Tab") {
                            if (event.target.parentElement.parentElement.parentElement.classList.contains('open')) {
                                event.target.parentElement.parentElement.parentElement.classList.remove('open');
                                if(event.target.parentElement.parentElement.parentElement.querySelectorAll('#cmp-Input')[0].value.length > 0){
                                    event.target.parentElement.parentElement.parentElement.querySelectorAll('#cmp-Input')[0].value = '';
                                    event.target.parentElement.parentElement.parentElement.querySelectorAll('.drop-options a').forEach(anchorOptions => { anchorOptions.removeAttribute('style'); });
                                }
                            }
                        }

					});
					parentHTML.appendChild(childHTML)
				})
				this.html.dropOptions.innerHTML = '';
				this.html.dropOptions.appendChild(parentHTML)
			},
			removeplaceholder: function() {
				let $valuesSelected = this.html.dropDisplay.innerText.split("X").length - 1;
				if ($valuesSelected > 0) {
					this.html.dropDisplay.getElementsByClassName('inputField')[0].setAttribute("placeholder", "");
				}
			},
			addplaceholder: function() {
				let $valueSelected = this.html.dropDisplay.innerText.split("X").length,
					placehold = this.html.parent.parentElement.children[0].children[1].children[0].attributes[2].value;

				if ($valueSelected == 1) {
					this.html.dropDisplay.getElementsByClassName('inputField')[0].setAttribute("placeholder", placehold);
				} else {
					this.html.dropDisplay.getElementsByClassName('inputField')[0].setAttribute("placeholder", "");
				}
			},

			clearStates: function() {
				let that = this;
				this.selected.forEach(function(select, index) {
					select.state = that.changeState(select.state)
				})
				this.options.forEach(function(option) {
					option.state = that.changeState(option.state)
				})
			},
			changeState: function(state) {
				switch (state) {
					case 'remove':
						return 'hide'
					case 'hide':
						return 'hide'
					default:
						return ''
				}
			},
			isSelected: function(index) {
				let check = false
				this.selected.forEach(function(select) {
					if (select.index == index && select.removed == false) check = true
				})
				return check
			}

		};
		o.init();
		return o;
	}

	let myMultielements = document.querySelectorAll("#myMulti");
	myMultielements.forEach(function(element, index) {
        let thisUniqueId = element.getAttribute('uniqueId'),
            optionsStored = JSON.parse(sessionStorage.getItem(element.getAttribute('name') + '_multi')),
            sessionUniqueId = sessionStorage.getItem('uniqueId'),
            indexValue = [];
        if((optionsStored) && (thisUniqueId === sessionUniqueId)){
			for (let i = 0; i < optionsStored.length; i++) {
				indexValue.push(optionsStored[i].index);
			}
        }
		let myDrop = new drop({
			selector: '#myMulti',
			preselected: indexValue,
			multiIndex: index
		});
	});

	let parentInputs = document.querySelectorAll('.drop-display');

	function filterFunction(event) {
		let input, filter, ul, li, a, i,div;
		filter = event.target.value.toUpperCase();
		div = event.target.parentElement.parentElement.parentElement.querySelectorAll('.drop-options')[0];
		a = div.getElementsByTagName("a");
		for (i = 0; i < a.length; i++) {
			txtValue = a[i].textContent || a[i].innerText;
			if (txtValue.toUpperCase().indexOf(filter) > -1) {
				a[i].style.display = "";
			} else {
				a[i].style.display = "none";
			}
		}
	}
	parentInputs.forEach(function(element) {
		element.addEventListener('input', function(event) {
			if (event.target.classList.contains('inputField')) {
				filterFunction(event);
			}
		});
		element.addEventListener('keydown', function(event) {
			if (event.target.classList.contains('inputField')) {
				if (event.key === "ArrowDown") {
					event.preventDefault();
					let dropOptions = event.target.parentElement.parentElement.parentElement.querySelectorAll('.drop-options')[0],
						dropOptionsAnchor = dropOptions.querySelectorAll('a:not([class*="remove"]):not([class*="hide"]):not([style*="display: none"])');
					dropOptionsAnchor[0].focus();
				}
				if (event.key === "Tab") {
					if (event.target.parentElement.parentElement.parentElement.classList.contains('open')) {
						event.target.parentElement.parentElement.parentElement.classList.remove('open');
                        if(event.target.parentElement.parentElement.parentElement.querySelectorAll('#cmp-Input')[0].value.length > 0){
                            event.target.parentElement.parentElement.parentElement.querySelectorAll('#cmp-Input')[0].value = '';
                            event.target.parentElement.parentElement.parentElement.querySelectorAll('.drop-options a').forEach(anchorOptions => { anchorOptions.removeAttribute('style'); });
                        }
					}
				}
				if (event.key == "ArrowLeft") {
					if (event.target.value.length == 0) {
						event.preventDefault();
						let dropDisplay = event.target.parentElement.parentElement.parentElement.querySelectorAll('.drop-display')[0],
							dropDisplaySpan = dropDisplay.querySelectorAll('span:not([class*="hide"]):not([class*="remove"])');
						dropDisplaySpan[dropDisplaySpan.length - 1].focus();
					}
				}
			}
		});
	});

	document.addEventListener('keydown', function(event) {
		if (event.key === 'Tab') {
			setTimeout(function() {
				let focusedElement = document.activeElement;
				if (document?.activeElement?.parentElement?.parentElement?.parentElement?.classList.contains('drop')) {
					if (!(document.activeElement.parentElement.parentElement.parentElement.classList.contains('open'))) {
						document.activeElement.parentElement.parentElement.parentElement.classList.add('open')
					}
				}
			}, 0);
		}
	});


});