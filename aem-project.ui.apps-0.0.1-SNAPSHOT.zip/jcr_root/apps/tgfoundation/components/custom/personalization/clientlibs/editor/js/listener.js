// restricting the author to add only 50 Personalization Fields
(function ($, document, ns) {
    $(document).on("dialog-ready", function() {
        if($("span:contains('Personalization Fields')").length > 49) {
            $("button[coral-multifield-add]").get(-1).setAttribute('disabled','disabled');
        }

        // delete function
        $("div[data-name='./personalizationFields']").parent().next().on("click", function(){
        if($("span:contains('Personalization Fields')").length <= 50) {        
            $("button[coral-multifield-add]").get(-1).removeAttribute('disabled');
            $("#errorMsg").remove();
        }     
        }); 

        // add function
        $("button[coral-multifield-add]").get(-1).on("click", function(){
        var deleteBtns = $("div[data-name='./personalizationFields']").parent().next();
        for(let i=0; i<deleteBtns.length; i++){
            var events = $._data(deleteBtns[i], "events");    
            if(events == undefined){
                deleteBtns[i].on("click", function(){
                    if($("span:contains('Personalization Fields')").length <= 50) {        
                        $("button[coral-multifield-add]").get(-1).removeAttribute('disabled');
                        $("#errorMsg").remove();
                    }     
                });    
            }
        }

        if($("span:contains('Personalization Fields')").length > 49) { 
            var addBtn = $("button[coral-multifield-add]").get(-1);
            addBtn.setAttribute('disabled','disabled');
            $("<p id=\"errorMsg\" style=\"color:red;\">You have reached the max limit!</p>").insertAfter(addBtn);
        }
        });
    });
})(Granite.$, document, Granite.author);
