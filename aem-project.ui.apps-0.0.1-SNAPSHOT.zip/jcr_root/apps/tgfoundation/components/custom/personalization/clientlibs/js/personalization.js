$(document).on("ready", function() {
	validateXFs();
})

function validateXFs() {
	$(".personalization").each( (idx, elem) => {
		$(elem).find('>.xf-selector').each( (xfIndex, xf) => {
			let selector = $(xf),
				sessionName = selector.attr("data-sessionName"),
				operator = selector.attr("data-operator"),
				value = selector.attr("data-value"),
				andOr = selector.attr("data-andOr"),
				result = false;

			sessionName = sessionName.substring(1, sessionName.length);
			operator = operator.substring(1, operator.length);
			value = value.substring(1, value.length);
			andOr = andOr.substring(1, andOr.length);

			// validating from session
			sessionName = sessionName.split(",");
			operator = operator.split(",");
			value = value.split(",");
			andOr = andOr.split(",");

			for (let i = 0; i < sessionName.length; i++) {
				let sessVal = null,
					tempResult = false,
					name = sessionName[i],
					currentValue = value[i];

				if (name.includes(".")) {
					sessVal = JSON.parse(sessionStorage.getItem( name.split(".")[0]) );
					name.split(".").forEach( (value1, index1) => {
						if (index1 > 0) {
							if (value1.includes("[")) {
								let obj = value1.split("[")?.[0];
								sessVal = sessVal?.[`${obj}`];
								value1 = value1.split("[")?.[1]?.split("]")?.[0];
								sessVal = sessVal?.[`${value1}`];
							}
							else {
								sessVal = sessVal?.[`${value1}`];
							}
						}
					});
				}
				else {
					sessVal = sessionStorage.getItem( name );
				}

				if (sessVal === null || currentValue === "") {
					tempResult = false;
				}
				else {
					switch (operator[i]) {
						case '=' :
							tempResult = sessVal === currentValue;
							break;
						case '>':
							tempResult = sessVal > currentValue;
							break;
						case '<':
							tempResult = sessVal < currentValue;
							break;
						case '>=' :
							tempResult = sessVal >= currentValue;
							break;
						case '<=':
							tempResult = sessVal <= currentValue;
							break;
						case '!=':
							tempResult = sessVal !== currentValue;
							break;
						case 'contains':
							tempResult = sessVal.indexOf( currentValue ) !== -1;
							break;
						case 'does not contains':
							tempResult = sessVal.indexOf( currentValue ) === -1;
							break;
						case 'in':
							tempResult = currentValue.indexOf(sessVal) !== -1;
							break;
					}
				}

				if (i === 0) {
					result = tempResult;
				}
				else {
					if (andOr[i - 1] === 'and') {
						result = result && tempResult;
					}
					else if (andOr[i - 1] === 'or') {
						result = result || tempResult;
					}
					if (andOr[i - 1] === '') {
						result = tempResult;
					}
				}
			}

			// Remove all the form inputs so there is no conflicts
			if (!result && xfIndex === 0) {
				selector.find('input, .cmp-form-options--checkbox, .cmp-form-options--radio, .options select, .numberOfDuplicates, #mob-navbar-collapse').remove();
			}
			if ((!result && xfIndex > 0) ||
				(!result && xfIndex === 0 && !selector.find("link").length && !selector.find("script").length) ||
				(!result && xfIndex === 0 && selector.find(".containerDisplayCondition").length)) {
				selector.remove();
			}
			if (result) {
				showPersonalizationFragment( selector );

				$(elem).find("#default-xf").remove();
			}
		});

		if( $(elem).find("#default-xf") ) {
			showPersonalizationFragment( $(elem).find("#default-xf") );
		}
	});
}

function showPersonalizationFragment( elem ) {
	let path = elem.data("path");

	if( path ) {
		if( !path.endsWith(".html") && path.startsWith("/content/") ) {
			path += ".html";
		}

		$.ajax({
			type: "GET",
			url: path,
			async: true,
			success: (response) => {
				elem.after( response );
				elem.remove();
			},
			error: (error) => {
				console.log( error )
			}
		})
	}
}
