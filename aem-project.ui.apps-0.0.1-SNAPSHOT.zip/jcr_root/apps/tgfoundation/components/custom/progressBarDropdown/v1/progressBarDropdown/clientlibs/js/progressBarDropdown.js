$(document).ready(function() {
  progressBarInit();
});

function progressBarInit() {
  let pathMatch = false,
    loginValue = sessionStorage.getItem("login"),
    dropdownItem = document.querySelectorAll('.dropdownItems');
  dropdownItem.forEach(dropdownItem => {
    let link = dropdownItem.querySelector('a');
    dropdownItem.addEventListener('click', (event) => {
      if (loginValue || !(link.href === window.location.href)) {
		if ($("#defaultPlaceholder").attr("data-defaultPlaceholder") == undefined) {
		  window.location.href = link.href;
		}
		else if ($("#defaultPlaceholder").attr("data-defaultPlaceholder") !== undefined) {
          $("#placeholder").removeClass('cus-cmp-PlaceholderBg').addClass('cus-cmp-Placeholder');
          $("span.triangle_up").removeClass("triangle_up").addClass("triangle_down");
        }
      }
    });
  });
  $(".option li #cmp-url a").each(function() {
    let dropDownLink = $(this)?.attr('href')?.split('/')?.pop(),
      addOnCheck = $(this)?.parent()?.siblings()?.attr('fflogincheck'),
      dropDownText = $(this)?.parent()?.parent()?.children()?.get(0)?.textContent,
      dropDownTitle = $(this)?.text(),
      currentPagePath = window.location.pathname,
      textSection = $("<div class='stepDown'>" + dropDownText + "</div>"),
      titleSection = $("<div class='planTypeDown'>" + dropDownTitle + "</div>"),
      placeholder = $(this).parent().parent().parent().parent().parent().children().get(0);
    if ($("#defaultPlaceholder").attr("data-defaultPlaceholder") !== undefined) {
      $('.dropdownItems img[src]').addClass('styled-img');
      if ($("#placeholder").text().trim() == "") {
        $('[id="placeholder"]:visible').append($("#defaultPlaceholder").attr("data-defaultPlaceholder"));
      }
    } else if ((currentPagePath.includes(dropDownLink)) && addOnCheck != 'true' && $(this).closest('.option').siblings('[id="placeholder"]').is(":visible")) {
      pathMatch = true;
      $('[id="placeholder"]:visible').append(textSection);
      $('[id="placeholder"]:visible').append(titleSection);
      $(this).closest('.option').siblings('[id="placeholder"]').is(":visible") && $(this).addClass("dropdownValue");
      $(this).parent().parent().closest('.option').siblings('[id="placeholder"]').is(":visible") && $(this).parent().parent().addClass("dropdownBorder");
    } else if (pathMatch == true) {
      $(this).removeAttr('href');
      $(this).addClass('dropdownInactive');
    }
  });
  $('[id="select"]:visible').click(function(e) {
    $(this).children(".option").toggleClass("shown");
    $(this).toggleClass("open");
  });
  $(".option").click(function() {
    $(this).siblings("#selected").html($(this).html().split("<br>")[0]);
  });
  //To hide the dropdown options on click of filtered document
  $(document).on("click", function(event) {
    let dropDown = $('[id="select"]:visible')[0];
    if (!dropDown.contains(event.target)) {
      $(".option").removeClass("shown");
      $('[id="select"]:visible').removeClass("open");
	  if ($("#defaultPlaceholder").attr("data-defaultPlaceholder") !== undefined) {
        if ($('#placeholder').hasClass('cus-cmp-PlaceholderBg')) {
          $("#placeholder").removeClass('cus-cmp-PlaceholderBg').addClass('cus-cmp-Placeholder');
          $("span.triangle_up").removeClass("triangle_up").addClass("triangle_down");
        }
      }
    }
  });
  $('#placeholder').click(function() {
    if ($("#defaultPlaceholder").attr("data-defaultPlaceholder") !== undefined) {
      if ($(this).find('span').hasClass('triangle_up')) {
        $(this).find('span').removeClass('triangle_up').addClass('triangle_down');
        $(this).removeClass('cus-cmp-PlaceholderBg').addClass('cus-cmp-Placeholder');
      } else if ($(this).find('span').hasClass('triangle_down')) {
        $(this).find('span').removeClass('triangle_down').addClass('triangle_up');
        $(this).removeClass('cus-cmp-Placeholder').addClass('cus-cmp-PlaceholderBg');
      }
    }
  });
}