$(document).ready(function () {
	var hoverColor = $('.utilitybar').data('hovercolor');
	var defaultColor = $('.utilitybar').data('defaultcolor');
	$('.utility_nav li a').css('color', defaultColor);
	$('.utility_nav li').each(function (e) {
		$(this).mouseover(function () {
			$(this).find('a').css('color', hoverColor);
		})
		$(this).mouseout(function () {
			$(this).find('a').css('color', defaultColor);
		})
	})
 $(window).on('resize load',function(){
    var logoNavDeskHeight = $('.logo-Nav').data('logonavdeskheight');
    var logoNavMobHeight = $('.logo-Nav').data('logonavmobheight');
	if ($(window).width() > 767) {
        $('.logo-Nav').css({
                    'min-height': logoNavDeskHeight + 'px',
                    'line-height': logoNavDeskHeight + 'px'
                });


		$('.primaryNavLinks').each(function (e) {
			var primaryNavBgColor = $(this).data('primarynavbgcolor');
			var primaryNavBgHoverColor = $(this).data('primarynavbghovercolor');
			var primaryTextHoverColor = $(this).data('primarytexthovercolor');
			var primaryTextColor = $(this).data('primarytextcolor');
			$(this).css({
                        'color': primaryTextColor,
                        'background-color': primaryNavBgColor,
                        'border-bottom':'0'
                    });
             $(document).click(function(e){
                 if ($(window).width() > 767) {
                 if(e.target !== $('.primaryNavLinks')){
					$('.primaryNavLinks').css({'background-color': primaryNavBgColor,'color': primaryTextColor});
                 }
                 }
        	})
            $('.primaryNavLinks.open').css({'background-color': primaryNavBgHoverColor,'color': primaryTextHoverColor});
            $(this).on('mouseover focus', function () {
                $(this).css({'background-color': primaryNavBgHoverColor,'color':primaryTextHoverColor,'text-decoration':'underline'});
			})
			$(this).on('click', function () {
                if ($(window).width() > 767) {
                     $('.primaryNavLinks').css({'background-color': primaryNavBgColor,'color': primaryTextColor});
                    $(this).css({'background-color': primaryNavBgHoverColor,'color': primaryTextHoverColor,'text-decoration':'underline'});
                }
			})
			$(this).mouseout(function () {
                $(this).css({'background-color': primaryNavBgColor,'color': primaryTextColor,'text-decoration':'none'});
				$('.primaryNavLinks.open').css({'background-color': primaryNavBgHoverColor,'color': primaryTextHoverColor});
			})
		})

		$('.primaryNavLinks li').each(function (e) {
			var secondaryNavBgColor = $(this).data('secondarynavbgcolor');
			var secondaryNavBgHoverColor = $(this).data('secondarynavbghovercolor');
            var secondaryTextHoverColor = $(this).parent().parent().data('secondarynavlinkhovercolor');
			var secondaryTextColor = $(this).parent().parent().data('secondarynavlinkcolor');
			$(this).css({'border-bottom':'1px solid' + secondaryNavBgHoverColor,
                                 'border-left':'16px solid'+secondaryNavBgHoverColor});
			$(this).mouseover(function () {
				$(this).css('background-color', secondaryNavBgHoverColor);
				$(this).css('color', secondaryTextHoverColor);
			})
			$(this).mouseout(function () {
				$(this).css('background-color', secondaryNavBgColor);
				$(this).css('color', secondaryTextColor);

			})
		})
	} else {
		$('.logo-Nav').css({
			'min-height': logoNavMobHeight + 'px',
			'line-height': logoNavMobHeight + 'px'
		});

		$('.primaryNavLinks').each(function (e) {
            var primarymobopenbghovercolor,primarymobopentexthovercolor;
			/*mobile global variales*/
			var primaryMobNavBgColor = $(this).data('primarymobnavbgcolor');
			var primaryMobNavBgHoverColor = $(this).data('primarymobnavbghovercolor');
			var primaryMobTextHoverColor = $(this).data('primarymobtexthovercolor');
			var primaryMobTextColor = $(this).data('primarymobtextcolor');
			$(this).css({
				'border-bottom': '1px solid' + primaryMobNavBgHoverColor,
				'color': primaryMobTextColor,
				'background-color': primaryMobNavBgColor
			});
             $(this).on('mouseover',function () {
                 primarymobopenbghovercolor = $('.primaryNavLinks.open').data('primarymobnavbghovercolor');
            	primarymobopentexthovercolor = $('.primaryNavLinks.open').data('primarymobtexthovercolor');
                $(this).css({'background-color': primaryMobNavBgHoverColor,'text-decoration':'none','color': primaryMobTextHoverColor});
                 $('.primaryNavLinks.open').css({
					'background-color': primarymobopenbghovercolor,
					'color': primarymobopentexthovercolor
				});
			})
			$(this).on('mouseout',function () {
                primarymobopenbghovercolor = $('.primaryNavLinks.open').data('primarymobnavbghovercolor');
            		primarymobopentexthovercolor = $('.primaryNavLinks.open').data('primarymobtexthovercolor');
                $(this).css({'background-color': primaryMobNavBgColor,'color': primaryMobTextColor});
                 $('.primaryNavLinks.open').css({
					'background-color': primarymobopenbghovercolor,
					'color': primarymobopentexthovercolor
				});
			})
            $(document).click(function(e) {
if ($(window).width() < 767) {
    if (e.target !== $('.primaryNavLinks')) {
        $('.primaryNavLinks').each(function() {
            var primaryMobNavBgColor = $(this).data('primarymobnavbgcolor');
            var primaryMobTextColor = $(this).data('primarymobtextcolor');
            $(this).css({
                'background-color': primaryMobNavBgColor,
                'color': primaryMobTextColor
            });

        })
    }
}
})
})
		$('.primaryNavLinks li').each(function (e) {
			var secondaryMobNavBgColor = $(this).data('secondarymobnavbgcolor');
			var secondaryMobNavTextColor = $(this).data('secondarymobnavitemcolor');
			var secondaryMobNavBgHoverColor = $(this).data('secondarymobnavhoverbgcolor');
			var secondaryMobNavTextHoverColor = $(this).data('secondarymobnavitemhovercolor');
			$(this).css({'border-bottom':'1px solid' + secondaryMobNavBgHoverColor,
                                 'border-left':'16px solid'+secondaryMobNavBgHoverColor,
                                 'background-color': secondaryMobNavBgColor,
                                 'color': secondaryMobNavTextColor});
			$(this).on('mouseover', function () {
				$(this).css('background-color', secondaryMobNavBgHoverColor);
				$(this).css('color', secondaryMobNavTextHoverColor);

			})
			$(this).on('mouseout',function () {
				$(this).css('background-color', secondaryMobNavBgColor);
				$(this).css('color', secondaryMobNavTextColor);

			})
		})
	}
 })

	$('.utilityprimarynav a').each(function () {
		var hrefval = $(this).attr('href');
		if (hrefval != undefined && !hrefval.startsWith('/content/dam') && hrefval.startsWith('/content') && !hrefval.includes('.html')) {
			$(this).attr('href', hrefval + '.html');
		}
	})

})