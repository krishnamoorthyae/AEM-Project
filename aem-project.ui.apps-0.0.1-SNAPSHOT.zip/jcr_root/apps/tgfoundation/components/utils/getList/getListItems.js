// get generic list items

"use strict"

use(function () {
	var resolver = sling.getRequest().getResource().getResourceResolver();
	var listCF = resolver.getResource( this.listPath );
	var list = listCF.adaptTo(Packages.com.tgfoundation.core.models.GenericListModel);

	return list.getItems();
});
