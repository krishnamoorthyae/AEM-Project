package com.policy.models;

public class ContactNumber {
	
	private String prefix;
	private String handlebar;
	private String value;
	
	public String getPrefix() {
		return prefix;
	}
	public void setPrefix(String prefix) {
		this.prefix = prefix;
	}
	public String getHandlebar() {
		return handlebar;
	}
	public void setHandlebar(String handlebar) {
		this.handlebar = handlebar;
	}
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}

}

