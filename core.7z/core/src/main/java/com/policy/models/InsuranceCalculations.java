package com.policy.models;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import com.google.gson.Gson;
import com.tgfoundation.core.models.functionality.HttpUtilResponse;
import com.policy.models.detailresponse.Amount;
import com.policy.models.detailresponse.AmountValue;
import com.policy.models.detailresponse.AmountValue_;
import com.policy.models.detailresponse.Amount_;
import com.policy.models.detailresponse.BenefitDetail;
import com.policy.models.detailresponse.TravelApiResponse;
import com.policy.models.quoteresponse.AmountValues;
import com.policy.models.quoteresponse.Amounts;
import com.policy.models.quoteresponse.BenefitDetails;
import com.policy.models.quoteresponse.ProductDetails;
import com.policy.models.quoteresponse.QuoteApiResponse;
import com.policy.components.Insurance;

public class InsuranceCalculations implements Insurance {

    @Override
    public TravelApiResponse getCalculations(HttpUtilResponse httpUtilResponse) {
        TravelApiResponse travelApiResponse = new Gson().fromJson((httpUtilResponse.getBody()), TravelApiResponse.class);
        List<Amount> amountList = travelApiResponse.getDetailResponse().getPolicyDetail().getProductDetail().getAmounts();
        List<AmountValue> amountValueList = amountList.get(0).getAmountValues();
        List<BenefitDetail> benefitDetails = travelApiResponse.getDetailResponse().getPolicyDetail().getProductDetail().getBenefitDetails();
        List<AmountValue> clonedAmmountValueList = calculateTravel(benefitDetails, amountValueList);

        travelApiResponse.getDetailResponse().getPolicyDetail().getProductDetail().getAmounts().get(0).setAmountValues(clonedAmmountValueList);

        return travelApiResponse;
    }

    public QuoteApiResponse getCalculationQuote(HttpUtilResponse httpUtilResponse) {
        QuoteApiResponse quoteApiResponse = new Gson().fromJson((httpUtilResponse.getBody()), QuoteApiResponse.class);
		if (quoteApiResponse.getQuoteResponse().getQuoteResponses() != null) {
			for (int j = 0; j < quoteApiResponse.getQuoteResponse().getQuoteResponses().size(); j++) {
				List<ProductDetails> productDetailList = quoteApiResponse.getQuoteResponse().getQuoteResponses().get(j).getPurchaseRequest().getProductDetails();
				for (int i = 0; i < productDetailList.size(); i++) {
					List<Amounts> amountList = productDetailList.get(i).getAmounts();
					List<AmountValues> amountValueList = amountList.get(0).getAmountValues();
					List<BenefitDetails> benefitDetails = productDetailList.get(i).getBenefitDetails();
					List<AmountValues> clonedAmmountValueList = calculateQuote(benefitDetails, amountValueList);
					quoteApiResponse.getQuoteResponse().getQuoteResponses().get(j).getPurchaseRequest().getProductDetails().get(i).getAmounts().get(0).setAmountValues(clonedAmmountValueList);
				}
			}
		}

        return quoteApiResponse;
    }

    public List<AmountValue> calculateTravel(List<BenefitDetail> benefitDetails, List<AmountValue> amountValueList) {
        BigDecimal insurance = new BigDecimal("0.0");
        BigDecimal nonInsurance = new BigDecimal("0.0");
        BigDecimal bundlePremium = new BigDecimal("0.0");
        List<AmountValue> clonedAmmountValueList = new ArrayList<>(amountValueList);

        if (!benefitDetails.isEmpty()) {
            for (BenefitDetail bd : benefitDetails) {
                if ((bd.getBundle() != null && bd.getBundle() == true) && (bd.getCoverageType() != null && bd.getCoverageType().equals("NORMAL COVERAGES"))) {
                    List<Amount_> amounts = bd.getAmounts();
                    List<AmountValue_> amountValues = amounts.get(0).getAmountValues();
                    for (AmountValue_ amountValue : amountValues) {
                        if (amountValue.getType().equals("BasePremium"))
                            insurance = insurance.add(new BigDecimal(amountValue.getValue()));
                    }
                } else if ((bd.getBundle() != null && bd.getBundle() == true) && (bd.getCoverageType() != null && bd.getCoverageType().equals("SERVICE COVERAGE"))) {
                    List<Amount_> amounts = bd.getAmounts();
                    List<AmountValue_> amountValues = amounts.get(0).getAmountValues();
                    for (AmountValue_ amountValue : amountValues) {
                        if (amountValue.getType().equals("BasePremium"))
                            nonInsurance = nonInsurance.add(new BigDecimal(amountValue.getValue()));
                    }
                }
                if ((bd.getBundle() != null && bd.getBundle() == true)) {
                    List<Amount_> amounts = bd.getAmounts();
                    List<AmountValue_> amountValues = amounts.get(0).getAmountValues();
                    for (AmountValue_ amountValue : amountValues) {
                        if (amountValue.getType().equals("BasePremium"))
                        	bundlePremium = bundlePremium.add(new BigDecimal(amountValue.getValue()));
                    }
                }
            }

            AmountValue newInsuranceAmount = new AmountValue();
            newInsuranceAmount.setType("InsuranceServices");
            newInsuranceAmount.setValue(String.valueOf(insurance));
            clonedAmmountValueList.add(newInsuranceAmount);

            AmountValue newNonInsuranceAmount = new AmountValue();
            newNonInsuranceAmount.setType("NonInsuranceServices");
            newNonInsuranceAmount.setValue(String.valueOf(nonInsurance));
            clonedAmmountValueList.add(newNonInsuranceAmount);
            
            AmountValue newBundlePremium = new AmountValue();
            newBundlePremium.setType("BundlePremiumServices");
            newBundlePremium.setValue(String.valueOf(bundlePremium));
            clonedAmmountValueList.add(newBundlePremium);
        }

        return clonedAmmountValueList;
    }

    public List<AmountValues> calculateQuote(List<BenefitDetails> benefitDetails, List<AmountValues> amountValueList) {
        BigDecimal insurance = new BigDecimal("0.0");
        BigDecimal nonInsurance = new BigDecimal("0.0");
        BigDecimal bundlePremium = new BigDecimal("0.0");
        List<AmountValues> clonedAmmountValueList = new ArrayList<>(amountValueList);

        if (!benefitDetails.isEmpty()) {
            for (BenefitDetails bd : benefitDetails) {
                if ((bd.getBundle() != null && bd.getBundle() == true) && (bd.getCoverageType() != null && bd.getCoverageType().equals("NORMAL COVERAGES"))) {
                    List<Amounts> amounts = bd.getAmounts();
                    List<AmountValues> amountValues = amounts.get(0).getAmountValues();
                    for (AmountValues amountValue : amountValues) {
                        if (amountValue.getType().equals("BasePremium"))
                            insurance = insurance.add(new BigDecimal(amountValue.getValue()));
                    }
                } else if ((bd.getBundle() != null && bd.getBundle() == true) && (bd.getCoverageType() != null && bd.getCoverageType().equals("SERVICE COVERAGE"))) {
                    List<Amounts> amounts = bd.getAmounts();
                    List<AmountValues> amountValues = amounts.get(0).getAmountValues();
                    for (AmountValues amountValue : amountValues) {
                        if (amountValue.getType().equals("BasePremium"))
                            nonInsurance = nonInsurance.add(new BigDecimal(amountValue.getValue()));
                    }
                }
                if ((bd.getBundle() != null && bd.getBundle() == true)) {
                    List<Amounts> amounts = bd.getAmounts();
                    List<AmountValues> amountValues = amounts.get(0).getAmountValues();
                    for (AmountValues amountValue : amountValues) {
                        if (amountValue.getType().equals("BasePremium"))
                            bundlePremium = bundlePremium.add(new BigDecimal(amountValue.getValue()));
                    }
                }
            }

            AmountValues newInsuranceAmount = new AmountValues();
            newInsuranceAmount.setType("InsuranceServices");
            newInsuranceAmount.setValue(String.valueOf(insurance));
            clonedAmmountValueList.add(newInsuranceAmount);

            AmountValues newNonInsuranceAmount = new AmountValues();
            newNonInsuranceAmount.setType("NonInsuranceServices");
            newNonInsuranceAmount.setValue(String.valueOf(nonInsurance));
            clonedAmmountValueList.add(newNonInsuranceAmount);
            
            AmountValues newBundlePremium = new AmountValues();
            newBundlePremium.setType("BundlePremiumServices");
            newBundlePremium.setValue(String.valueOf(bundlePremium));
            clonedAmmountValueList.add(newBundlePremium);
        }

        return clonedAmmountValueList;
    }
}
