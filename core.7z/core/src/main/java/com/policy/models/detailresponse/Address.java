
package com.policy.models.detailresponse;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;
import java.util.List;

public class Address {

    @SerializedName("addressId")
    @Expose
    private String addressId;
    @SerializedName("types")
    @Expose
    private List<String> types = null;
    @SerializedName("street1")
    @Expose
    private String street1;
    @SerializedName("street2")
    @Expose
    private String street2;
    @SerializedName("street3")
    @Expose
    private String street3;
    @SerializedName("city")
    @Expose
    private String city;
    @SerializedName("isoStateOrProvince")
    @Expose
    private String isoStateOrProvince;
    @SerializedName("stateOrProvinceName")
    @Expose
    private String stateOrProvinceName;
    @SerializedName("postalCode")
    @Expose
    private String postalCode;
    @SerializedName("isoCountry")
    @Expose
    private String isoCountry;
    @SerializedName("countryName")
    @Expose
    private String countryName;
    @SerializedName("expired")
    @Expose
    private Boolean expired;

    public String getAddressId() {
        return addressId;
    }

    public void setAddressId(String addressId) {
        this.addressId = addressId;
    }

    public List<String> getTypes() {
        return (types != null) ? new ArrayList<String>(types): null;
    }

    public void setTypes(List<String> types) {
        this.types = (types != null) ? new ArrayList<String>(types): null;
    }

    public String getStreet1() {
        return street1;
    }

    public void setStreet1(String street1) {
        this.street1 = street1;
    }

    public String getStreet2() {
        return street2;
    }

    public void setStreet2(String street2) {
        this.street2 = street2;
    }

    public String getStreet3() {
        return street3;
    }

    public void setStreet3(String street3) {
        this.street3 = street3;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getIsoStateOrProvince() {
        return isoStateOrProvince;
    }

    public void setIsoStateOrProvince(String isoStateOrProvince) {
        this.isoStateOrProvince = isoStateOrProvince;
    }

    public String getStateOrProvinceName() {
        return stateOrProvinceName;
    }

    public void setStateOrProvinceName(String stateOrProvinceName) {
        this.stateOrProvinceName = stateOrProvinceName;
    }

    public String getPostalCode() {
        return postalCode;
    }

    public void setPostalCode(String postalCode) {
        this.postalCode = postalCode;
    }

    public String getIsoCountry() {
        return isoCountry;
    }

    public void setIsoCountry(String isoCountry) {
        this.isoCountry = isoCountry;
    }

    public String getCountryName() {
        return countryName;
    }

    public void setCountryName(String countryName) {
        this.countryName = countryName;
    }

    public Boolean getExpired() {
        return expired;
    }

    public void setExpired(Boolean expired) {
            this.expired = expired;
    }

}
