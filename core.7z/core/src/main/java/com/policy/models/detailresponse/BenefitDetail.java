
package com.policy.models.detailresponse;

import java.util.Collections;
import java.util.List;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class BenefitDetail {

    @SerializedName("benefitCode")
    @Expose
    private String benefitCode;
    @SerializedName("benefitName")
    @Expose
    private String benefitName;
    @SerializedName("section")
    @Expose
    private String section;
    @SerializedName("formType")
    @Expose
    private String formType;
    @SerializedName("perRule")
    @Expose
    private String perRule;
    @SerializedName("amounts")
    @Expose
    private List<Amount_> amounts = null;
    @SerializedName("factors")
    @Expose
    private List<Object> factors = null;
    @SerializedName("sublimits")
    @Expose
    private List<Sublimit> sublimits = null;
    @SerializedName("isStandard")
    @Expose
    private Boolean isStandard;
    @SerializedName("useForClaims")
    @Expose
    private Boolean useForClaims;
    @SerializedName("useForFulfillment")
    @Expose
    private Boolean useForFulfillment;
    @SerializedName("payoutPerRuleDesc")
    @Expose
    private String payoutPerRuleDesc;
    @SerializedName("packageType")
    @Expose
    private String packageType;
    @SerializedName("packageDesc")
    @Expose
    private String packageDesc;
    @SerializedName("bundle")
    @Expose
    private Boolean bundle;
    @SerializedName("coverageType")
    @Expose
    private String coverageType;
    
    public Boolean getBundle() {
		return bundle;
	}

	public void setBundle(Boolean bundle) {
		this.bundle = bundle;
	}

	public String getCoverageType() {
		return coverageType;
	}

	public void setCoverageType(String coverageType) {
		this.coverageType = coverageType;
	}

	public String getBenefitCode() {
        return benefitCode;
    }

    public void setBenefitCode(String benefitCode) {
        this.benefitCode = benefitCode;
    }

    public String getBenefitName() {
        return benefitName;
    }

    public void setBenefitName(String benefitName) {
        this.benefitName = benefitName;
    }

    public String getSection() {
        return section;
    }

    public void setSection(String section) {
        this.section = section;
    }

    public String getFormType() {
        return formType;
    }

    public void setFormType(String formType) {
        this.formType = formType;
    }

    public String getPerRule() {
        return perRule;
    }

    public void setPerRule(String perRule) {
        this.perRule = perRule;
    }

    public List<Amount_> getAmounts() {
        return (amounts != null) ? Collections.unmodifiableList(amounts): null;
    }

    public void setAmounts(List<Amount_> amounts) {
        this.amounts = (amounts != null) ? Collections.unmodifiableList(amounts): null;
    }

    public List<Object> getFactors() {
        return (factors != null) ? Collections.unmodifiableList(factors): null;
    }

    public void setFactors(List<Object> factors) {
        this.factors = (factors != null) ? Collections.unmodifiableList(factors): null;
    }

    public List<Sublimit> getSublimits() {
        return (sublimits != null) ? Collections.unmodifiableList(sublimits): null;
    }

    public void setSublimits(List<Sublimit> sublimits) {
        this.sublimits = (sublimits != null) ? Collections.unmodifiableList(sublimits): null;
    }

    public Boolean getIsStandard() {
        return isStandard;
    }

    public void setIsStandard(Boolean isStandard) {
        this.isStandard = isStandard;
    }

    public Boolean getUseForClaims() {
        return useForClaims;
    }

    public void setUseForClaims(Boolean useForClaims) {
        this.useForClaims = useForClaims;
    }

    public Boolean getUseForFulfillment() {
        return useForFulfillment;
    }

    public void setUseForFulfillment(Boolean useForFulfillment) {
        this.useForFulfillment = useForFulfillment;
    }

    public String getPayoutPerRuleDesc() {
        return payoutPerRuleDesc;
    }

    public void setPayoutPerRuleDesc(String payoutPerRuleDesc) {
        this.payoutPerRuleDesc = payoutPerRuleDesc;
    }

    public String getPackageType() {
        return packageType;
    }

    public void setPackageType(String packageType) {
        this.packageType = packageType;
    }

    public String getPackageDesc() {
        return packageDesc;
    }

    public void setPackageDesc(String packageDesc) {
        this.packageDesc = packageDesc;
    }
}
