
package com.policy.models.detailresponse;

import java.util.Collections;
import java.util.List;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Destination {

    @SerializedName("type")
    @Expose
    private String type;
    @SerializedName("locationValue")
    @Expose
    private List<LocationValue> locationValue = null;

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public List<LocationValue> getLocationValue() {
        return (locationValue != null) ? Collections.unmodifiableList(locationValue): null;
    }

    public void setLocationValue(List<LocationValue> locationValue) {
        this.locationValue = (locationValue != null) ? Collections.unmodifiableList(locationValue): null;
    }

}
