
package com.policy.models.detailresponse;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class DetailResponse {

    @SerializedName("transactionLog")
    @Expose
    private TransactionLog transactionLog;
    @SerializedName("policyDetail")
    @Expose
    private PolicyDetail policyDetail;

    public TransactionLog getTransactionLog() {
        return transactionLog;
    }

    public void setTransactionLog(TransactionLog transactionLog) {
        this.transactionLog = transactionLog;
    }

    public PolicyDetail getPolicyDetail() {
        return policyDetail;
    }

    public void setPolicyDetail(PolicyDetail policyDetail) {
        this.policyDetail = policyDetail;
    }

}
