
package com.policy.models.detailresponse;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class PayoutLimit {

    @SerializedName("payoutLimitName")
    @Expose
    private String payoutLimitName;
    @SerializedName("payoutLimitAmount")
    @Expose
    private String payoutLimitAmount;
    @SerializedName("payoutRuleCode")
    @Expose
    private String payoutRuleCode;
    @SerializedName("payoutRuleDesc")
    @Expose
    private String payoutRuleDesc;
    @SerializedName("payoutPerRuleCode")
    @Expose
    private String payoutPerRuleCode;

    public String getPayoutLimitName() {
        return payoutLimitName;
    }

    public void setPayoutLimitName(String payoutLimitName) {
        this.payoutLimitName = payoutLimitName;
    }

    public String getPayoutLimitAmount() {
        return payoutLimitAmount;
    }

    public void setPayoutLimitAmount(String payoutLimitAmount) {
        this.payoutLimitAmount = payoutLimitAmount;
    }

    public String getPayoutRuleCode() {
        return payoutRuleCode;
    }

    public void setPayoutRuleCode(String payoutRuleCode) {
        this.payoutRuleCode = payoutRuleCode;
    }

    public String getPayoutRuleDesc() {
        return payoutRuleDesc;
    }

    public void setPayoutRuleDesc(String payoutRuleDesc) {
        this.payoutRuleDesc = payoutRuleDesc;
    }

    public String getPayoutPerRuleCode() {
        return payoutPerRuleCode;
    }

    public void setPayoutPerRuleCode(String payoutPerRuleCode) {
        this.payoutPerRuleCode = payoutPerRuleCode;
    }

}
