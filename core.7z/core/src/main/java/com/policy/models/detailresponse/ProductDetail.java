
package com.policy.models.detailresponse;

import java.util.Collections;
import java.util.List;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class ProductDetail {

    @SerializedName("productCode")
    @Expose
    private String productCode;
    @SerializedName("productName")
    @Expose
    private String productName;
    @SerializedName("planCode")
    @Expose
    private String planCode;
    @SerializedName("planId")
    @Expose
    private String planId;
    @SerializedName("planName")
    @Expose
    private String planName;
    @SerializedName("planDescription")
    @Expose
    private String planDescription;
    @SerializedName("amounts")
    @Expose
    private List<Amount> amounts = null;
    @SerializedName("referenceNumbers")
    @Expose
    private Object referenceNumbers;
    @SerializedName("customElements")
    @Expose
    private Object customElements;
    @SerializedName("benefitDetails")
    @Expose
    private List<BenefitDetail> benefitDetails = null;
    @SerializedName("productContent")
    @Expose
    private Object productContent;
    @SerializedName("currencyCode")
    @Expose
    private Object currencyCode;

    public String getProductCode() {
        return productCode;
    }

    public void setProductCode(String productCode) {
        this.productCode = productCode;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getPlanCode() {
        return planCode;
    }

    public void setPlanCode(String planCode) {
        this.planCode = planCode;
    }

    public String getPlanId() {
        return planId;
    }

    public void setPlanId(String planId) {
        this.planId = planId;
    }

    public String getPlanName() {
        return planName;
    }

    public void setPlanName(String planName) {
        this.planName = planName;
    }

    public String getPlanDescription() {
        return planDescription;
    }

    public void setPlanDescription(String planDescription) {
        this.planDescription = planDescription;
    }

    public List<Amount> getAmounts() {
        return (amounts != null) ? Collections.unmodifiableList(amounts): null;
    }

    public void setAmounts(List<Amount> amounts) {
        this.amounts = (amounts != null) ? Collections.unmodifiableList(amounts): null;
    }

    public Object getReferenceNumbers() {
        return referenceNumbers;
    }

    public void setReferenceNumbers(Object referenceNumbers) {
        this.referenceNumbers = referenceNumbers;
    }

    public Object getCustomElements() {
        return customElements;
    }

    public void setCustomElements(Object customElements) {
        this.customElements = customElements;
    }

    public List<BenefitDetail> getBenefitDetails() {
        return (benefitDetails != null) ? Collections.unmodifiableList(benefitDetails): null;
    }

    public void setBenefitDetails(List<BenefitDetail> benefitDetails) {
        this.benefitDetails = (benefitDetails != null) ? Collections.unmodifiableList(benefitDetails): null;
    }

    public Object getProductContent() {
        return productContent;
    }

    public void setProductContent(Object productContent) {
        this.productContent = productContent;
    }

    public Object getCurrencyCode() {
        return currencyCode;
    }

    public void setCurrencyCode(Object currencyCode) {
        this.currencyCode = currencyCode;
    }

}