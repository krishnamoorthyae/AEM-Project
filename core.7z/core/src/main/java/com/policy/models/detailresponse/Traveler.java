
package com.policy.models.detailresponse;

import java.util.Collections;
import java.util.List;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Traveler {

    @SerializedName("travelerIdentifier")
    @Expose
    private String travelerIdentifier;
    @SerializedName("insuredType")
    @Expose
    private String insuredType;
    @SerializedName("deductible")
    @Expose
    private Deductible deductible;    
	@SerializedName("medicalScore")
    @Expose
    private String medicalScore;   
	@SerializedName("passengerType")
    @Expose
    private String passengerType;
    @SerializedName("prefix")
    @Expose
    private String prefix;
    @SerializedName("firstName")
    @Expose
    private String firstName;
    @SerializedName("middleName")
    @Expose
    private String middleName;
    @SerializedName("lastName")
    @Expose
    private String lastName;
    @SerializedName("suffix")
    @Expose
    private String suffix;
    @SerializedName("gender")
    @Expose
    private String gender;
    @SerializedName("dateOfBirth")
    @Expose
    private String dateOfBirth;
    @SerializedName("identifications")
    @Expose
    private List<Object> identifications = null;
    @SerializedName("addresses")
    @Expose
    private List<Address> addresses = null;
    @SerializedName("beneficiaries")
    @Expose
    public List<Beneficiaries> beneficiaries = null;
    @SerializedName("contactDetails")
    @Expose
    private List<ContactDetail> contactDetails = null;
    @SerializedName("travelerContent")
    @Expose
    private Object travelerContent;
    @SerializedName("travelerTripPrice")
    @Expose
    private TravelerTripPrice travelerTripPrice;
    @SerializedName("oldestIsoResidencyState")
    @Expose
    private String oldestIsoResidencyState;

    public String getTravelerIdentifier() {
        return travelerIdentifier;
    }

    public void setTravelerIdentifier(String travelerIdentifier) {
        this.travelerIdentifier = travelerIdentifier;
    }

    public String getInsuredType() {
        return insuredType;
    }

    public void setInsuredType(String insuredType) {
        this.insuredType = insuredType;
    }
    
    public Deductible getDeductible() {
		return deductible;
	}

	public void setDeductible(Deductible deductible) {
		this.deductible = deductible;
	}
    
    public String getMedicalScore() {
		return medicalScore;
	}

	public void setMedicalScore(String medicalScore) {
		this.medicalScore = medicalScore;
	}
	
    public String getPassengerType() {
        return passengerType;
    }

    public void setPassengerType(String passengerType) {
        this.passengerType = passengerType;
    }

    public String getPrefix() {
        return prefix;
    }

    public void setPrefix(String prefix) {
        this.prefix = prefix;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getMiddleName() {
        return middleName;
    }

    public void setMiddleName(String middleName) {
        this.middleName = middleName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getSuffix() {
        return suffix;
    }

    public void setSuffix(String suffix) {
        this.suffix = suffix;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(String dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public List<Object> getIdentifications() {
        return (identifications != null) ? Collections.unmodifiableList(identifications): null;
    }

    public void setIdentifications(List<Object> identifications) {
        this.identifications = (identifications != null) ? Collections.unmodifiableList(identifications): null;
    }

    public List<Address> getAddresses() {
        return (addresses != null) ? Collections.unmodifiableList(addresses): null;
    }

    public void setAddresses(List<Address> addresses) {
        this.addresses = (addresses != null) ? Collections.unmodifiableList(addresses): null;
    }
    
    public List<Beneficiaries> getBeneficiaries() {
        return (beneficiaries != null) ? Collections.unmodifiableList(beneficiaries): null;
    }

    public void setBeneficiaries(List<Beneficiaries> beneficiaries) {
        this.beneficiaries = (beneficiaries != null) ? Collections.unmodifiableList(beneficiaries): null;
    }

    public List<ContactDetail> getContactDetails() {
        return (contactDetails != null) ? Collections.unmodifiableList(contactDetails): null;
    }

    public void setContactDetails(List<ContactDetail> contactDetails) {
        this.contactDetails = (contactDetails != null) ? Collections.unmodifiableList(contactDetails): null;
    }

    public Object getTravelerContent() {
        return travelerContent;
    }

    public void setTravelerContent(Object travelerContent) {
        this.travelerContent = travelerContent;
    }

    public TravelerTripPrice getTravelerTripPrice() {
        return travelerTripPrice;
    }

    public void setTravelerTripPrice(TravelerTripPrice travelerTripPrice) {
        this.travelerTripPrice = travelerTripPrice;
    }

    public String getOldestIsoResidencyState() {
        return oldestIsoResidencyState;
    }

    public void setOldestIsoResidencyState(String oldestIsoResidencyState) {
        this.oldestIsoResidencyState = oldestIsoResidencyState;
    }

}
