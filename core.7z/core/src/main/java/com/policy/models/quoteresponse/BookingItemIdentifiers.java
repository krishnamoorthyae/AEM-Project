package com.policy.models.quoteresponse;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class BookingItemIdentifiers {

	@SerializedName("bookingItemIdentifier")
    @Expose
	private String bookingItemIdentifier;

	public String getBookingItemIdentifier() {
		return bookingItemIdentifier;
	}

	public void setBookingItemIdentifier(String bookingItemIdentifier) {
		this.bookingItemIdentifier = bookingItemIdentifier;
	}
}
