package com.policy.models.quoteresponse;

import java.util.ArrayList;
import java.util.List;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class BookingItems {

	@SerializedName("order")
	@Expose
	private String order;
	@SerializedName("startDateTime")
	@Expose
	private String startDateTime;
	@SerializedName("endDateTime")
	@Expose
	private String endDateTime;
	@SerializedName("bookingItemPrice")
	@Expose
	private List<BookingItemPrice> bookingItemPrice = null;
	@SerializedName("referenceNumbers")
	@Expose
	private List<ReferenceNumbers> referenceNumbers = null;
	@SerializedName("ticketType")
	@Expose
	private String ticketType;
	@SerializedName("supplier")
	@Expose
	private Supplier supplier;
	@SerializedName("locations")
	@Expose
	private List<Locations> locations = null;
	@SerializedName("customElements")
	@Expose
	private List<CustomElements> customElements = null;
	public String getOrder() {
		return order;
	}
	public void setOrder(String order) {
		this.order = order;
	}
	public String getStartDateTime() {
		return startDateTime;
	}
	public void setStartDateTime(String startDateTime) {
		this.startDateTime = startDateTime;
	}
	public String getEndDateTime() {
		return endDateTime;
	}
	public void setEndDateTime(String endDateTime) {
		this.endDateTime = endDateTime;
	}
	public List<BookingItemPrice> getBookingItemPrice() {
		return (bookingItemPrice != null) ? new ArrayList<BookingItemPrice>(bookingItemPrice) : null;
	}
	public void setBookingItemPrice(List<BookingItemPrice> bookingItemPrice) {
		this.bookingItemPrice = (bookingItemPrice != null) ? new ArrayList<BookingItemPrice>(bookingItemPrice) : null;
	}
	public List<ReferenceNumbers> getReferenceNumbers() {
		return (referenceNumbers != null) ? new ArrayList<ReferenceNumbers>(referenceNumbers) : null;
	}
	public void setReferenceNumbers(List<ReferenceNumbers> referenceNumbers) {
		this.referenceNumbers = (referenceNumbers != null) ? new ArrayList<ReferenceNumbers>(referenceNumbers) : null;
	}
	public String getTicketType() {
		return ticketType;
	}
	public void setTicketType(String ticketType) {
		this.ticketType = ticketType;
	}
	public Supplier getSupplier() {
		return supplier;
	}
	public void setSupplier(Supplier supplier) {
		this.supplier = supplier;
	}
	public List<Locations> getLocations() {
		return (locations != null) ? new ArrayList<Locations>(locations) : null;
	}
	public void setLocations(List<Locations> locations) {
		this.locations = (locations != null) ? new ArrayList<Locations>(locations) : null;
	}
	public List<CustomElements> getCustomElements() {
		return (customElements != null) ? new ArrayList<CustomElements>(customElements) : null;
	}
	public void setCustomElements(List<CustomElements> customElements) {
		this.customElements = (customElements != null) ? new ArrayList<CustomElements>(customElements) : null;
	}
	
}
