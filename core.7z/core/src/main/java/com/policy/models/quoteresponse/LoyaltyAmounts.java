package com.policy.models.quoteresponse;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

public class LoyaltyAmounts {
	@SerializedName("type")
    @Expose
	private String type;
	@SerializedName("value")
    @Expose
	private String value;
    @SerializedName("description")
    @Expose
    private String description;

	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
    public String getValue() {
        return value;
    }
    public void setValue(String value) {
        this.value = value;
   	}
    public String getDescription() {
        return description;
    }
    public void setDescription(String description) {
        this.description = description;
    }
    public List<String> getKeys() {
        List<String> result = new ArrayList<>();
        Field[] declaredFields = this.getClass().getDeclaredFields();
        for( Field field : declaredFields ) {
//            if( !field.isAccessible() ) {
            String[] nameArr = field.getName().split("_");
            String name = "";
            for( String s : nameArr ) {
                name = name + s.substring(0, 1).toUpperCase() + s.substring(1);
            }
            result.add( name );
//            }
        }
        return result;
    }
}
