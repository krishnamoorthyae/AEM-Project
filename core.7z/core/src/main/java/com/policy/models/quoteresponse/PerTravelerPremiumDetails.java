package com.policy.models.quoteresponse;

import java.util.ArrayList;
import java.util.List;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class PerTravelerPremiumDetails {

	@SerializedName("travelerIdentifier")
    @Expose
	private String travelerIdentifier;
	@SerializedName("travelerPremiumDetails")
    @Expose
	private List<TravelerPremiumDetails> travelerPremiumDetails = null;
	public String getTravelerIdentifier() {
		return travelerIdentifier;
	}
	public void setTravelerIdentifier(String travelerIdentifier) {
		this.travelerIdentifier = travelerIdentifier;
	}
	public List<TravelerPremiumDetails> getTravelerPremiumDetails() {
		return (travelerPremiumDetails != null) ? new ArrayList<TravelerPremiumDetails>(travelerPremiumDetails) : null;
	}
	public void setTravelerPremiumDetails(List<TravelerPremiumDetails> travelerPremiumDetails) {
		this.travelerPremiumDetails = (travelerPremiumDetails != null) ? new ArrayList<TravelerPremiumDetails>(travelerPremiumDetails) : null;
	}
}
