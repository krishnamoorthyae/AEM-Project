package com.policy.models.quoteresponse;

import java.util.ArrayList;
import java.util.List;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class ProductDetails {

	@SerializedName("productCode")
    @Expose
	private String productCode;
	@SerializedName("productName")
    @Expose
	private String productName;
	@SerializedName("planCode")
    @Expose
	private String planCode;
	@SerializedName("planId")
    @Expose
	private String planId;
	@SerializedName("planName")
    @Expose
	private String planName;
	@SerializedName("planDescription")
    @Expose
	private String planDescription;
	@SerializedName("purchaseDateTime")
    @Expose
	private String purchaseDateTime;
    @SerializedName("loyaltyPrograms")
    @Expose
    private List<LoyaltyPrograms> loyaltyPrograms;
	@SerializedName("amounts")
    @Expose
	private List<Amounts> amounts = null;
	@SerializedName("referenceNumbers")
    @Expose
	private List<ReferenceNumbers> referenceNumbers = null;
	@SerializedName("factors")
    @Expose
	private List<Object> factors = null;
	@SerializedName("benefitDetails")
    @Expose
	private List<BenefitDetails> benefitDetails = null;
	@SerializedName("tripIdentifiers")
    @Expose
	private List<TripIdentifiers> tripIdentifiers = null;
	@SerializedName("travelerIdentifiers")
    @Expose
	private List<TravelerIdentifiers> travelerIdentifiers = null;
	@SerializedName("customElements")
    @Expose
	private List<CustomElements> customElements = null;
	@SerializedName("fromPS")
    @Expose
	private Boolean fromPS;
    @SerializedName("offerId")
    @Expose
    private String offerId;
	public String getProductCode() {
		return productCode;
	}
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getPlanCode() {
		return planCode;
	}
	public void setPlanCode(String planCode) {
		this.planCode = planCode;
	}
	public String getPlanId() {
		return planId;
	}
	public void setPlanId(String planId) {
		this.planId = planId;
	}
	public String getPlanName() {
		return planName;
	}
	public void setPlanName(String planName) {
		this.planName = planName;
	}
	public String getPlanDescription() {
		return planDescription;
	}
	public void setPlanDescription(String planDescription) {
		this.planDescription = planDescription;
	}
	public String getPurchaseDateTime() {
		return purchaseDateTime;
	}
	public void setPurchaseDateTime(String purchaseDateTime) {
		this.purchaseDateTime = purchaseDateTime;
	}
    public List<LoyaltyPrograms> getLoyaltyPrograms() {
        return (loyaltyPrograms != null) ? new ArrayList<LoyaltyPrograms>(loyaltyPrograms) : null;
    }
    public void setLoyaltyPrograms(List<LoyaltyPrograms> loyaltyPrograms) {
        this.loyaltyPrograms = (loyaltyPrograms != null) ? new ArrayList<LoyaltyPrograms>(loyaltyPrograms) : null;
   	}
	public List<Amounts> getAmounts() {
		return (amounts != null) ? new ArrayList<Amounts>(amounts) : null;
	}
	public void setAmounts(List<Amounts> amounts) {
		this.amounts = (amounts != null) ? new ArrayList<Amounts>(amounts) : null;
	}
	public List<ReferenceNumbers> getReferenceNumbers() {
		return (referenceNumbers != null) ? new ArrayList<ReferenceNumbers>(referenceNumbers) : null;
	}
	public void setReferenceNumbers(List<ReferenceNumbers> referenceNumbers) {
		this.referenceNumbers = (referenceNumbers != null) ? new ArrayList<ReferenceNumbers>(referenceNumbers) : null;
	}
	public List<Object> getFactors() {
		return (factors != null) ? new ArrayList<Object>(factors) : null;
	}
	public void setFactors(List<Object> factors) {
		this.factors = (factors != null) ? new ArrayList<Object>(factors) : null;
	}
	public List<BenefitDetails> getBenefitDetails() {
		return (benefitDetails != null) ? new ArrayList<BenefitDetails>(benefitDetails) : null;
	}
	public void setBenefitDetails(List<BenefitDetails> benefitDetails) {
		this.benefitDetails = (benefitDetails != null) ? new ArrayList<BenefitDetails>(benefitDetails) : null;
	}
	public List<TripIdentifiers> getTripIdentifiers() {
		return (tripIdentifiers != null) ? new ArrayList<TripIdentifiers>(tripIdentifiers) : null;
	}
	public void setTripIdentifiers(List<TripIdentifiers> tripIdentifiers) {
		this.tripIdentifiers = (tripIdentifiers != null) ? new ArrayList<TripIdentifiers>(tripIdentifiers) : null;
	}
	public List<TravelerIdentifiers> getTravelerIdentifiers() {
		return (travelerIdentifiers != null) ? new ArrayList<TravelerIdentifiers>(travelerIdentifiers) : null;
	}
	public void setTravelerIdentifiers(List<TravelerIdentifiers> travelerIdentifiers) {
		this.travelerIdentifiers = (travelerIdentifiers != null) ? new ArrayList<TravelerIdentifiers>(travelerIdentifiers) : null;
	}
	public List<CustomElements> getCustomElements() {
		return (customElements != null) ? new ArrayList<CustomElements>(customElements) : null;
	}
	public void setCustomElements(List<CustomElements> customElements) {
		this.customElements = (customElements != null) ? new ArrayList<CustomElements>(customElements) : null;
	}
	public Boolean getFromPS() {
		return fromPS;
	}
	public void setFromPS(Boolean fromPS) {
		this.fromPS = fromPS;
	}
    public String getOfferId() {
        return offerId;
    }
    public void setOfferId(String offerId) {
        this.offerId = offerId;
   	}

}
