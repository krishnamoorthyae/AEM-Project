package com.policy.models.quoteresponse;

import java.util.ArrayList;
import java.util.List;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class PurchaseRequest {
	@SerializedName("trips")
    @Expose
    private List<Trips> trips = null;
	@SerializedName("customElements")
    @Expose
	private List<CustomElements> customElements = null;
	@SerializedName("travelers")
    @Expose
    private List<Travelers> travelers = null;
	@SerializedName("productDetails")
    @Expose
    private List<ProductDetails> productDetails = null;
	@SerializedName("exchangeRateDetails")
    @Expose
	private List<Object> exchangeRateDetails = null;
	@SerializedName("paymentDetail")
    @Expose
    private PaymentDetail paymentDetail;
	@SerializedName("fulfillmentOption")
    @Expose
	private String fulfillmentOption;
    @SerializedName("accountDetail")
    @Expose
    private AccountDetail accountDetail;
    @SerializedName("submissionType")
    @Expose
    private String submissionType;
    @SerializedName("quoteId")
    @Expose
    private Integer quoteId;
	public List<Trips> getTrips() {
		return (trips != null) ? new ArrayList<Trips>(trips) : null;
	}
	public void setTrips(List<Trips> trips) {
		this.trips = (trips != null) ? new ArrayList<Trips>(trips) : null;
	}
	
	public List<ProductDetails> getProductDetails() {
		return (productDetails != null) ? new ArrayList<ProductDetails>(productDetails) : null;
	}
	public void setProductDetails(List<ProductDetails> productDetails) {
		this.productDetails = (productDetails != null) ? new ArrayList<ProductDetails>(productDetails) : null;
	}
	public AccountDetail getAccountDetail() {
		return accountDetail;
	}
	public void setAccountDetail(AccountDetail accountDetail) {
		this.accountDetail = accountDetail;
	}
	public String getFulfillmentOption() {
		return fulfillmentOption;
	}
	public void setFulfillmentOption(String fulfillmentOption) {
		this.fulfillmentOption = fulfillmentOption;
	}
	public String getSubmissionType() {
		return submissionType;
	}
	public void setSubmissionType(String submissionType) {
		this.submissionType = submissionType;
	}
	
	public List<Object> getExchangeRateDetails() {
		return (exchangeRateDetails != null) ? new ArrayList<Object>(exchangeRateDetails) : null;
	}
	public void setExchangeRateDetails(List<Object> exchangeRateDetails) {
		this.exchangeRateDetails = (exchangeRateDetails != null) ? new ArrayList<Object>(exchangeRateDetails) : null;
	}
	public List<Travelers> getTravelers() {
		return (travelers != null) ? new ArrayList<Travelers>(travelers) : null;
	}
	public void setTravelers(List<Travelers> travelers) {
		this.travelers = (travelers != null) ? new ArrayList<Travelers>(travelers) : null;
	}
	public Integer getQuoteId() {
		return quoteId;
	}
	public void setQuoteId(Integer quoteId) {
		this.quoteId = quoteId;
	}
	public List<CustomElements> getCustomElements() {
		return (customElements != null) ? new ArrayList<CustomElements>(customElements) : null;
	}
	public void setCustomElements(List<CustomElements> customElements) {
		this.customElements = (customElements != null) ? new ArrayList<CustomElements>(customElements) : null;
	}
	public PaymentDetail getPaymentDetail() {
		return paymentDetail;
	}
	public void setPaymentDetail(PaymentDetail paymentDetail) {
		this.paymentDetail = paymentDetail;
	}

}
