package com.policy.models.quoteresponse;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import static org.osgi.framework.Constants.BUNDLE_NATIVECODE_LANGUAGE;

import static org.osgi.framework.Constants.BUNDLE_NATIVECODE_LANGUAGE;

public class QuoteApiResponse {

	@SerializedName("quoteResponse")
    @Expose
    private QuoteResponse quoteResponse;
    @SerializedName("schemaVersion")
    @Expose
    private String schemaVersion;
    @SerializedName("partnerId")
    @Expose
    private String partnerId;
    @SerializedName("partnerSystemId")
    @Expose
    private String partnerSystemId;
    @SerializedName("partnerPos")
    @Expose
    private String partnerPos;
    @SerializedName(BUNDLE_NATIVECODE_LANGUAGE)
    @Expose
    private String language;
    @SerializedName("offerId")
    @Expose
    private String offerId;
	    
    public QuoteResponse getQuoteResponse() {
		return quoteResponse;
	}
	public void setQuoteResponse(QuoteResponse quoteResponse) {
		this.quoteResponse = quoteResponse;
	}
	public String getSchemaVersion() {
		return schemaVersion;
	}
	public void setSchemaVersion(String schemaVersion) {
		this.schemaVersion = schemaVersion;
	}
	public String getPartnerId() {
		return partnerId;
	}
	public void setPartnerId(String partnerId) {
		this.partnerId = partnerId;
	}
	public String getPartnerSystemId() {
		return partnerSystemId;
	}
	public void setPartnerSystemId(String partnerSystemId) {
		this.partnerSystemId = partnerSystemId;
	}
	public String getPartnerPos() {
		return partnerPos;
	}
	public void setPartnerPos(String partnerPos) {
		this.partnerPos = partnerPos;
	}
	public String getLanguage() {
		return language;
	}
	public void setLanguage(String language) {
		this.language = language;
	}
	public String getOfferId() {
		return offerId;
	}
	public void setOfferId(String offerId) {
		this.offerId = offerId;
	}

}
