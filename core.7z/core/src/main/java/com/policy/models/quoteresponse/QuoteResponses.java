package com.policy.models.quoteresponse;

import java.util.ArrayList;
import java.util.List;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.policy.models.detailresponse.TransactionLog;

public class QuoteResponses {
	@SerializedName("transactionLog")
    @Expose
    private TransactionLog transactionLog;
    @SerializedName("purchaseRequest")
    @Expose
    private PurchaseRequest purchaseRequest;
    @SerializedName("quoteContent")
    @Expose
    private QuoteContent quoteContent;
    @SerializedName("perTravelerPremiumDetails")
    @Expose
    private List<PerTravelerPremiumDetails> perTravelerPremiumDetails = null;
	public TransactionLog getTransactionLog() {
		return transactionLog;
	}
	public void setTransactionLog(TransactionLog transactionLog) {
		this.transactionLog = transactionLog;
	}
	public PurchaseRequest getPurchaseRequest() {
		return purchaseRequest;
	}
	public void setPurchaseRequest(PurchaseRequest purchaseRequest) {
		this.purchaseRequest = purchaseRequest;
	}
	public QuoteContent getQuoteContent() {
		return quoteContent;
	}
	public void setQuoteContent(QuoteContent quoteContent) {
		this.quoteContent = quoteContent;
	}
	public List<PerTravelerPremiumDetails> getPerTravelerPremiumDetails() {
		return (perTravelerPremiumDetails != null) ? new ArrayList<PerTravelerPremiumDetails>(perTravelerPremiumDetails) : null;
	}
	public void setPerTravelerPremiumDetails(List<PerTravelerPremiumDetails> perTravelerPremiumDetails) {
		this.perTravelerPremiumDetails = (perTravelerPremiumDetails != null) ? new ArrayList<PerTravelerPremiumDetails>(perTravelerPremiumDetails) : null;
	}
	
}
