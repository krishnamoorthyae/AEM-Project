package com.policy.models.quoteresponse;

import java.util.ArrayList;
import java.util.List;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class TransactionLog {

	@SerializedName("transactionStatus")
    @Expose
	private String transactionStatus;
	@SerializedName("messages")
    @Expose
	private List<Messages> messages = null;
	public String getTransactionStatus() {
		return transactionStatus;
	}
	public void setTransactionStatus(String transactionStatus) {
		this.transactionStatus = transactionStatus;
	}
	public List<Messages> getMessages() {
		return (messages != null) ? new ArrayList<Messages>(messages) : null;
	}
	public void setMessages(List<Messages> messages) {
		this.messages = (messages != null) ? new ArrayList<Messages>(messages) : null;
	}
}
