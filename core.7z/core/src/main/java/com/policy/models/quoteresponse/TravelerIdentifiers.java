package com.policy.models.quoteresponse;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class TravelerIdentifiers {

	@SerializedName("travelerIdentifier")
    @Expose
	private String travelerIdentifier;
	@SerializedName("insuredType")
    @Expose
	private String insuredType;
	public String getTravelerIdentifier() {
		return travelerIdentifier;
	}
	public void setTravelerIdentifier(String travelerIdentifier) {
		this.travelerIdentifier = travelerIdentifier;
	}
	public String getInsuredType() {
		return insuredType;
	}
	public void setInsuredType(String insuredType) {
		this.insuredType = insuredType;
	}
}
