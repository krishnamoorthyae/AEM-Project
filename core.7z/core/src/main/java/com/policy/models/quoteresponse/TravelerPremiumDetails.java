package com.policy.models.quoteresponse;

import java.util.ArrayList;
import java.util.List;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class TravelerPremiumDetails {

	@SerializedName("benefitCode")
    @Expose
	private String benefitCode;
	@SerializedName("benefitName")
    @Expose
	private String benefitName;
	@SerializedName("amounts")
    @Expose
	private List<Amounts> amounts = null;
	public String getBenefitCode() {
		return benefitCode;
	}
	public void setBenefitCode(String benefitCode) {
		this.benefitCode = benefitCode;
	}
	public String getBenefitName() {
		return benefitName;
	}
	public void setBenefitName(String benefitName) {
		this.benefitName = benefitName;
	}
	public List<Amounts> getAmounts() {
		return (amounts != null) ? new ArrayList<Amounts>(amounts) : null;
	}
	public void setAmounts(List<Amounts> amounts) {
		this.amounts = (amounts != null) ? new ArrayList<Amounts>(amounts) : null;
	}
}
