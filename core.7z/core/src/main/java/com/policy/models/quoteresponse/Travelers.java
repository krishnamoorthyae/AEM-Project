package com.policy.models.quoteresponse;

import java.util.ArrayList;
import java.util.List;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Travelers {

	@SerializedName("travelerIdentifier")
    @Expose
	private String travelerIdentifier;
	@SerializedName("insuredType")
    @Expose
	private String insuredType;
	@SerializedName("passengerType")
    @Expose
	private String passengerType;
	@SerializedName("restrictedCountryCertification")
    @Expose
	private String restrictedCountryCertification;
	@SerializedName("restrictedCountryReasonCode")
    @Expose
	private String restrictedCountryReasonCode;
	@SerializedName("deductible")
	@Expose
	private Integer deductible;
	@SerializedName("medicalScore")
	@Expose
	private Double medicalScore;
	@SerializedName("loyaltyPrograms")
    @Expose
	private List<Object> loyaltyPrograms = null;
	@SerializedName("customElements")
    @Expose
	private List<CustomElements> customElements = null;
	@SerializedName("travelerTripPrice")
    @Expose
	private List<TravelerTripPrice> travelerTripPrice = null;
	@SerializedName("beneficiaries")
    @Expose
	private List<Beneficiaries> beneficiaries = null;
	@SerializedName("prefix")
    @Expose
	private String prefix;
	@SerializedName("firstName")
    @Expose
	private String firstName;
	@SerializedName("middleName")
    @Expose
	private String middleName;
	@SerializedName("lastName")
    @Expose
	private String lastName;
	@SerializedName("suffix")
    @Expose
	private String suffix;
	@SerializedName("dateOfBirth")
    @Expose
	private String dateOfBirth;
	@SerializedName("gender")
    @Expose
	private String gender;
	@SerializedName("identifications")
    @Expose
	private String identifications;
	@SerializedName("addresses")
    @Expose
	private List<Addresses> addresses = null;
	@SerializedName("contactDetails")
    @Expose
	private List<ContactDetails> contactDetails = null;
	public String getTravelerIdentifier() {
		return travelerIdentifier;
	}
	public void setTravelerIdentifier(String travelerIdentifier) {
		this.travelerIdentifier = travelerIdentifier;
	}
	public String getInsuredType() {
		return insuredType;
	}
	public void setInsuredType(String insuredType) {
		this.insuredType = insuredType;
	}
	public String getPassengerType() {
		return passengerType;
	}
	public void setPassengerType(String passengerType) {
		this.passengerType = passengerType;
	}
	public String getRestrictedCountryCertification() {
		return restrictedCountryCertification;
	}
	public void setRestrictedCountryCertification(String restrictedCountryCertification) {
		this.restrictedCountryCertification = restrictedCountryCertification;
	}
	public String getRestrictedCountryReasonCode() {
		return restrictedCountryReasonCode;
	}
	public void setRestrictedCountryReasonCode(String restrictedCountryReasonCode) {
		this.restrictedCountryReasonCode = restrictedCountryReasonCode;
	}
	public List<Object> getLoyaltyPrograms() {
		return (loyaltyPrograms != null) ? new ArrayList<Object>(loyaltyPrograms) : null;
	}
	public void setLoyaltyPrograms(List<Object> loyaltyPrograms) {
		this.loyaltyPrograms = (loyaltyPrograms != null) ? new ArrayList<Object>(loyaltyPrograms) : null;
	}
	public List<CustomElements> getCustomElements() {
		return (customElements != null) ? new ArrayList<CustomElements>(customElements) : null;
	}
	public void setCustomElements(List<CustomElements> customElements) {
		this.customElements = (customElements != null) ? new ArrayList<CustomElements>(customElements) : null;
	}
	public List<TravelerTripPrice> getTravelerTripPrice() {
		return (travelerTripPrice != null) ? new ArrayList<TravelerTripPrice>(travelerTripPrice) : null;
	}
	public void setTravelerTripPrice(List<TravelerTripPrice> travelerTripPrice) {
		this.travelerTripPrice = (travelerTripPrice != null) ? new ArrayList<TravelerTripPrice>(travelerTripPrice) : null;
	}
	public List<Beneficiaries> getBeneficiaries() {
		return (beneficiaries != null) ? new ArrayList<Beneficiaries>(beneficiaries) : null;
	}
	public void setBeneficiaries(List<Beneficiaries> beneficiaries) {		
		this.beneficiaries = (beneficiaries != null) ? new ArrayList<Beneficiaries>(beneficiaries) : null;
	}
	public String getPrefix() {
		return prefix;
	}
	public void setPrefix(String prefix) {
		this.prefix = prefix;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getMiddleName() {
		return middleName;
	}
	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getSuffix() {
		return suffix;
	}
	public void setSuffix(String suffix) {
		this.suffix = suffix;
	}
	public String getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getIdentifications() {
		return identifications;
	}
	public void setIdentifications(String identifications) {
		this.identifications = identifications;
	}
	public List<Addresses> getAddresses() {
		return (addresses != null) ? new ArrayList<Addresses>(addresses) : null;
	}
	public void setAddresses(List<Addresses> addresses) {
		this.addresses = (addresses != null) ? new ArrayList<Addresses>(addresses) : null;
	}
	public List<ContactDetails> getContactDetails() {
		return (contactDetails != null) ? new ArrayList<ContactDetails>(contactDetails) : null;
	}
	public void setContactDetails(List<ContactDetails> contactDetails) {
		this.contactDetails = (contactDetails != null) ? new ArrayList<ContactDetails>(contactDetails) : null;
	}
	public Integer getDeductible() {
		return deductible;
	}
	public void setDeductible(Integer deductible) {
		this.deductible = deductible;
	}
	public Double getMedicalScore() {
		return medicalScore;
	}
	public void setMedicalScore(Double medicalScore) {
		this.medicalScore = medicalScore;
	}
}
