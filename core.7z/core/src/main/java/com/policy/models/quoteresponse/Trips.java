package com.policy.models.quoteresponse;

import java.util.ArrayList;
import java.util.List;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Trips {
	
	@SerializedName("tripIdentifier")
    @Expose
	private String tripIdentifier;
	@SerializedName("tripType")
    @Expose
	private String tripType;
	@SerializedName("bookingType")
    @Expose
	private String bookingType;
	@SerializedName("initialDepositDate")
    @Expose
	private String initialDepositDate;
	@SerializedName("finalPaymentDate")
    @Expose
	private String finalPaymentDate;
	@SerializedName("totalTripPrice")
    @Expose
	private List<TotalTripPrice> totalTripPrice = null;
	@SerializedName("referenceNumbers")
    @Expose
	private List<ReferenceNumbers> referenceNumbers = null;
	@SerializedName("bookingItems")
    @Expose
	private List<BookingItems> bookingItems = null;
	@SerializedName("customElements")
    @Expose
	private List<CustomElements> customElements = null;
	@SerializedName("totalInsured")
    @Expose
	private Integer totalInsured;
	@SerializedName("totalInfants")
    @Expose
	private Integer totalInfants;
	public String getTripIdentifier() {
		return tripIdentifier;
	}
	public void setTripIdentifier(String tripIdentifier) {
		this.tripIdentifier = tripIdentifier;
	}
	public String getTripType() {
		return tripType;
	}
	public void setTripType(String tripType) {
		this.tripType = tripType;
	}
	public String getBookingType() {
		return bookingType;
	}
	public void setBookingType(String bookingType) {
		this.bookingType = bookingType;
	}
	public String getInitialDepositDate() {
		return initialDepositDate;
	}
	public void setInitialDepositDate(String initialDepositDate) {
		this.initialDepositDate = initialDepositDate;
	}
	public String getFinalPaymentDate() {
		return finalPaymentDate;
	}
	public void setFinalPaymentDate(String finalPaymentDate) {
		this.finalPaymentDate = finalPaymentDate;
	}
	public List<TotalTripPrice> getTotalTripPrice() {
		return (totalTripPrice != null) ? new ArrayList<TotalTripPrice>(totalTripPrice) : null;
	}
	public void setTotalTripPrice(List<TotalTripPrice> totalTripPrice) {
		this.totalTripPrice = (totalTripPrice != null) ? new ArrayList<TotalTripPrice>(totalTripPrice) : null;
	}
	public List<ReferenceNumbers> getReferenceNumbers() {
		return (referenceNumbers != null) ? new ArrayList<ReferenceNumbers>(referenceNumbers) : null;
	}
	public void setReferenceNumbers(List<ReferenceNumbers> referenceNumbers) {
		this.referenceNumbers = (referenceNumbers != null) ? new ArrayList<ReferenceNumbers>(referenceNumbers) : null;
	}
	public List<BookingItems> getBookingItems() {
		return (bookingItems != null) ? new ArrayList<BookingItems>(bookingItems): null;
	}
	public void setBookingItems(List<BookingItems> bookingItems) {
		this.bookingItems = (bookingItems != null) ? new ArrayList<BookingItems>(bookingItems): null;
	}
	public List<CustomElements> getCustomElements() {
		return (customElements != null) ? new ArrayList<CustomElements>(customElements) : null;
	}
	public void setCustomElements(List<CustomElements> customElements) {
		this.customElements = (customElements != null) ? new ArrayList<CustomElements>(customElements) : null;
	}
	public Integer getTotalInsured() {
		return totalInsured;
	}
	public void setTotalInsured(Integer totalInsured) {
		this.totalInsured = totalInsured;
	}
	public Integer getTotalInfants() {
		return totalInfants;
	}
	public void setTotalInfants(Integer totalInfants) {
		this.totalInfants = totalInfants;
	}
	
}
