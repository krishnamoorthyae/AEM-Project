package com.policy.servlets;

import java.io.IOException;
import java.io.OutputStream;
import javax.servlet.Servlet;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletResponse;

import com.day.cq.search.QueryBuilder;
import com.tgfoundation.core.models.SecretsManager;
import com.tgfoundation.core.utils.DataDictionary;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.servlets.HttpConstants;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.apache.sling.servlets.annotations.SlingServletPaths;
import org.osgi.framework.Constants;
import org.osgi.service.cm.Configuration;
import org.osgi.service.cm.ConfigurationAdmin;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.Marker;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.tgfoundation.core.models.functionality.HttpUtilResponse;
import com.tgfoundation.core.exceptions.MyOwnRuntimeException;
import com.tgfoundation.core.utils.HttpUtil;
import com.tgfoundation.core.utils.session.SessionStorage;
import com.policy.models.detailresponse.TravelApiResponse;
import com.policy.models.InsuranceCalculations;

@Component(
        service=Servlet.class,
        property={
                Constants.SERVICE_DESCRIPTION + "=policy validate surname with policy number",
                "sling.servlet.methods=" + HttpConstants.METHOD_POST
        })
@SlingServletPaths("/bin/policy/validateSurname/v4")

public class PolicyLookUp extends SlingAllMethodsServlet {
	private static final long serialVersionUID = 1L;
	private static Logger log = LoggerFactory.getLogger(PolicyLookUp.class);
	private static Marker marker;
	
	@Reference
	private transient ConfigurationAdmin configAdmin;

    @Reference
    private transient QueryBuilder queryBuilder;

    @Reference
    private transient SecretsManager secretsManager;
	
	@Override
	protected void doPost(SlingHttpServletRequest request, SlingHttpServletResponse response) throws ServletException, IOException {
		try {
			String validateSurnameReq = request.getParameter("data");
			String configFile = request.getParameter("configFile");
			String configConcat = "com.travelguard.".concat(configFile);

			Configuration conf = configAdmin.getConfiguration(configConcat);				
			HttpUtil httpUtil = new HttpUtil(conf, request.getParameter("proxy"), secretsManager);
			httpUtil.setConfigAdmin( configAdmin );
			httpUtil.setJWT(request);

            DataDictionary dictionary = new DataDictionary( queryBuilder );
            dictionary.getDataDictionary( request );

			Gson gson = new Gson();
			JsonObject validateSurnameObj = gson.fromJson(validateSurnameReq, JsonObject.class);
			httpUtil.setProxyPath(httpUtil.getProxyPath().replace("{policyNumber}", validateSurnameObj.get("policyNumber").getAsString())
														 .replace("{lastName}", validateSurnameObj.get("lastName").getAsString().replace(" ", "%20")));

			HttpUtilResponse httpUtilResponse = httpUtil.executeGet();
			httpUtil.setSlingResponseHeaders(response, httpUtilResponse);

			if (httpUtilResponse.getStatus() == 200) {
				final OutputStream out = response.getOutputStream();

				if(validateSurnameObj.get("policyNumber").getAsString().contains("as/purchase")){
					out.write(httpUtilResponse.getBody().getBytes());
				}
				else{
					InsuranceCalculations insuranceCalculations = new InsuranceCalculations();
					TravelApiResponse travelApiResponse = insuranceCalculations.getCalculations(httpUtilResponse);

					ObjectMapper obj = new ObjectMapper();
					String travelApiStringResponse = obj.writeValueAsString(travelApiResponse);

					SessionStorage sessionStorage = new SessionStorage();
					sessionStorage.setItem(request, "policyDetail", travelApiStringResponse);
					out.write(travelApiStringResponse.getBytes());
				}
			}
			else{
				throw new MyOwnRuntimeException(httpUtilResponse.getBody());
			}

		}
        catch (RuntimeException e) {
			log.error(marker, "PolicyLookUp Servlet Error - RuntimeException: {}", e.getMessage());
			response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
		}
        catch (MyOwnRuntimeException e) {
			log.error(marker, "PolicyLookUp Servlet Error - MyOwnRuntimeException: {}", e.getMessage());
			response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
		}
        catch (IOException e) {
			log.error(marker, "PolicyLookUp Servlet Error - IOException: {}", e.getMessage());
			response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
		}
	}
}
