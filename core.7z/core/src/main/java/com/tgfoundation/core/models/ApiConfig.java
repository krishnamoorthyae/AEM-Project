package com.tgfoundation.core.models;

public interface ApiConfig {
    public String getApiConfig();
}
