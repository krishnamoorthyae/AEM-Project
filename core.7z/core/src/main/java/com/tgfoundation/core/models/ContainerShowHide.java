package com.tgfoundation.core.models;

public interface ContainerShowHide {

    public String getShowHideJson();

    public String getEditorString();
}
