package com.tgfoundation.core.models;

public interface GenericListItem {

    public String getValue();

    public String getTitle();

    public void setValue(String value);

    public void setTitle(String Title);
}
