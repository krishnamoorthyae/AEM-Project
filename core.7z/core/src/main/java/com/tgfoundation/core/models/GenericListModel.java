package com.tgfoundation.core.models;

import java.util.List;

public interface GenericListModel {
    public List<GenericListItem> getItems();
}
