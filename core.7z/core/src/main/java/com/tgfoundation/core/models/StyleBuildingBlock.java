package com.tgfoundation.core.models;

import java.util.Map;

public interface StyleBuildingBlock {
    public Map<String, Map<String, String>> getStyleGroups();
}
