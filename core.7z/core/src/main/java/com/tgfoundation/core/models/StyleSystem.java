package com.tgfoundation.core.models;

import java.util.List;

public interface StyleSystem {
    public String getComponentId();

    public List<StyleBuildingBlockGroup> getStyleGroups();

    public List<StyleShortcutGroup> getShortcutGroups();

    public String getSelectedStyleBuildingBlocks();

    public List<String> getSelectedShortcuts();
}
