package com.tgfoundation.core.models.content;

import com.google.gson.JsonArray;

public interface ApiContentFragment {
    public String getMethod();

    public String getEndpoint();

    public Boolean isAsync();

    public String getConfigFileName();

    public String getProxyPathKey();

    public String getJwt();

    public JsonArray getDataReferencePath();

    public JsonArray getSuccessFunctionJson();

    public JsonArray getErrorFunctionJson();
}
