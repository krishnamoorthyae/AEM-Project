package com.tgfoundation.core.models.content;

import com.google.gson.JsonArray;

public interface ObjectConfig {
    public Boolean isArrayTemplate();

    public JsonArray getObjectJson();
}
