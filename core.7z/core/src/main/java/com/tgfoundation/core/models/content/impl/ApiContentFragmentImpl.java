package com.tgfoundation.core.models.content.impl;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.tgfoundation.core.models.content.ApiContentFragment;
import com.tgfoundation.core.models.content.ObjectConfig;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.SlingObject;
import javax.annotation.PostConstruct;
import javax.inject.Inject;
import javax.jcr.RepositoryException;

@Model(
        adaptables = {SlingHttpServletRequest.class, Resource.class},
        adapters = {ApiContentFragment.class},
        defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL
)
public class ApiContentFragmentImpl implements ApiContentFragment {
    @SlingObject
    private Resource resource;

    @Inject
    private ResourceResolver resourceResolver;

    private String method = "";

    private String endpoint = "";

    private Boolean async = false;

    private String configFileName = "";

    private String proxyPathKey = "";

    private String jwt = "";

    JsonArray dataFragments = new JsonArray();

    JsonArray successConfig = new JsonArray();

    JsonArray errorConfig = new JsonArray();

    @PostConstruct
    public void init() throws RepositoryException {
        if (resource == null) return;

        Resource master = resourceResolver.getResource(resource.getPath() + "/jcr:content/data/master");

        if (master == null) return;

        ValueMap valueMap = master.getValueMap();
        if (valueMap == null) return;

        Object methodObj = valueMap.get("method");
        if (methodObj != null) {
            method = methodObj.toString();
        }

        Object endpointObj = valueMap.get("endpoint");
        if (endpointObj != null) {
            endpoint = endpointObj.toString();
        }

        Object asyncObj = valueMap.get("async");
        if (asyncObj != null) {
            async = "true".equals(asyncObj.toString());
        }

        Object configFileObj = valueMap.get("configFile");
        if (configFileObj != null) {
            configFileName = configFileObj.toString();
        }

        Object proxyPathKeyObj = valueMap.get("proxyPath");
        if (proxyPathKeyObj != null) {
            proxyPathKey = proxyPathKeyObj.toString();
        }

        Object jwtObj = valueMap.get("jwt");
        if (jwtObj != null) {
            jwt = jwtObj.toString();
        }

        String[] dataArray = getArray(valueMap, "data");
        if(dataArray != null) {
            for( String path : dataArray ) {
                Resource dataResource = resourceResolver.getResource( path.concat("/jcr:content/data/master" ) );
                ObjectConfig objectConfig = dataResource.adaptTo( ObjectConfig.class );

                JsonObject jsonObject = new JsonObject();
                jsonObject.addProperty("isArrayTemplate", objectConfig.isArrayTemplate());
                jsonObject.add( "object", objectConfig.getObjectJson() );

                dataFragments.add( jsonObject );
            }
        }

        String[] errorArray = getArray(valueMap, "errorConditionCMF");
        if( errorArray != null ) {
            for( String err : errorArray ) {
                JsonObject errObject = generateErrorObject( JsonParser.parseString( err ).getAsJsonObject() );
                errorConfig.add( errObject );
            }
        }

        String[] successArray = getArray(valueMap, "successConditionCMF");
        if( successArray != null ) {
            for( String succ : successArray ) {
                JsonObject successObject = generateSuccessObject( JsonParser.parseString( succ ).getAsJsonObject() );
                successConfig.add( successObject );
            }
        }
    }

    private JsonObject generateErrorObject( JsonObject obj ) {
        JsonObject jsonVal = new JsonObject();

        JsonElement functionElem = obj.get( "errorFunctionCall" );
        if( functionElem != null ) {
            jsonVal.addProperty("function", functionElem.getAsString());
        }

        JsonElement paramElem = obj.get( "errorParameterPath" );
        if( paramElem != null ) {
            jsonVal.addProperty("parameters", paramElem.getAsString());
        }

        return jsonVal;
    }

    private JsonObject generateSuccessObject( JsonObject obj ) {
        JsonObject jsonVal = new JsonObject();

        JsonObject condition = new JsonObject();
        JsonElement successCondition = obj.get( "successCondition" );
        if( successCondition != null ) {
            condition.addProperty("variable", successCondition.getAsString());
        }

        JsonElement successConditionOperator = obj.get( "successConditionOperator" );
        if( successConditionOperator != null ) {
            condition.addProperty("operator", successConditionOperator.getAsString());
        }

        JsonElement successConditionValue = obj.get( "successConditionValue" );
        if( successConditionValue != null ) {
            condition.addProperty("value", successConditionValue.getAsString());
        }
        jsonVal.add("condition", condition );

        JsonElement functionElem = obj.get( "successFunctionCall" );
        if( functionElem != null ) {
            jsonVal.addProperty("function", functionElem.getAsString());
        }

        JsonElement paramElem = obj.get( "parameterPath" );
        if( paramElem != null ) {
            jsonVal.addProperty("parameters", paramElem.getAsString());
        }

        return jsonVal;
    }

    private String[] getArray(ValueMap valueMap, String name) {
        return valueMap.get(name, String[].class);
    }

    @Override
    public String getMethod() {
        return method;
    }

    @Override
    public String getEndpoint() {
        return endpoint;
    }

    @Override
    public Boolean isAsync() {
        return async;
    }

    @Override
    public String getConfigFileName() {
        return configFileName;
    }

    @Override
    public String getProxyPathKey() {
        return proxyPathKey;
    }

    @Override
    public String getJwt() {
        return jwt;
    }

    @Override
    public JsonArray getDataReferencePath() {
        return dataFragments;
    }

    @Override
    public JsonArray getSuccessFunctionJson() {
        return successConfig;
    }

    @Override
    public JsonArray getErrorFunctionJson() {
        return errorConfig;
    }
}
