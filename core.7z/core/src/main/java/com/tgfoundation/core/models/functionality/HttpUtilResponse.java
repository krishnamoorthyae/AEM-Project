package com.tgfoundation.core.models.functionality;

import org.apache.http.HttpResponse;

public interface HttpUtilResponse {
    public int getStatus();

    public void setStatus(int status);

    public String getBody();
    //setters
    public void setBody(String body);

    public HttpResponse getResponse();

    public void setResponse(HttpResponse response);
}