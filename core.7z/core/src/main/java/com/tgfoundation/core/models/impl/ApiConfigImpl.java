package com.tgfoundation.core.models.impl;

import com.day.cq.search.QueryBuilder;
import com.day.cq.search.result.Hit;
import com.day.cq.search.result.SearchResult;
import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.tgfoundation.core.models.ApiConfig;
import com.tgfoundation.core.models.content.ApiContentFragment;
import com.tgfoundation.core.utils.ContentFragmentLookup;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.SlingObject;
import javax.annotation.PostConstruct;
import javax.inject.Inject;
import javax.jcr.RepositoryException;
import java.util.List;

@Model(
        adaptables = {SlingHttpServletRequest.class, Resource.class},
        adapters = {ApiConfig.class},
        defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL
)
public class ApiConfigImpl implements ApiConfig {
    @SlingObject
    private Resource resource;

    @Inject
    private ResourceResolver resourceResolver;

    @Inject
    private QueryBuilder queryBuilder;

    private String apiConfig = "";

    @PostConstruct
    public void init() throws RepositoryException {
        if( resource == null ) return;

        ValueMap valueMap = resource.getValueMap();

        String feature = getMapStringValue( valueMap, "feature" );
        String actionType = getMapStringValue( valueMap, "actionType" );
        String applicationType = getMapStringValue( valueMap, "applicationType" );

        if( !actionType.isEmpty() ) {
            actionType = "/".concat( actionType );
        }

        if( !applicationType.isEmpty() ) {
            applicationType = "/".concat( applicationType );
        }

        String defaultTag = feature.concat( actionType ).concat( "/default" );
        String overrideTag = feature.concat( actionType ).concat( applicationType );

        generateContentFragmentJSON( defaultTag, overrideTag );
    }

    private String getMapStringValue(ValueMap valueMap, String name) {
        Object featureObj = valueMap.get(name);
        if( featureObj != null ) {
            return featureObj.toString();
        }
        return "";
    }

    private void generateContentFragmentJSON( String defaultTag, String overrideTag ) throws RepositoryException {
        JsonObject defaultObj = getUniqueJson( defaultTag );
        JsonObject overrideObj = getUniqueJson( overrideTag );

        JsonObject mergedObj = mergeJsonObjects( defaultObj, overrideObj );
        if( mergedObj != null ) {
            apiConfig = (new Gson()).toJson( mergedObj );
        }
    }

    private JsonObject mergeJsonObjects( JsonObject object1, JsonObject object2 ) {
        if( object1 == null && object2 == null ) return null;
        else if(object1 == null) return object2;
        else if(object2 == null) return object1;

        JsonObject mergedObj = new JsonObject();

        for( String key : object1.keySet() ) {
            JsonElement value1 = object1.get( key );

            if( object2.has( key ) ) {
                JsonElement value2 = object2.get( key );

                if( value1.isJsonObject() && value2.isJsonObject() ) {
                    mergedObj.add( key, mergeJsonObjects( value1.getAsJsonObject(), value2.getAsJsonObject() ) );
                }
                else if(value2.isJsonArray() && !value2.getAsJsonArray().isEmpty()){
                    mergedObj.add( key, value2 );
                }
                else if (value2.isJsonArray() || (value2.isJsonPrimitive() && value2.getAsString().isEmpty())){
                    mergedObj.add( key, value1 );
                }
                else {
                    mergedObj.add( key, value2 );
                }
            }
            else {
                mergedObj.add( key, value1 );
            }
        }

        for( String key : object2.keySet() ) {
            if( !mergedObj.has( key ) ) {
                mergedObj.add( key, object2.get( key ) );
            }
        }

        return mergedObj;
    }

    private JsonObject getUniqueJson( String tag ) throws RepositoryException {
        JsonObject jsonObject = new JsonObject();

        String CONTENT_FRAGMENT_PATH = "/content/dam/config";
        if( tag.startsWith("/") ) {
            tag = tag.substring(1);
        }
        String lookupTag = "/content/cq:tags/config/api/".concat( tag );

        ContentFragmentLookup lookup = new ContentFragmentLookup( queryBuilder );
        List<Hit> hitList = lookup.lookupFragmentByTag( resourceResolver, CONTENT_FRAGMENT_PATH, lookupTag);

        for( Hit hit : hitList ) {
            Resource hitResource = hit.getResource();
            ApiContentFragment config = hitResource.adaptTo(ApiContentFragment.class);

            assert config != null;
            jsonObject.addProperty( "configFile", config.getConfigFileName() );
            jsonObject.addProperty( "method", config.getMethod() );
            jsonObject.addProperty( "endpoint", config.getEndpoint() );
            jsonObject.addProperty( "jwt", config.getJwt() );
            jsonObject.addProperty( "proxyPath", config.getProxyPathKey() );
            jsonObject.add( "data", config.getDataReferencePath() );
            jsonObject.add( "success", config.getSuccessFunctionJson() );
            jsonObject.add( "error", config.getErrorFunctionJson() );
        }

        return jsonObject;
    }

    @Override
    public String getApiConfig() {
        return apiConfig;
    }
}
