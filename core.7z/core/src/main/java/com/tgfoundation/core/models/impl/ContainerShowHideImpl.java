package com.tgfoundation.core.models.impl;

import com.tgfoundation.core.models.ContainerShowHide;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.SlingObject;
import javax.annotation.PostConstruct;
import javax.inject.Inject;
import javax.jcr.RepositoryException;
import java.util.Iterator;

@Model(
        adaptables = {SlingHttpServletRequest.class, Resource.class},
        adapters = {ContainerShowHide.class},
        defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL
)
public class ContainerShowHideImpl implements ContainerShowHide {
    @SlingObject
    private Resource resource;

    @Inject
    private ResourceResolver resourceResolver;

    private String jsonValues = "";

    @PostConstruct
    public void init() throws RepositoryException {
        if( resource == null ) return;

        Resource showHide = resourceResolver.getResource( resource.getPath() + "/showHideItems");
        if( showHide == null ) return;

        Iterator<Resource> iterator = showHide.listChildren();
        while ( iterator.hasNext() ) {
            Resource item = iterator.next();
            ValueMap valueMap = item.getValueMap();
            String temp = "";

            if( valueMap.get( "openParenthesis" ) != null ) {
                temp = temp.concat(" ( " );
            }

            temp = temp.concat(" [[ " );

            String source = valueMap.get( "source", String.class );
            if( source == null ) continue;

            String operand = valueMap.get( "operands", String.class );
            if( operand == null ) continue;

            String showHideData = valueMap.get( "showHideData", String.class );

            if( "clientSession".equals( source ) ) {
                String sessionName = valueMap.get( "sessionName", String.class );
                if( sessionName == null || showHideData == null ) break;

                temp = temp.concat(" clientSession~~" ).concat( sessionName ).concat( " " );
                temp = temp.concat("]]operand~~" ).concat( operand ).concat( "]]" );
                temp = temp.concat(" value~~" ).concat( showHideData ).concat( " " );
            }
            else {
                String dataDropdownValue = valueMap.get( "dataDropdownValue", String.class );
                if( dataDropdownValue != null ) {
                    temp = temp.concat(" options~~" ).concat( source ).concat( " " );
                    temp = temp.concat("]]operand~~" ).concat( operand ).concat( "]]" );
                    temp = temp.concat(" value~~" ).concat( dataDropdownValue ).concat( " " );
                }
                else {
                    if( showHideData == null ) break;

                    temp = temp.concat(" input~~" ).concat( source ).concat( " " );
                    temp = temp.concat("]]operand~~" ).concat( operand ).concat( "]]" );
                    temp = temp.concat(" value~~" ).concat( showHideData ).concat( " " );
                }
            }

            temp = temp.concat(" [[ " );

            if( valueMap.get( "closeParenthesis" ) != null ) {
                temp = temp.concat(" ) " );
            }

            if( iterator.hasNext() ) {
                String andor = valueMap.get( "andor", String.class );
                if( "or".equals( andor ) ) {
                    temp = temp.concat(" || " );
                }
                else if( "and".equals( andor ) ) {
                    temp = temp.concat(" && " );
                }
            }

            jsonValues = jsonValues.concat( temp );
        }
    }

    @Override
    public String getShowHideJson() {
        return jsonValues;
    }

    @Override
    public String getEditorString() {
        return jsonValues.replace("[[", "").replace("options:", "").replace("input:", "").replace("clientSession:", "").replace("value:", "").replace("&&", "and").replace("||", "or").replace("operand:", "").replace("~~", "=").replace("]]", " ").replace("input=", "").replace("operand=", "").replace("value=", "");
    }
}
