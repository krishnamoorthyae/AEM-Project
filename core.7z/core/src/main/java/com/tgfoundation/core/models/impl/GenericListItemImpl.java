package com.tgfoundation.core.models.impl;

import com.tgfoundation.core.models.GenericListItem;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.SlingObject;
import javax.annotation.PostConstruct;
import javax.jcr.RepositoryException;

@Model(
        adaptables = {SlingHttpServletRequest.class, Resource.class},
        adapters = {GenericListItem.class},
        defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL
)
public class GenericListItemImpl implements GenericListItem {
    @SlingObject
    private Resource resource;

    private String title;

    private String value;

    @PostConstruct
    public void init() throws RepositoryException {
        if( resource == null ) return;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    @Override
    public String getValue() {
        return value;
    }

    @Override
    public String getTitle() {
        return title;
    }
}
