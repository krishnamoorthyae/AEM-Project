package com.tgfoundation.core.models.impl;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.tgfoundation.core.models.GenericListItem;
import com.tgfoundation.core.models.GenericListModel;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.RequestAttribute;
import org.apache.sling.models.annotations.injectorspecific.SlingObject;
import javax.annotation.PostConstruct;
import javax.inject.Inject;
import javax.jcr.RepositoryException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

@Model(
        adaptables = {SlingHttpServletRequest.class, Resource.class},
        adapters = {GenericListModel.class},
        defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL
)
public class GenericListModelImpl implements GenericListModel {
    @SlingObject
    private Resource resource;

    @Inject
    private ResourceResolver resourceResolver;

    @RequestAttribute
    private String list;

    private List<GenericListItem> listItems = new ArrayList<>();

    @PostConstruct
    public void init() throws RepositoryException {
        if( resource == null ) return;

        if( list != null ) {
            Resource listResource = resourceResolver.getResource( list + "/jcr:content/data" );

            createGenericListItems( listResource );
        }
        else {
            Resource listResource = resourceResolver.getResource( resource.getPath() + "/jcr:content/data" );

            createGenericListItems( listResource );
        }
    }

    private void createGenericListItems( Resource listResource ) {
        if( listResource == null ) return;

        ValueMap fragmentMap = listResource.getValueMap();
        String model = fragmentMap.get("cq:model", String.class);

        String[] listArr = null;
        Resource master = listResource.getChild("master");

        if( master == null ) return;

        ValueMap valueMap = master.getValueMap();

        if( "/conf/tgfoundation/settings/dam/cfm/models/multi-variate-content".equals( model ) ) {
            String modelItems = "/jcr:content/model/cq:dialog/content/items";
            Resource modelResource = resourceResolver.getResource( model + modelItems );

            if( modelResource == null ) return;

            Iterator<Resource> iterator = modelResource.listChildren();
            List<String> list = new ArrayList<>();
            while( iterator.hasNext() ) {
                Resource r = iterator.next();
                ValueMap v = r.getValueMap();

                String title = v.get("name", String.class);

                if( title == null ) continue;

                String value = valueMap.get( title, String.class );

                if( value == null || value.isEmpty() ) continue;

                String item = "{\"title\":\"" + title + "\",\"value\":\"" + value + "\"}";
                list.add( item );
            }
            listArr = list.toArray( new String[]{} );
        }
        else {
            listArr = valueMap.get("genericListCMF", String[].class);
        }

        if( listArr == null ) return;

        JsonArray array = JsonParser.parseString( Arrays.toString( listArr ) ).getAsJsonArray();
        for(JsonElement element : array ) {
            JsonObject object = element.getAsJsonObject();
            GenericListItem genericListItem = new GenericListItemImpl();
            if( object.get("title") != null ) {
                if( object.get("value") == null ) {
                    genericListItem.setValue( "" );
                }
                else {
                    genericListItem.setValue( object.get("value").getAsString() );
                }
                genericListItem.setTitle( object.get("title").getAsString() );
            }

            listItems.add( genericListItem );
        }
    }

    @Override
    public List<GenericListItem> getItems() {
        return new ArrayList<>( listItems );
    }
}
