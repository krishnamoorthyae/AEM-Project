package com.tgfoundation.core.models.stylesystem;

import com.day.cq.search.QueryBuilder;
import com.tgfoundation.core.models.StyleBuildingBlock;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.RequestAttribute;
import org.apache.sling.models.annotations.injectorspecific.SlingObject;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import javax.jcr.RepositoryException;
import java.util.Map;

@Model(
        adaptables = {SlingHttpServletRequest.class, Resource.class},
        adapters = {StyleBuildingBlock.class},
        defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL
)
public class StyleBuildingBlockImpl implements StyleBuildingBlock {
    @SlingObject
    private Resource resource;

    @Inject
    private ResourceResolver resourceResolver;

    @Inject
    private QueryBuilder queryBuilder;

    @RequestAttribute
    String path;

    @RequestAttribute
    String resourceType;

    @PostConstruct
    public void init() throws RepositoryException {
        if( resource == null ) return;

        ValueMap valueMap = resource.getValueMap();

        if( path != null ) {
            Resource pageResource = resourceResolver.getResource( path + "/jcr:content" );
            if( pageResource != null ) {
                valueMap = pageResource.getValueMap();
            }
        }
    }

    @Override
    public Map<String, Map<String, String>> getStyleGroups() {
        return null;
    }
}
