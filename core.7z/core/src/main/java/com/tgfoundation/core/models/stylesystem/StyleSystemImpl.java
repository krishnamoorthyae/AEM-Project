package com.tgfoundation.core.models.stylesystem;

import com.day.cq.search.QueryBuilder;
import com.day.cq.search.result.Hit;
import com.tgfoundation.core.models.StyleBuildingBlockGroup;
import com.tgfoundation.core.models.StyleShortcutGroup;
import com.tgfoundation.core.models.StyleSystem;
import com.tgfoundation.core.utils.ContentFragmentLookup;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.RequestAttribute;
import org.apache.sling.models.annotations.injectorspecific.SlingObject;
import javax.annotation.PostConstruct;
import javax.inject.Inject;
import javax.jcr.Node;
import javax.jcr.Property;
import javax.jcr.RepositoryException;
import java.util.*;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Model(
        adaptables = {SlingHttpServletRequest.class, Resource.class},
        adapters = {StyleSystem.class},
        defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL
)
public class StyleSystemImpl implements StyleSystem {
    @SlingObject
    private Resource resource;

    @Inject
    private ResourceResolver resourceResolver;

    @Inject
    private QueryBuilder queryBuilder;

    @RequestAttribute
    String path;

    private ContentFragmentLookup  contentFragmentLookup;

    private String id;

    private final ArrayList<StyleBuildingBlockGroup> buildingBlockGroups = new ArrayList<>();

    private String appliedStyles = "";

    private final ArrayList<StyleShortcutGroup> shortcuts = new ArrayList<>();

    private final ArrayList<String> appliedShortcuts = new ArrayList<>();

    @PostConstruct
    public void init() throws RepositoryException {
        if( resource == null ) return;

        ValueMap valueMap = resource.getValueMap();

        contentFragmentLookup = new ContentFragmentLookup( queryBuilder );

        Node node = resource.adaptTo( Node.class );
        if( node != null ) {
            retrieveComponentId( node );

            if( node.hasProperty( "buildingBlocks" ) ) {
                Property property = node.getProperty( "buildingBlocks" );

                if( property != null ) {
                    appliedStyles = property.getString();
                }
            }
        }

        if( path != null ) {
            Resource pageResource = resourceResolver.getResource( path + "/jcr:content" );
            if( pageResource != null ) {
                valueMap = pageResource.getValueMap();
            }
        }

        String resourceType = valueMap.get("sling:resourceType", String.class);

        if( resourceType == null ) return;

        if( !resourceType.startsWith( "tgfoundation/components") ) return;

        resourceType = resourceType.split( "tgfoundation/components" )[1];

        String tag = "/content/cq:tags/style-system" + resourceType;

        getStyleShortcuts( tag );

        getAppliedShortcuts();

        getStyleBuildingBlocks( tag );
    }

    private void getStyleBuildingBlocks( String tag ) throws RepositoryException {
        List<Hit> hitList = contentFragmentLookup.lookupFragmentByTag(resourceResolver, "/content/dam/config/style-system/building-block", tag );

        for( Hit hit : hitList ) {
            Resource hitResource = hit.getResource();

            StyleBuildingBlockGroup styleGroup = hitResource.adaptTo( StyleBuildingBlockGroup.class );
            buildingBlockGroups.add( styleGroup );
        }
    }

    private void getAppliedShortcuts() throws RepositoryException {
        Node component = resource.adaptTo( Node.class );

        if( component == null ) return;

        if( component.hasProperty("cq:cssClass") ) {
            String classString = component.getProperty("cq:cssClass").getString();

            if( classString == null || classString.isEmpty() ) return;

            String[] classList = classString.split(" ");
            for( String str : classList ) {
                if( !str.contains("building-blocks") ) {
                    appliedShortcuts.add( str );
                }
            }
        }
    }

    private void retrieveComponentId( Node node ) throws RepositoryException {
        if( node.hasProperty("cq:cssClass") ) {
            String styleString = node.getProperty("cq:cssClass").getString();
            String[] styleClasses = styleString.split(" ");
            boolean found = false;

            for( String str : styleClasses ) {
                if( str.contains("building-block") ) {
                    found = true;
                    id = str;
                }
            }

            if( !found ) {
                Random rand = new Random();
                int n = rand.nextInt(999999999);

                id = "aem-building-blocks_" + n + "_styles";

                node.setProperty("cq:cssClass", id );
            }
        }
        else {
            Random rand = new Random();
            int n = rand.nextInt(999999999);

            id = "aem-building-blocks_" + n + "_styles";

            node.setProperty("cq:cssClass", id );
        }
    }

    private void getStyleShortcuts( String tag ) throws RepositoryException {
        List<Hit> hitList = contentFragmentLookup.lookupFragmentByTag(resourceResolver, "/content/dam/config/style-system/shortcut", tag );

        Set<String> groups = new HashSet<>();

        for( Hit hit : hitList ) {
            Resource hitResource = hit.getResource();

            Resource parent = hitResource.getParent();

            if( parent == null ) continue;

            if( !groups.contains( parent.getPath() ) ) {
                StyleShortcutGroup shortcutGroup = parent.adaptTo( StyleShortcutGroup.class );
                shortcuts.add( shortcutGroup );

                groups.add( parent.getPath() );
            }
        }
    }

    @Override
    public String getComponentId() {
        return id;
    }

    @Override
    public List<StyleBuildingBlockGroup> getStyleGroups() {
        return new ArrayList<>(buildingBlockGroups);
    }

    @Override
    public List<StyleShortcutGroup> getShortcutGroups() {
        return new ArrayList<>( shortcuts );
    }

    @Override
    public String getSelectedStyleBuildingBlocks() {
        return appliedStyles;
    }

    @Override
    public List<String> getSelectedShortcuts() {
        return new ArrayList<>( appliedShortcuts );
    }
}
