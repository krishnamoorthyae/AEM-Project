package com.tgfoundation.core.scripts;

import com.adobe.cq.dam.cfm.*;
import com.day.cq.commons.jcr.JcrConstants;
import com.day.cq.dam.api.DamConstants;
import com.day.cq.search.PredicateGroup;
import com.day.cq.search.Query;
import com.day.cq.search.QueryBuilder;
import com.day.cq.search.result.Hit;
import com.day.cq.search.result.SearchResult;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.PersistenceException;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.apache.sling.servlets.annotations.SlingServletPaths;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.Marker;

import javax.jcr.Node;
import javax.jcr.NodeIterator;
import javax.jcr.RepositoryException;
import javax.jcr.Session;
import javax.servlet.Servlet;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Component(service = { Servlet.class })
@SlingServletPaths("/bin/foundation/migrate/mvs/fragments")
public class MVSMigration extends SlingAllMethodsServlet {
    private static Logger log = LoggerFactory.getLogger(MVSMigration.class);
    private static Marker marker;

    @Reference
    ContentFragmentManager contentFragmentManager;

    @Reference
    private QueryBuilder queryBuilder;

    @Override
    protected void doGet( SlingHttpServletRequest request, SlingHttpServletResponse response ) throws IOException {
        ResourceResolver resolver = request.getResourceResolver();

        List<Hit> hits = getContentFragmentList( request.getResource().getResourceResolver() );
        for( Hit hit : hits ) {
            try {
                Resource resource = hit.getResource();

                if( resource == null ) continue;

                Resource data = resource.getChild("jcr:content/data");

                if( data == null ) continue;

                Node node = data.adaptTo(Node.class);

                if( node == null ) continue;

                node.setProperty("cq:model", "/conf/tgfoundation/settings/dam/cfm/models/multi-variate-content");
            }
            catch (RepositoryException e) {
                throw new RuntimeException(e);
            }
        }
        resolver.commit();
    }

    public List<Hit> getContentFragmentList( ResourceResolver resolver ) {
        String mvsPath = "/content/dam/tg-documents/aig-travel/contents";

        Map<String, String> predicateMap = new HashMap<>();
        predicateMap.put("path", mvsPath);
        predicateMap.put("type", DamConstants.NT_DAM_ASSET);
        predicateMap.put("property", "jcr:content/data/cq:model");
        predicateMap.put("property.value", "/conf/tg-documents/settings/dam/cfm/models/aig-travel-content" );
        predicateMap.put("property.operation", "exact" );
        predicateMap.put("p.limit", String.valueOf( 10 ) );
        predicateMap.put("p.offset", "0" );

        Session session = resolver.adaptTo(Session.class);
        Query defaultQuery = queryBuilder.createQuery( PredicateGroup.create(predicateMap), session );
        SearchResult searchResult = defaultQuery.getResult();

        List<Hit> hits = new ArrayList<>( searchResult.getHits() );

        for(int i = 10; i < searchResult.getTotalMatches(); i = i + 10 ) {
            predicateMap.put("p.offset", String.valueOf( i ) );
            Query query = queryBuilder.createQuery( PredicateGroup.create(predicateMap), session );
            SearchResult result = query.getResult();

            hits.addAll( result.getHits() );
        }

        return hits;
    }
}
