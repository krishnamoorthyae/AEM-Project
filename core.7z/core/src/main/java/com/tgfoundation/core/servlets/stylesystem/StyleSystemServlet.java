package com.tgfoundation.core.servlets.stylesystem;

import com.google.gson.*;
import com.tgfoundation.core.models.*;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.apache.sling.servlets.annotations.SlingServletPaths;
import org.osgi.service.component.annotations.Component;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.Marker;

import javax.jcr.*;
import javax.jcr.lock.LockException;
import javax.jcr.nodetype.ConstraintViolationException;
import javax.jcr.version.VersionException;
import javax.servlet.Servlet;
import java.io.IOException;
import java.util.List;
import java.util.Map;

@Component(service = { Servlet.class })
@SlingServletPaths("/bin/style-system/style")
public class StyleSystemServlet extends SlingAllMethodsServlet {
    private static Logger log = LoggerFactory.getLogger(StyleSystemServlet.class);
    private static Marker marker;

    @Override
    protected void doGet( SlingHttpServletRequest request, SlingHttpServletResponse response ) throws IOException {
        String path = request.getParameter( "path" );

        if( path == null ) {
            response.setStatus(SlingHttpServletResponse.SC_BAD_REQUEST);
            response.getWriter().write("Component Path cannot be null.");
            log.debug("Found no component path");
            return;
        }

        Resource resource = request.getResourceResolver().getResource( path );

        StyleSystem styleSystem = resource.adaptTo( StyleSystem.class );

        if( styleSystem == null ) {
            response.setStatus(SlingHttpServletResponse.SC_BAD_REQUEST);
            response.getWriter().write("there was a problem finding the style system");
            log.debug("There was a problem finding the style system");
            return;
        }

        JsonObject jsonObject = new JsonObject();
        jsonObject.addProperty("id", styleSystem.getComponentId());
        jsonObject.addProperty("appliedStyles", styleSystem.getSelectedStyleBuildingBlocks());

        List<StyleShortcutGroup> shortcutGroupList = styleSystem.getShortcutGroups();
        JsonArray shortcutArray = getShortcutGroups(shortcutGroupList);
        jsonObject.add("shortcuts", shortcutArray);

        List<String> shortcutList = styleSystem.getSelectedShortcuts();
        JsonArray selectedShortcuts = getAppliedShortcuts( shortcutList );
        jsonObject.add("selectedShortcuts", selectedShortcuts);

        List<StyleBuildingBlockGroup> groupList = styleSystem.getStyleGroups();
        JsonArray groupArray = getStyleGroups( groupList );
        jsonObject.add("groups", groupArray );

        response.getWriter().write(jsonObject.toString());
    }

    private JsonArray getStyleGroups( List<StyleBuildingBlockGroup> groups ) {
        JsonArray array = new JsonArray();

        if( groups == null ) return array;

        Gson gson = new Gson();

        for( StyleBuildingBlockGroup styleBuildingBlockGroup : groups ) {
            JsonObject object = new JsonObject();

            Map<String, String> mediaQueries = styleBuildingBlockGroup.getMediaQueries();
            String mediaJson = gson.toJson( mediaQueries );
            JsonObject mediaObj = JsonParser.parseString( mediaJson ).getAsJsonObject();
            object.add( "media", mediaObj );

            Map<String, String> targets = styleBuildingBlockGroup.getTargets();
            String targetJson = gson.toJson( targets );
            JsonObject targetObj = JsonParser.parseString( targetJson ).getAsJsonObject();
            object.add( "target", targetObj );

            Map<String, GenericListModel> styleMap = styleBuildingBlockGroup.getStyleOptions();

            JsonObject valueObj = new JsonObject();

            for( String key : styleMap.keySet() ) {
                GenericListModel list = styleMap.get( key );

                if( list == null ) continue;

                JsonArray styleOptions = new JsonArray();
                List<GenericListItem> options = list.getItems();

                for( GenericListItem item : options ) {
                    if( item.getValue() != null && item.getTitle() != null ) {
                        JsonObject option = new JsonObject();

                        option.addProperty("title", item.getTitle() );
                        option.addProperty("value", item.getValue() );

                        styleOptions.add( option );
                    }
                }

                valueObj.add( key, styleOptions);
            }

            object.add( "options", valueObj );
            array.add( object );
        }

        return array;
    }

    private JsonArray getAppliedShortcuts( List<String> shortcutList ) {
        JsonArray array = new JsonArray();

        if( shortcutList != null ) {
            for( String str : shortcutList ) {
                array.add( str );
            }
        }

        return array;
    }

    private JsonArray getShortcutGroups(List<StyleShortcutGroup> shortcutGroupList) {
        JsonArray jsonArray = new JsonArray();
        for (StyleShortcutGroup shortcutGroup : shortcutGroupList) {
            JsonObject group = new JsonObject();
            group.addProperty("name", shortcutGroup.getName());
            group.addProperty("path", shortcutGroup.getPath());

            List<StyleShortcut> shortcutList = shortcutGroup.getStyles();

            if (shortcutList == null) continue;

            JsonArray shortcutArray = new JsonArray();
            for (StyleShortcut shortcut : shortcutList) {
                JsonObject shortcutObject = new JsonObject();

                shortcutObject.addProperty("name", shortcut.getName());
                shortcutObject.addProperty("path", shortcut.getPath());

                GenericListItem item = shortcut.getShortcut();
                shortcutObject.addProperty("title", item.getTitle());
                shortcutObject.addProperty("value", item.getValue());

                shortcutArray.add(shortcutObject);
            }

            group.add("shortcuts", shortcutArray);

            jsonArray.add( group );
        }

        return jsonArray;
    }

    @Override
    protected void doPost(SlingHttpServletRequest request, SlingHttpServletResponse response) throws IOException {
        try {
            ResourceResolver resolver = request.getResourceResolver();
            String path = request.getParameter("path");
            String id = request.getParameter("id");

            if (path == null || path.isEmpty()) {
                response.setStatus(SlingHttpServletResponse.SC_NOT_FOUND);
                response.getWriter().write("No Resource Path Provided");
                return;
            }

            if (id == null || id.isEmpty()) {
                response.setStatus(SlingHttpServletResponse.SC_NOT_FOUND);
                response.getWriter().write("No component id Provided");
                return;
            }

            Resource resource = resolver.getResource(path);

            if (resource == null) {
                response.setStatus(SlingHttpServletResponse.SC_NOT_FOUND);
                response.getWriter().write("No Resource found at the provided path");
                return;
            }

            Node component = resource.adaptTo(Node.class);

            if (component == null) {
                response.setStatus(SlingHttpServletResponse.SC_NOT_FOUND);
                response.getWriter().write("Resource not found at the provided path.");
                log.debug("Found no resource in path {}", path);
                return;
            }

            String buildingBlocks = request.getParameter("buildingBlocks");
            if( buildingBlocks != null && buildingBlocks.isEmpty() ) {
                component.setProperty("buildingBlocks", buildingBlocks);
            }
            else {
                Property buildingBlockProperty = component.getProperty("buildingBlocks");
                if( buildingBlockProperty != null ) {
                    buildingBlockProperty.remove();
                }
            }

            String shortcutString = request.getParameter("shortcuts");

            //removing shortcuts from the page
            if (shortcutString == null || shortcutString.isEmpty()) {
                if (component.hasProperty("shortcutStyles")) {
                    component.getProperty("shortcutStyles").remove();
                }
            }

            JsonArray jsonArray = JsonParser.parseString( shortcutString ).getAsJsonArray();
            StringBuilder classBuilder = new StringBuilder();
            StringBuilder shortcutStyle = new StringBuilder();

            classBuilder.append( id ).append( " " );

            for( JsonElement element : jsonArray ) {
                JsonObject object = element.getAsJsonObject();

                if( object.has("id") && object.has( "value" ) ) {
                    classBuilder.append( object.get("id").getAsString() ).append(" ");
                    shortcutStyle.append( object.get("value").getAsString() ).append("\n\r");
                }
            }

            component.setProperty("cq:cssClass", classBuilder.toString().trim() );

            String styleShortcuts = shortcutStyle.toString().trim();
            if( !styleShortcuts.isEmpty() ) {
                component.setProperty("shortcutStyles", styleShortcuts );
            }

            resolver.commit();
            response.setStatus( 200 );
        }
        catch (RepositoryException e) {
            throw new RuntimeException(e);
        }
    }
}
