package com.tgfoundation.core.utils;

import com.day.cq.search.QueryBuilder;
import com.day.cq.dam.api.DamConstants;
import com.day.cq.search.PredicateGroup;
import com.day.cq.search.Query;
import com.day.cq.search.result.Hit;
import com.day.cq.search.result.SearchResult;
import org.apache.sling.api.resource.ResourceResolver;
import javax.jcr.Session;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ContentFragmentLookup {
    private final QueryBuilder queryBuilder;

    public ContentFragmentLookup( QueryBuilder queryBuilder ) {
        this.queryBuilder = queryBuilder;
    }

    public List<Hit> lookupFragmentByTag(ResourceResolver resolver, String path, String tag ) {
        if( tag.startsWith("/content/cq:tags/" ) ) {
            tag = tag.replace( "/content/cq:tags/", "" );
            tag = tag.replaceFirst("/", ":");
        }

        Map<String, String> predicateMap = new HashMap<>();
        predicateMap.put("path", path);
        predicateMap.put("type", DamConstants.NT_DAM_ASSET);
        predicateMap.put("property", "jcr:content/metadata/cq:tags");
        predicateMap.put("property.value", tag );
        predicateMap.put("property.operation", "exact" );
        predicateMap.put("p.limit", String.valueOf( 10 ) );
        predicateMap.put("p.offset", "0" );

        Session session = resolver.adaptTo(Session.class);
        Query defaultQuery = queryBuilder.createQuery( PredicateGroup.create(predicateMap), session );
        SearchResult searchResult = defaultQuery.getResult();

        List<Hit> hits = new ArrayList<>( searchResult.getHits() );

        for(int i = 10; i < searchResult.getTotalMatches(); i = i + 10 ) {
            predicateMap.put("p.offset", String.valueOf( i ) );
            Query query = queryBuilder.createQuery( PredicateGroup.create(predicateMap), session );
            SearchResult result = query.getResult();

            hits.addAll( result.getHits() );
        }

        return hits;
    }
}
