package com.tgfoundation.core.utils;

import org.apache.sling.api.resource.ValueMap;

import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

public class DataDictionarySwap {
    private final Map<String, String> dictionary;

    private final ValueMap valueMap;

    public DataDictionarySwap(Map<String, String> dictionary, ValueMap valueMap) {
        this.dictionary = dictionary;
        this.valueMap = valueMap;
    }

    public void updateValueMapSimple( Map<String, Object> map, String property ) {
        if( property == null || map == null ) return;

        if( map.containsKey( property ) ) {
            String originalText = valueMap.get(property, String.class);
            if (dictionary.containsKey(originalText)) {
                map.put(property, dictionary.get(originalText));
            }
            else {
                for( String key : dictionary.keySet() ) {
                    if( originalText != null && originalText.contains( key ) ) {
                        originalText = originalText.replace( key, dictionary.get( key ) );
                        map.put( property, originalText );
                    }
                }
            }
        }
    }

    public void updateValueMapStringSimple( Map<String, String> map, String property ) {
        if( property == null || map == null ) return;

        if( map.containsKey( property ) ) {
            String originalText = valueMap.get(property, String.class);
            if (dictionary.containsKey(originalText)) {
                map.put(property, dictionary.get(originalText));
            }
        }
    }

    public void updateValueMapById( Map<String, Object> map, String property ) {
        if( property == null || map == null ) return;

        String id = valueMap.get("id", String.class);
        if( id != null ) {
            String idProperty = id.concat(" : ").concat( property );

            if( map.containsKey( property ) ) {
                if (dictionary.containsKey( idProperty )) {
                    map.put(property, dictionary.get( idProperty ) );
                }
            }
        }
    }

    public void updateValueMapStringById( Map<String, String> map, String property ) {
        if( property == null || map == null ) return;

        String id = valueMap.get("id", String.class);
        if( id != null ) {
            String idProperty = id.concat(":").concat( property );

            if( map.containsKey( property ) ) {
                if (dictionary.containsKey( idProperty )) {
                    map.put(property, dictionary.get( idProperty ) );
                }
            }
        }
    }

    public void searchAndReplaceRichText( Map<String, Object> map, String property ) {
        if( property == null || map == null ) return;

        String id = valueMap.get("id", String.class);

        if( id == null ) return;

        String updatedText = valueMap.get(property, String.class);

        if( updatedText == null ) return;

        Set<String> keys = dictionary.keySet()
                .stream()
                .filter(n -> n.startsWith( id.concat(":") ) )
                .collect(Collectors.toSet());

        for( String key : keys ) {
            String searchKey = key.split( id + ":" )[1];

            updatedText = updatedText.replace( searchKey, dictionary.get( key ) );
        }

        map.put(property, updatedText);
    }
}
