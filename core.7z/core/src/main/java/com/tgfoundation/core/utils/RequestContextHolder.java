package com.tgfoundation.core.utils;

import org.apache.sling.api.SlingHttpServletRequest;

public class RequestContextHolder {
    private static final ThreadLocal<SlingHttpServletRequest> requestHolder = new ThreadLocal<>();

    public static void setRequest(SlingHttpServletRequest request) {
        requestHolder.set(request);
    }

    public static SlingHttpServletRequest getRequest() {
        return requestHolder.get();
    }

    public static void clear() {
        requestHolder.remove();
    }
}
