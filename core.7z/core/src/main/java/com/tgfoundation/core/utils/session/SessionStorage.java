package com.tgfoundation.core.utils.session;

import com.google.gson.Gson;
import org.apache.sling.api.SlingHttpServletRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.Marker;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.HashMap;

public class SessionStorage {
    private static Logger log = LoggerFactory.getLogger(SessionStorage.class);
    private static Marker marker;

    //set item with a cookie userid or global session by default
    public void setItem(SlingHttpServletRequest request, String key, Object value) {
        Cookie uuid = request.getCookie("uuid");
        String userId = "sessionStorage";

        if( uuid == null && request.getAttribute("uuid") != null) {
            uuid = new Cookie("uuid", request.getAttribute("uuid").toString() );
            uuid.setSecure(true);
        }
        if( uuid != null ) {
            userId = uuid.getValue();
        }

        if (key == null) {
            return;
        }

        Gson gson = new Gson();
        HashMap<String, Object> sessionStorage;
        HttpSession httpSession = request.getSession();

        if( httpSession.getAttribute(userId) == null ) {
            sessionStorage = new HashMap<>();
        }
        else {
            String sessionJson = httpSession.getAttribute(userId).toString();
            sessionStorage = gson.fromJson(sessionJson, HashMap.class);
        }

        sessionStorage.put(key, value);

        String sessionJson = gson.toJson( sessionStorage );
        httpSession.setAttribute(userId, sessionJson);
    }

    //set item with a provided userid
    public void setItem(SlingHttpServletRequest request, String key, Object value, String userId) {
        if (key == null) {
            return;
        }

        Gson gson = new Gson();
        HashMap<String, Object> sessionStorage;
        HttpSession httpSession = request.getSession();

        if( httpSession.getAttribute(userId) == null ) {
            sessionStorage = new HashMap<>();
        }
        else {
            String sessionJson = httpSession.getAttribute(userId).toString();
            sessionStorage = gson.fromJson(sessionJson, HashMap.class);
        }

        sessionStorage.put(key, value);

        String sessionJson = gson.toJson( sessionStorage );
        httpSession.setAttribute(userId, sessionJson);
    }

    public Object getItem(SlingHttpServletRequest request, String key) {
        Cookie uuid = request.getCookie("uuid");
        String userId = "sessionStorage";

        if( uuid == null && request.getAttribute("uuid") != null) {
            uuid = new Cookie("uuid", request.getAttribute("uuid").toString() );
            uuid.setSecure(true);
        }
        if( uuid != null ) {
            userId = uuid.getValue();
        }

        if( key == null ) {
            return null;
        }

        Gson gson = new Gson();
        HashMap<String, Object> sessionStorage = null;
        Object value = null;

        if( request.getAttribute("uuid") != null) {
            String sessionJson = request.getAttribute(userId).toString();
            sessionStorage = gson.fromJson(sessionJson, HashMap.class);
        }
        else {
            HttpSession httpSession = request.getSession();
            if (httpSession.getAttribute(userId) != null) {
                String sessionJson = httpSession.getAttribute(userId).toString();
                sessionStorage = gson.fromJson(sessionJson, HashMap.class);
            }
        }

        if( sessionStorage != null ) {
            value = sessionStorage.get(key);
        }

        return value;
    }

    //this is duplicate but is used for workflows
    public Object getItem(HttpServletRequest request, String key) {
        Cookie uuid = null;
        String userId = "sessionStorage";

        if( uuid == null && request.getAttribute("uuid") != null) {
            uuid = new Cookie("uuid", request.getAttribute("uuid").toString() );
            uuid.setSecure(true);
        }
        if( uuid != null ) {
            userId = uuid.getValue();
        }

        if( key == null ) {
            return null;
        }

        Gson gson = new Gson();
        HashMap<String, Object> sessionStorage = null;
        Object value = null;

        if( request.getAttribute("uuid") != null) {
            String sessionJson = request.getAttribute(userId).toString();
            sessionStorage = gson.fromJson(sessionJson, HashMap.class);
        }
        else {
            HttpSession httpSession = request.getSession();
            if (httpSession.getAttribute(userId) != null) {
                String sessionJson = httpSession.getAttribute(userId).toString();
                sessionStorage = gson.fromJson(sessionJson, HashMap.class);
            }
        }

        if( sessionStorage != null ) {
            value = sessionStorage.get(key);
        }

        return value;
    }

    public Object getItem(HttpServletRequest request, String key, String userId) {
        if( key == null ) {
            return null;
        }

        Gson gson = new Gson();
        HashMap<String, Object> sessionStorage = null;
        Object value = null;

        if( request.getAttribute("uuid") != null) {
            String sessionJson = request.getAttribute(userId).toString();
            sessionStorage = gson.fromJson(sessionJson, HashMap.class);
        }
        else {
            HttpSession httpSession = request.getSession();
            if (httpSession.getAttribute(userId) != null) {
                String sessionJson = httpSession.getAttribute(userId).toString();
                sessionStorage = gson.fromJson(sessionJson, HashMap.class);
            }
        }

        if( sessionStorage != null ) {
            value = sessionStorage.get(key);
        }

        return value;
    }

    public void removeItem(SlingHttpServletRequest request, String key) {
        Cookie uuid = request.getCookie("uuid");
        String userId = "sessionStorage";

        if( uuid != null ) {
            userId = uuid.getValue();
        }

        if (key == null) {
            return;
        }

        Gson gson = new Gson();
        HashMap<String, Object> sessionStorage;
        HttpSession httpSession = request.getSession();

        if( httpSession.getAttribute(userId) == null ) {
            return;
        }
        else {
            String sessionJson = httpSession.getAttribute(userId).toString();
            sessionStorage = gson.fromJson(sessionJson, HashMap.class);
        }

        sessionStorage.remove(key);

        String sessionJson = gson.toJson( sessionStorage );
        httpSession.setAttribute(userId, sessionJson);
    }

    public void removeItem(SlingHttpServletRequest request, String key, String userId) {
        if (key == null) {
            return;
        }

        Gson gson = new Gson();
        HashMap<String, Object> sessionStorage;
        HttpSession httpSession = request.getSession();

        if( httpSession.getAttribute(userId) == null ) {
            return;
        }
        else {
            String sessionJson = httpSession.getAttribute(userId).toString();
            sessionStorage = gson.fromJson(sessionJson, HashMap.class);
        }

        sessionStorage.remove(key);

        String sessionJson = gson.toJson( sessionStorage );
        httpSession.setAttribute(userId, sessionJson);
    }

    public String getSessionObject(SlingHttpServletRequest request) {
        Cookie uuid = request.getCookie("uuid");
        String userId = "sessionStorage";
        String sessionJson = "";

        if( uuid != null ) {
            userId = uuid.getValue();
        }

        HttpSession httpSession = request.getSession();
        if( userId != null &&  httpSession.getAttribute(userId) != null ) {
            sessionJson = httpSession.getAttribute(userId).toString();
        }

        return sessionJson;
    }

    public String getSessionObject(SlingHttpServletRequest request, String userId) {
        String sessionJson = "";

        HttpSession httpSession = request.getSession();
        if( userId != null &&  httpSession.getAttribute(userId) != null ) {
            sessionJson = httpSession.getAttribute(userId).toString();
        }

        return sessionJson;
    }

    public void clear(SlingHttpServletRequest request) {
        Cookie uuid = request.getCookie("uuid");
        String userId;

        if( uuid == null && request.getAttribute("uuid") != null) {
            uuid = new Cookie("uuid", request.getAttribute("uuid").toString() );
            uuid.setSecure(true);
        }
        if( uuid != null ) {
            userId = uuid.getValue();
        }
        else {
            return;
        }

        HttpSession httpSession = request.getSession();
        if( httpSession.getAttribute(userId) != null ) {
            httpSession.removeAttribute(userId);
        }
    }

    public void clear(SlingHttpServletRequest request, String userId) {
        HttpSession httpSession = request.getSession();
        if( httpSession.getAttribute(userId) != null ) {
            httpSession.removeAttribute(userId);
        }
    }
}
