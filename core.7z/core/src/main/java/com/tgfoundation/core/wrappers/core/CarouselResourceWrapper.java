package com.tgfoundation.core.wrappers.core;

import com.tgfoundation.core.utils.DataDictionarySwap;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceWrapper;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.api.wrappers.ValueMapDecorator;
import org.jetbrains.annotations.NotNull;

import java.util.HashMap;
import java.util.Map;

public class CarouselResourceWrapper extends ResourceWrapper {

    private final Map<String, String> dictionary;

    public CarouselResourceWrapper(@NotNull Resource resource, @NotNull Map<String, String> dictionary) {
        super(resource);
        this.dictionary = dictionary;
    }

    @Override
    public @NotNull ValueMap getValueMap() {
        ValueMap originalValueMap = super.getValueMap();

        HashMap<String, Object> overriddenMap = new HashMap<>( originalValueMap );

        DataDictionarySwap dataDictionarySwap = new DataDictionarySwap( dictionary, originalValueMap );

        dataDictionarySwap.updateValueMapSimple( overriddenMap, "id" );
        dataDictionarySwap.updateValueMapSimple( overriddenMap, "dealy" );
        dataDictionarySwap.updateValueMapSimple( overriddenMap, "autoplay" );
        dataDictionarySwap.updateValueMapSimple( overriddenMap, "autopauseDisabled" );
        dataDictionarySwap.updateValueMapSimple( overriddenMap, "activeItem" );
        dataDictionarySwap.updateValueMapSimple( overriddenMap, "accessibilityPrevious" );
        dataDictionarySwap.updateValueMapSimple( overriddenMap, "accessibilityPlay" );
        dataDictionarySwap.updateValueMapSimple( overriddenMap, "accessibilityPause" );
        dataDictionarySwap.updateValueMapSimple( overriddenMap, "accessibilityLabel" );
        dataDictionarySwap.updateValueMapSimple( overriddenMap, "accessibilityAutoItemTitles" );

        dataDictionarySwap.updateValueMapById( overriddenMap, "id" );
        dataDictionarySwap.updateValueMapById( overriddenMap, "dealy" );
        dataDictionarySwap.updateValueMapById( overriddenMap, "autoplay" );
        dataDictionarySwap.updateValueMapById( overriddenMap, "autopauseDisabled" );
        dataDictionarySwap.updateValueMapById( overriddenMap, "activeItem" );
        dataDictionarySwap.updateValueMapById( overriddenMap, "accessibilityPrevious" );
        dataDictionarySwap.updateValueMapById( overriddenMap, "accessibilityPlay" );
        dataDictionarySwap.updateValueMapById( overriddenMap, "accessibilityPause" );
        dataDictionarySwap.updateValueMapById( overriddenMap, "accessibilityLabel" );
        dataDictionarySwap.updateValueMapById( overriddenMap, "accessibilityAutoItemTitles" );

        return new ValueMapDecorator( overriddenMap );
    }
}
