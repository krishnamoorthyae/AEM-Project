package com.tgfoundation.core.wrappers.core;

import com.day.cq.commons.jcr.JcrConstants;
import com.tgfoundation.core.utils.DataDictionarySwap;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceWrapper;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.api.wrappers.ValueMapDecorator;
import org.jetbrains.annotations.NotNull;

import java.util.HashMap;
import java.util.Map;

public class ImageResourceWrapper extends ResourceWrapper {

    private final Map<String, String> dictionary;

    public ImageResourceWrapper(@NotNull Resource resource, @NotNull Map<String, String> dictionary) {
        super(resource);
        this.dictionary = dictionary;
    }

    @Override
    public @NotNull ValueMap getValueMap() {
        ValueMap originalValueMap = super.getValueMap();

        HashMap<String, Object> overriddenMap = new HashMap<>( originalValueMap );

        DataDictionarySwap dataDictionarySwap = new DataDictionarySwap( dictionary, originalValueMap );

        dataDictionarySwap.updateValueMapSimple( overriddenMap, "id" );
        dataDictionarySwap.updateValueMapSimple( overriddenMap, "fileReference" );
        dataDictionarySwap.updateValueMapSimple( overriddenMap, "alt" );
        dataDictionarySwap.updateValueMapSimple( overriddenMap, "linkTarget" );
        dataDictionarySwap.updateValueMapSimple( overriddenMap, "linkURL" );
        dataDictionarySwap.updateValueMapSimple( overriddenMap, JcrConstants.JCR_TITLE);

        dataDictionarySwap.updateValueMapById( overriddenMap, "id" );
        dataDictionarySwap.updateValueMapById( overriddenMap, "fileReference" );
        dataDictionarySwap.updateValueMapById( overriddenMap, "alt" );
        dataDictionarySwap.updateValueMapById( overriddenMap, "linkTarget" );
        dataDictionarySwap.updateValueMapById( overriddenMap, "linkURL" );
        dataDictionarySwap.updateValueMapById( overriddenMap, JcrConstants.JCR_TITLE );

        return new ValueMapDecorator( overriddenMap );
    }
}
