package com.tgfoundation.core.wrappers.core;

import com.day.cq.wcm.api.Page;
import com.tgfoundation.core.utils.DataDictionarySwap;
import com.tgfoundation.core.utils.RequestContextHolder;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceWrapper;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.api.wrappers.ValueMapDecorator;
import org.jetbrains.annotations.NotNull;

import java.util.HashMap;
import java.util.Map;

public class TextResourceWrapper extends ResourceWrapper {

    private final Map<String, String> dictionary;

    public TextResourceWrapper(@NotNull Resource resource, @NotNull Map<String, String> dictionary) {
        super(resource);
        this.dictionary = dictionary;
    }

    @Override
    public @NotNull ValueMap getValueMap() {
        ValueMap originalValueMap = super.getValueMap();

        HashMap<String, Object> overriddenMap = new HashMap<>( originalValueMap );

        DataDictionarySwap dataDictionarySwap = new DataDictionarySwap( dictionary, originalValueMap );

        dataDictionarySwap.updateValueMapSimple( overriddenMap, "id" );
        dataDictionarySwap.updateValueMapSimple( overriddenMap, "text" );

        dataDictionarySwap.updateValueMapById( overriddenMap, "id" );
        dataDictionarySwap.updateValueMapById( overriddenMap, "text" );

        dataDictionarySwap.searchAndReplaceRichText( overriddenMap, "text" );

        return new ValueMapDecorator( overriddenMap );
    }
}
