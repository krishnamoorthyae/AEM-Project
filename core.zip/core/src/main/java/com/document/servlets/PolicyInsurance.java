package com.document.servlets;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.URL;
import java.util.Base64;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.servlet.Servlet;
import com.google.gson.Gson;
import com.tgfoundation.core.utils.session.SessionStorage;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.api.servlets.HttpConstants;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.apache.sling.servlets.annotations.SlingServletPaths;
import org.osgi.framework.Constants;
import org.osgi.service.cm.ConfigurationAdmin;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.Marker;
import org.osgi.service.cm.Configuration;

@Component(service = Servlet.class, property = { Constants.SERVICE_DESCRIPTION + "=policy insurance document",
		"sling.servlet.methods=" + HttpConstants.METHOD_GET })
@SlingServletPaths("/bin/document/policyinsurancedoc")
public class PolicyInsurance extends SlingAllMethodsServlet {
	private static final long serialVersionUID = 1L;

	private static Logger log = LoggerFactory.getLogger(PolicyInsurance.class);

	private static Marker marker;

	@Reference
	transient ConfigurationAdmin configAdmin;

	@Reference
	transient ResourceResolverFactory resourceResolverFactory;

	@Override
	protected void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response) throws IOException {
		log.debug("Triggered policy Insurance servlet");

        InputStream inputStream = null;

		try {
			SessionStorage sessionStorage = new SessionStorage();
			Object policyObject = sessionStorage.getItem(request, "policyDetail");

            final OutputStream out = response.getOutputStream();

			if( policyObject == null ) {
                out.write( "we could not find your policy information".getBytes() );
				response.sendError(500);
				return;
			}
			Gson gson = new Gson();
			HashMap<String, Object> policy = gson.fromJson( policyObject.toString(), HashMap.class);
			if( policy == null ) {
                out.write( "Something went wrong when retrieving your policy information".getBytes() );
				response.sendError(500);
				return;
			}
			Map<String, Object> detailResponse = (Map<String, Object>) policy.get("detailResponse");
			if( detailResponse == null ) {
                out.write( "Something went wrong! Please try again later".getBytes() );
				response.sendError(500);
				return;
			}
			Map<String, Object> policyDetail  = (Map<String, Object>) detailResponse.get("policyDetail");
			if( policyDetail == null ) {
                out.write( "We ran into issues retrieving your Policy Details! Please try again later".getBytes() );
				response.sendError(500);
				return;
			}
			Map<String, Object> productDetails  = (Map<String, Object>) policyDetail.get("productDetail");
			if( productDetails == null ) {
                out.write( "We ran into issues retrieving your Product Details! Please try again later".getBytes() );
				response.sendError(500);
				return;
			}
			List<Object> travelers  = (List<Object>)  policyDetail.get("travelers");
			if( travelers == null || travelers.isEmpty() ) {
                out.write( "We ran into issues retrieving your Traveler Details! Please try again later".getBytes() );
				response.sendError(500);
				return;
			}

			Map<String, Object> primaryTraveler  = (Map<String, Object>) travelers.get(0);
			if( primaryTraveler == null ) {
                out.write( "We ran into issues retrieving your Primary Traveler! Please try again later".getBytes() );
				response.sendError(500);
				return;
			}

			List<Object> addresses  = (List<Object>)  primaryTraveler.get("addresses");
			if( addresses == null || addresses.isEmpty()) {
                out.write( "We ran into issues retrieving your Address Information! Please try again later".getBytes() );
				response.sendError(500);
				return;
			}

			Map<String, Object> address  = (Map<String, Object>) addresses.get(0);
			if( address == null ) {
                out.write( "We ran into issues retrieving your Address Details! Please try again later".getBytes() );
				response.sendError(500);
				return;
			}

			String state = "";
			String product = "";
			String plan = "";
			String country = "";
			String date = "";
			String docType = "PROD_PLAN_DOC";

			Object stateObj = address.get("isoStateOrProvince");
			if( stateObj == null ) {
                out.write( "We were not able to determine your state of residency! Please try again later".getBytes() );
				response.sendError(500);
				return;
			}
			state = stateObj.toString().trim();

            Object countryObj = address.get("isoCountry");
            if( countryObj == null ) {
                out.write( "We were not able to determine your Country of residency! Please try again later".getBytes() );
                response.sendError(500);
                return;
            }
            country = countryObj.toString().trim();

			Object productObj = productDetails.get("productCode");
			if( productObj == null ) {
                out.write( "We were not able to determine which product you purchased! Please try again later".getBytes() );
				response.sendError(500);
				return;
			}
			product = productObj.toString().trim();

			Object planObj = productDetails.get("planCode");
			if( planObj == null ) {
                out.write( "We were not able to determine which plan you purchased! Please try again later".getBytes() );
				response.sendError(500);
				return;
			}
			plan = planObj.toString().trim();			

			Object dateObj = policyDetail.get("effectiveDate");
			if( dateObj == null ) {
                out.write( "Unable to determine effective date of policy! Please try again later".getBytes() );
				response.sendError(500);
				return;
			}
			date = dateObj.toString().trim();

			Configuration conf = configAdmin.getConfiguration("com.travelguard.webservices");
			String proxyPath = conf.getProperties().get("policyOfInsurance").toString();
			proxyPath = proxyPath.replace("{isoState}", state)
							.replace("{productCode}", product)
							.replace("{planCode}", plan)
							.replace("{isoCountry}", country)
							.replace("{effectiveDate}", date)
							.replace("{PROD_PLAN_DOC}", docType);

			String urlPath = conf.getProperties().get("host") + proxyPath;

			log.debug("Retrieving document for path {}", urlPath);
			URL url = new URL(urlPath);
			inputStream = url.openStream();
			response.setContentType("application/pdf");

			log.debug("Successfully Retrieved the document");

			byte[] buffer = new byte[4096];
			int bytesRead;
			while((bytesRead = inputStream.read(buffer)) != -1) {
				out.write(buffer, 0, bytesRead);
			}

			out.flush();
			inputStream.close();
			out.close();
		}
        catch (RuntimeException e) {
			log.error(marker, "Servlet Error : {}", e.getMessage());
			response.setStatus(500);
		}
        finally {
            if( inputStream != null ) {
                inputStream.close();
            }
        }
	}

}