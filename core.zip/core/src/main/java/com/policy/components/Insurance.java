package com.policy.components;


import com.tgfoundation.core.models.functionality.HttpUtilResponse;
import com.policy.models.detailresponse.TravelApiResponse;
import com.policy.models.quoteresponse.QuoteApiResponse;

public interface Insurance {
	
	TravelApiResponse getCalculations(HttpUtilResponse httpUtilResponse);
	
	QuoteApiResponse getCalculationQuote (HttpUtilResponse httpUtilResponse);
}
