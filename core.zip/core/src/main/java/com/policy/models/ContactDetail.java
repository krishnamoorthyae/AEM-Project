package com.policy.models;

import java.util.Collections;
import java.util.List;

public class ContactDetail {
	
	private String label;
	private List<ContactNumber> numbers;
	
	public String getLabel() {
		return label;
	}
	public void setLabel(String label) {
		this.label = label;
	}
	public List<ContactNumber> getNumbers() {
		return Collections.unmodifiableList(numbers);
	}
	public void setNumbers(List<ContactNumber> numbers) {
		this.numbers = Collections.unmodifiableList(numbers);
	}
	
}
