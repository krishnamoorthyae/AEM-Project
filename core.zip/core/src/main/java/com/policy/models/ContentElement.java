package com.policy.models;

public class ContentElement {
	
	private String dataType;
	private String type;
	private String title;
	private String value;
	private String multiValue;
	
	public ContentElement() {}
	
	public ContentElement(String title, String value) {
		this.title = title;
		this.value = value;
	}
	
	public String getDataType() {
		return dataType;
	}
	public void setDataType(String dataType) {
		this.dataType = dataType;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getValue() {
		return value;
	}	
	public void setValue(String value) {
		this.value = value;
	}
	public String getMultiValue() {
		return multiValue;
	}
	public void setMultiValue(String multiValue) {
		this.multiValue = multiValue;
	}
	
	@Override
	public String toString() {	
		return "[DataType:" + getDataType() + ", Type" + getType() + ", Title:" + getTitle() + ", Value=" + getValue() + ", MultiValue:" + getMultiValue() + "]";
	}
	
	
	
}

