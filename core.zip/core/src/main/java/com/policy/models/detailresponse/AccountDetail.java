
package com.policy.models.detailresponse;

import java.util.Collections;
import java.util.List;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class AccountDetail {

    @SerializedName("accountCode")
    @Expose
    private String accountCode;
    @SerializedName("accountLocationCode")
    @Expose
    private String accountLocationCode;
    @SerializedName("accountName")
    @Expose
    private String accountName;
    @SerializedName("organizationId")
    @Expose
    private Integer organizationId;
    @SerializedName("accountContactDetails")
    @Expose
    private List<AccountContactDetail> accountContactDetails = null;

    public String getAccountCode() {
        return accountCode;
    }

    public void setAccountCode(String accountCode) {
        this.accountCode = accountCode;
    }

    public String getAccountLocationCode() {
        return accountLocationCode;
    }

    public void setAccountLocationCode(String accountLocationCode) {
        this.accountLocationCode = accountLocationCode;
    }

    public String getAccountName() {
        return accountName;
    }

    public void setAccountName(String accountName) {
        this.accountName = accountName;
    }

    public Integer getOrganizationId() {
        return organizationId;
    }

    public void setOrganizationId(Integer organizationId) {
        this.organizationId = organizationId;
    }

    public List<AccountContactDetail> getAccountContactDetails() {
        return (accountContactDetails != null) ? Collections.unmodifiableList(accountContactDetails): null;
    }

    public void setAccountContactDetails(List<AccountContactDetail> accountContactDetails) {
        this.accountContactDetails = (accountContactDetails != null) ? Collections.unmodifiableList(accountContactDetails): null;
    }

}
