
package com.policy.models.detailresponse;

import java.util.Collections;
import java.util.List;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Amount {

    @SerializedName("isoCurrencyCode")
    @Expose
    private String isoCurrencyCode;
    @SerializedName("amountValues")
    @Expose
    private List<AmountValue> amountValues = null;

    public String getIsoCurrencyCode() {
        return isoCurrencyCode;
    }

    public void setIsoCurrencyCode(String isoCurrencyCode) {
        this.isoCurrencyCode = isoCurrencyCode;
    }

    public List<AmountValue> getAmountValues() {
        return (amountValues != null) ? Collections.unmodifiableList(amountValues): null;
    }

    public void setAmountValues(List<AmountValue> amountValues) {
        this.amountValues = (amountValues != null) ? Collections.unmodifiableList(amountValues): null;
    }

}
