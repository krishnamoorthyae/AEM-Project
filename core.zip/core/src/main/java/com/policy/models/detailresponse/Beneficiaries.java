package com.policy.models.detailresponse;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Beneficiaries {
	
	 @SerializedName("address")
	 @Expose
	 private String address;
	 @SerializedName("email")
	 @Expose
	 private String email;
	 @SerializedName("fax")
	 @Expose
	 private String fax;
	 @SerializedName("name")
	 @Expose
	 private String name;
	 @SerializedName("phone")
	 @Expose
	 private String phone;
	 
	 public String getAddress() {
		 return address;
	 }
	 
	 public void setAddress(String address) {
		 this.address = address;
	 }
	 
	 public String getEmail() {
		 return email;
	 }
	 
	 public void setEmail(String email) {
		 this.email = email;
	 }
	 
	 public String getFax() {
		 return fax;
	 }
	 
	 public void setFax(String fax) {
		 this.fax = fax;
	 }
	 
	 public String getName() {
		 return name;
	 }
	 
	 public void setName(String name) {
		 this.name = name;
	 }
	 
	 public String getPhone() {
		 return phone;
	 }
	 
	 public void setPhone(String phone) {
		 this.phone = phone;
	 }
}