
package com.policy.models.detailresponse;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class ContactDetail {

    @SerializedName("contactDetailId")
    @Expose
    private String contactDetailId;
    @SerializedName("type")
    @Expose
    private String type;
    @SerializedName("value")
    @Expose
    private String value;
    @SerializedName("expired")
    @Expose
    private String expired;
    @SerializedName("countryCodeId")
    @Expose
    private Integer countryCodeId;

    public String getContactDetailId() {
        return contactDetailId;
    }

    public void setContactDetailId(String contactDetailId) {
        this.contactDetailId = contactDetailId;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public String getExpired() {
        return expired;
    }

    public void setExpired(String expired) {
        this.expired = expired;
    }

    public Integer getCountryCodeId() {
        return countryCodeId;
    }

    public void setCountryCodeId(Integer countryCodeId) {
        this.countryCodeId = countryCodeId;
    }

}
