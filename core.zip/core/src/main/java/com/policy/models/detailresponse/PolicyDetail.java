
package com.policy.models.detailresponse;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class PolicyDetail {

    @SerializedName("quoteId")
    @Expose
    private Integer quoteId;
    @SerializedName("policyNumber")
    @Expose
    private String policyNumber;
    @SerializedName("policyStatus")
    @Expose
    private String policyStatus;
    @SerializedName("policyStatusName")
    @Expose
    private String policyStatusName;
    @SerializedName("displayStatus")
    @Expose
    private String displayStatus;
    @SerializedName("purchaseDate")
    @Expose
    private String purchaseDate;
    @SerializedName("effectiveDate")
    @Expose
    private String effectiveDate;
    @SerializedName("expirationDate")
    @Expose
    private String expirationDate;
    @SerializedName("cancelationDate")
    @Expose
    private String cancelationDate;
    @SerializedName("departureDate")
    @Expose
    private String departureDate;
    @SerializedName("returnDate")
    @Expose
    private String returnDate;
    @SerializedName("applicationDate")
    @Expose
    private String applicationDate;
    @SerializedName("totalTripPrice")
    @Expose
    private TotalTripPrice totalTripPrice;
    @SerializedName("totalNumberOfInsureds")
    @Expose
    private Integer totalNumberOfInsureds;
    @SerializedName("destinations")
    @Expose
    private List<Destination> destinations = null;
    @SerializedName("policyLookup")
    @Expose
    private Object policyLookup;
    @SerializedName("productDetail")
    @Expose
    private ProductDetail productDetail;
    @SerializedName("travelers")
    @Expose
    private List<Traveler> travelers = null;
    @SerializedName("policyContent")
    @Expose
    private List<PolicyContent> policyContent = null;
    @SerializedName("claims")
    @Expose
    private List<Object> claims = null;
    @SerializedName("accountDetail")
    @Expose
    private AccountDetail accountDetail;
    @SerializedName("paymentInfo")
    @Expose
    private PaymentInfo paymentInfo;
    @SerializedName("bookingType")
    @Expose
    private String bookingType;
    @SerializedName("memos")
    @Expose
    private List<Object> memos = null;
    @SerializedName("customElements")
    @Expose
    private List<Object> customElements = null;
    @SerializedName("fulfillmentOption")
    @Expose
    private String fulfillmentOption;

    public Integer getQuoteId() {
        return quoteId;
    }

    public void setQuoteId(Integer quoteId) {
        this.quoteId = quoteId;
    }

    public String getPolicyNumber() {
        return policyNumber;
    }

    public void setPolicyNumber(String policyNumber) {
        this.policyNumber = policyNumber;
    }

    public String getPolicyStatus() {
        return policyStatus;
    }

    public void setPolicyStatus(String policyStatus) {
        this.policyStatus = policyStatus;
    }

    public String getPolicyStatusName() {
        return policyStatusName;
    }

    public void setPolicyStatusName(String policyStatusName) {
        this.policyStatusName = policyStatusName;
    }

    public String getDisplayStatus() {
        return displayStatus;
    }

    public void setDisplayStatus(String displayStatus) {
        this.displayStatus = displayStatus;
    }

    public String getPurchaseDate() {
        return purchaseDate;
    }

    public void setPurchaseDate(String purchaseDate) {
        this.purchaseDate = purchaseDate;
    }

    public String getEffectiveDate() {
        return effectiveDate;
    }

    public void setEffectiveDate(String effectiveDate) {
        this.effectiveDate = effectiveDate;
    }

    public String getExpirationDate() {
        return expirationDate;
    }

    public void setExpirationDate(String expirationDate) {
        this.expirationDate = expirationDate;
    }

    public String getCancelationDate() {
        return cancelationDate;
    }

    public void setCancelationDate(String cancelationDate) {
        this.cancelationDate = cancelationDate;
    }

    public String getDepartureDate() {
        return departureDate;
    }

    public void setDepartureDate(String departureDate) {
        this.departureDate = departureDate;
    }

    public String getReturnDate() {
        return returnDate;
    }

    public void setReturnDate(String returnDate) {
        this.returnDate = returnDate;
    }

    public String getApplicationDate() {
        return applicationDate;
    }

    public void setApplicationDate(String applicationDate) {
        this.applicationDate = applicationDate;
    }
    
    public TotalTripPrice getTotalTripPrice() {
        return totalTripPrice;
    }

    public void setTotalTripPrice(TotalTripPrice totalTripPrice) {
        this.totalTripPrice = totalTripPrice;
    }

    public Integer getTotalNumberOfInsureds() {
        return totalNumberOfInsureds;
    }

    public void setTotalNumberOfInsureds(Integer totalNumberOfInsureds) {
        this.totalNumberOfInsureds = totalNumberOfInsureds;
    }

    public List<Destination> getDestinations() {
        return (destinations != null) ? Collections.unmodifiableList(destinations): null;
    }

    public void setDestinations(List<Destination> destinations) {
        this.destinations = (destinations != null) ? Collections.unmodifiableList(destinations): null;
    }

    public Object getPolicyLookup() {
        return policyLookup;
    }

    public void setPolicyLookup(Object policyLookup) {
        this.policyLookup = policyLookup;
    }

    public ProductDetail getProductDetail() {
        return productDetail;
    }

    public void setProductDetail(ProductDetail productDetail) {
        this.productDetail = productDetail;
    }

    public List<Traveler> getTravelers() {
        return (travelers != null) ? Collections.unmodifiableList(travelers): null;
    }

    public void setTravelers(List<Traveler> travelers) {
        this.travelers = (travelers != null) ? Collections.unmodifiableList(travelers): null;
    }

    public List<PolicyContent> getPolicyContent() {
        return (policyContent != null) ? Collections.unmodifiableList(policyContent): null;
    }

    public void setPolicyContent(List<PolicyContent> policyContent) {
        this.policyContent = (policyContent != null) ? Collections.unmodifiableList(policyContent): null;
    }

    public ArrayList<Object> getClaims() {
        return (claims != null) ? new ArrayList<Object>(claims): null;
    }

    public void setClaims(List<Object> claims) {
        this.claims = (claims != null) ? new ArrayList<Object>(claims): null;
    }

    public AccountDetail getAccountDetail() {
        return accountDetail;
    }

    public void setAccountDetail(AccountDetail accountDetail) {
        this.accountDetail = accountDetail;
    }

    public PaymentInfo getPaymentInfo() {
        return paymentInfo;
    }

    public void setPaymentInfo(PaymentInfo paymentInfo) {
        this.paymentInfo = paymentInfo;
    }

    public String getBookingType() {
        return bookingType;
    }

    public void setBookingType(String bookingType) {
        this.bookingType = bookingType;
    }

    public List<Object> getMemos() {
        return (memos != null) ? new ArrayList<Object>(memos): null;
    }

    public void setMemos(List<Object> memos) {
        this.memos = (memos != null) ? new ArrayList<Object>(memos): null;
    }

    public List<Object> getCustomElements() {
        return (customElements != null) ? new ArrayList<Object>(customElements): null;
    }

    public void setCustomElements(List<Object> customElements) {
        this.customElements = (customElements != null) ? new ArrayList<Object>(customElements): null;
    }

    public String getFulfillmentOption() {
        return fulfillmentOption;
    }

    public void setFulfillmentOption(String fulfillmentOption) {
        this.fulfillmentOption = fulfillmentOption;
    }
}
