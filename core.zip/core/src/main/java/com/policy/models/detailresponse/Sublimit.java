
package com.policy.models.detailresponse;

import java.util.Collections;
import java.util.List;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Sublimit {

    @SerializedName("unitOfCoverage")
    @Expose
    private Double unitOfCoverage;
    @SerializedName("sublimitName")
    @Expose
    private String sublimitName;
    @SerializedName("payoutLimits")
    @Expose
    private List<PayoutLimit> payoutLimits = null;

    public Double getUnitOfCoverage() {
        return unitOfCoverage;
    }

    public void setUnitOfCoverage(Double unitOfCoverage) {
        this.unitOfCoverage = unitOfCoverage;
    }

    public String getSublimitName() {
        return sublimitName;
    }

    public void setSublimitName(String sublimitName) {
        this.sublimitName = sublimitName;
    }

    public List<PayoutLimit> getPayoutLimits() {
    	
        return (payoutLimits != null) ? Collections.unmodifiableList(payoutLimits): null;
    }

    public void setPayoutLimits(List<PayoutLimit> payoutLimits) {
    	
        this.payoutLimits = (payoutLimits != null) ? Collections.unmodifiableList(payoutLimits): null;
    }

}
