
package com.policy.models.detailresponse;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import org.osgi.framework.Constants;

public class TravelApiResponse {

    @SerializedName("detailResponse")
    @Expose
    private DetailResponse detailResponse;
    @SerializedName("product")
    @Expose
    private Object product;
    @SerializedName("method")
    @Expose
    private Object method;
    @SerializedName("schemaVersion")
    @Expose
    private Object schemaVersion;
    @SerializedName("partnerId")
    @Expose
    private String partnerId;
    @SerializedName("partnerSystemId")
    @Expose
    private String partnerSystemId;
    @SerializedName("partnerPos")
    @Expose
    private Object partnerPos;
    @SerializedName(Constants.BUNDLE_NATIVECODE_LANGUAGE)
    @Expose
    private String language;
    @SerializedName("timestamp")
    @Expose
    private String timestamp;
    @SerializedName("transactionId")
    @Expose
    private Object transactionId;
    @SerializedName("offerId")
    @Expose
    private Object offerId;
    @SerializedName("sessionId")
    @Expose
    private Object sessionId;
    @SerializedName("marketingId")
    @Expose
    private Object marketingId;

    @SerializedName("partnerName")
    @Expose
    private String partnerName;

    public DetailResponse getDetailResponse() {
        return detailResponse;
    }

    public void setDetailResponse(DetailResponse detailResponse) {
        this.detailResponse = detailResponse;
    }

    public Object getProduct() {
        return product;
    }

    public void setProduct(Object product) {
        this.product = product;
    }

    public Object getMethod() {
        return method;
    }

    public void setMethod(Object method) {
        this.method = method;
    }

    public Object getSchemaVersion() {
        return schemaVersion;
    }

    public void setSchemaVersion(Object schemaVersion) {
        this.schemaVersion = schemaVersion;
    }

    public String getPartnerId() {
        return partnerId;
    }

    public void setPartnerId(String partnerId) {
        this.partnerId = partnerId;
    }

    public String getPartnerSystemId() {
        return partnerSystemId;
    }

    public void setPartnerSystemId(String partnerSystemId) {
        this.partnerSystemId = partnerSystemId;
    }

    public Object getPartnerPos() {
        return partnerPos;
    }

    public void setPartnerPos(Object partnerPos) {
        this.partnerPos = partnerPos;
    }

    public String getLanguage() {
        return language;
    }

    public void setLanguage(String language) {
        this.language = language;
    }

    public String getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(String timestamp) {
        this.timestamp = timestamp;
    }

    public Object getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(Object transactionId) {
        this.transactionId = transactionId;
    }

    public Object getOfferId() {
        return offerId;
    }

    public void setOfferId(Object offerId) {
        this.offerId = offerId;
    }

    public Object getSessionId() {
        return sessionId;
    }

    public void setSessionId(Object sessionId) {
        this.sessionId = sessionId;
    }

    public Object getMarketingId() {
        return marketingId;
    }

    public void setMarketingId(Object marketingId) {
        this.marketingId = marketingId;
    }

    public String getPartnerName() {
        return partnerName;
    }

    public void setPartnerName(String partnerName) {
        this.partnerName = partnerName;
    }

}
