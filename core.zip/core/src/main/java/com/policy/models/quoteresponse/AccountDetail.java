package com.policy.models.quoteresponse;

import java.util.ArrayList;
import java.util.List;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class AccountDetail {

	@SerializedName("accountCode")
    @Expose
	private String accountCode;
	@SerializedName("accountLocationCode")
    @Expose
	private String accountLocationCode;
	@SerializedName("accountName")
    @Expose
	private String accountName;
	@SerializedName("organizationId")
    @Expose
	private Integer organizationId;
	@SerializedName("accountContactDetails")
    @Expose
	private List<AccountContactDetails> accountContactDetails = null;
	@SerializedName("accountId")
    @Expose
	private Integer accountId;
	@SerializedName("addressLine1")
    @Expose
	private String addressLine1;
	@SerializedName("addressLine2")
    @Expose
	private String addressLine2;
	@SerializedName("addressLine3")
    @Expose
	private String addressLine3;
	@SerializedName("city")
    @Expose
	private String city;
	@SerializedName("state")
    @Expose
	private String state;
	@SerializedName("isoCountryCode")
    @Expose
	private String isoCountryCode;
	@SerializedName("postalCode")
    @Expose
	private String postalCode;
	public String getAccountCode() {
		return accountCode;
	}
	public void setAccountCode(String accountCode) {
		this.accountCode = accountCode;
	}
	public String getAccountLocationCode() {
		return accountLocationCode;
	}
	public void setAccountLocationCode(String accountLocationCode) {
		this.accountLocationCode = accountLocationCode;
	}
	public String getAccountName() {
		return accountName;
	}
	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}
	public Integer getOrganizationId() {
		return organizationId;
	}
	public void setOrganizationId(Integer organizationId) {
		this.organizationId = organizationId;
	}
	public List<AccountContactDetails> getAccountContactDetails() {
		return (accountContactDetails != null) ? new ArrayList<AccountContactDetails>(accountContactDetails) : null;
	}
	public void setAccountContactDetails(List<AccountContactDetails> accountContactDetails) {
		this.accountContactDetails = (accountContactDetails != null) ? new ArrayList<AccountContactDetails>(accountContactDetails) : null;
	}
	public Integer getAccountId() {
		return accountId;
	}
	public void setAccountId(Integer accountId) {
		this.accountId = accountId;
	}
	public String getAddressLine1() {
		return addressLine1;
	}
	public void setAddressLine1(String addressLine1) {
		this.addressLine1 = addressLine1;
	}
	public String getAddressLine2() {
		return addressLine2;
	}
	public void setAddressLine2(String addressLine2) {
		this.addressLine2 = addressLine2;
	}
	public String getAddressLine3() {
		return addressLine3;
	}
	public void setAddressLine3(String addressLine3) {
		this.addressLine3 = addressLine3;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getIsoCountryCode() {
		return isoCountryCode;
	}
	public void setIsoCountryCode(String isoCountryCode) {
		this.isoCountryCode = isoCountryCode;
	}
	public String getPostalCode() {
		return postalCode;
	}
	public void setPostalCode(String postalCode) {
		this.postalCode = postalCode;
	}
}
