package com.policy.models.quoteresponse;

import java.util.ArrayList;
import java.util.List;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Amounts {

	@SerializedName("isoCurrencyCode")
    @Expose
	private String isoCurrencyCode;
	@SerializedName("amountValues")
    @Expose
	private List<AmountValues> amountValues = null;
	public String getIsoCurrencyCode() {
		return isoCurrencyCode;
	}
	public void setIsoCurrencyCode(String isoCurrencyCode) {
		this.isoCurrencyCode = isoCurrencyCode;
	}
	public List<AmountValues> getAmountValues() {
		return (amountValues != null) ? new ArrayList<AmountValues>(amountValues) : null;
	}
	public void setAmountValues(List<AmountValues> amountValues) {
		this.amountValues = (amountValues != null) ? new ArrayList<AmountValues>(amountValues) : null;
	}
}
