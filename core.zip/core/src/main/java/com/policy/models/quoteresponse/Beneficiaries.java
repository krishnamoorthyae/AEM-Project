package com.policy.models.quoteresponse;

import java.util.ArrayList;
import java.util.List;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Beneficiaries {

	@SerializedName("distribution")
	@Expose
	private Integer distribution;	
	@SerializedName("firstName")
    @Expose
	private String firstName;
	@SerializedName("middleName")
    @Expose
	private String middleName;
	@SerializedName("lastName")
    @Expose
	private String lastName;
	@SerializedName("prefix")
    @Expose
	private String prefix;
	@SerializedName("suffix")
    @Expose
	private String suffix;
	@SerializedName("dateOfBirth")
    @Expose
	private String dateOfBirth;
	@SerializedName("gender")
    @Expose
	private String gender;
	@SerializedName("identifications")
    @Expose
	private String identifications;
	@SerializedName("addresses")
    @Expose
	private List<Addresses> addresses = null;
	@SerializedName("contactDetails")
    @Expose
	private List<ContactDetails> contactDetails = null;
	@SerializedName("doNotMarket")
	@Expose
	private Boolean doNotMarket;
	
	public Integer getDistribution() {
		return distribution;
	}
	public void setDistribution(Integer distribution) {
		this.distribution = distribution;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getMiddleName() {
		return middleName;
	}
	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getPrefix() {
		return prefix;
	}
	public void setPrefix(String prefix) {
		this.prefix = prefix;
	}
	public String getSuffix() {
		return suffix;
	}
	public void setSuffix(String suffix) {
		this.suffix = suffix;
	}
	public String getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getIdentifications() {
		return identifications;
	}
	public void setIdentifications(String identifications) {
		this.identifications = identifications;
	}
	public List<Addresses> getAddresses() {		
		return (addresses != null) ? new ArrayList<Addresses>(addresses) : null;
	}
	public void setAddresses(List<Addresses> addresses) {
		this.addresses = (addresses != null) ? new ArrayList<Addresses>(addresses) : null;
	}
	public List<ContactDetails> getContactDetails() {
		return (contactDetails != null) ? new ArrayList<ContactDetails>(contactDetails) : null;
	}
	public void setContactDetails(List<ContactDetails> contactDetails) {
		this.contactDetails = (contactDetails != null) ? new ArrayList<ContactDetails>(contactDetails) : null;
	}
	public Boolean getDoNotMarket() {
		return doNotMarket;
	}
	public void setDoNotMarket(Boolean doNotMarket) {
		this.doNotMarket = doNotMarket;
	}
}
