package com.policy.models.quoteresponse;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.policy.models.detailresponse.Amount_;

public class BenefitDetails {

    @SerializedName("benefitCode")
    @Expose
    private String benefitCode;
    @SerializedName("benefitName")
    @Expose
    private String benefitName;   
    @SerializedName("amounts")
    @Expose
    private List<Amounts> amounts = null;
    @SerializedName("factors")
    @Expose
    private List<Object> factors = null;
    @SerializedName("isStandard")
    @Expose
    private Boolean isStandard;    
    @SerializedName("bundle")
    @Expose
    private Boolean bundle;
    @SerializedName("coverageType")
    @Expose
    private String coverageType;
    
    public Boolean getBundle() {
		return bundle;
	}

	public void setBundle(Boolean bundle) {
		this.bundle = bundle;
	}

	public String getCoverageType() {
		return coverageType;
	}

	public void setCoverageType(String coverageType) {
		this.coverageType = coverageType;
	}

	public String getBenefitCode() {
        return benefitCode;
    }

    public void setBenefitCode(String benefitCode) {
        this.benefitCode = benefitCode;
    }

    public String getBenefitName() {
        return benefitName;
    }

    public void setBenefitName(String benefitName) {
        this.benefitName = benefitName;
    }

    public List<Object> getFactors() {
        return (factors != null) ? Collections.unmodifiableList(factors) : null;
    }

    public void setFactors(List<Object> factors) {
        this.factors = (factors != null) ? Collections.unmodifiableList(factors) : null;
    }
    
    public Boolean getIsStandard() {
        return isStandard;
    }

    public void setIsStandard(Boolean isStandard) {
        this.isStandard = isStandard;
    }

	public List<Amounts> getAmounts() {
		return (amounts != null) ? new ArrayList<Amounts>(amounts) : null;
	}

	public void setAmounts(List<Amounts> amounts) {
		this.amounts = (amounts != null) ? new ArrayList<Amounts>(amounts) : null;
	}

}
