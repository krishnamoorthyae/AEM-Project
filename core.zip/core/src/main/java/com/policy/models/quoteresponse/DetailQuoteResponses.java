package com.policy.models.quoteresponse;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class DetailQuoteResponses {
	@SerializedName("transactionLog")
    @Expose
    private QuoteResponse transactionLog;
    @SerializedName("purchaseRequest")
    @Expose
    private String purchaseRequest;
    @SerializedName("trips")
    @Expose
    private String trips;
    @SerializedName("customElements")
    @Expose
    private String customElements;
    @SerializedName("travelers")
    @Expose
    private String travelers;
    @SerializedName("productDetails")
    @Expose
    private String productDetails;
    @SerializedName("exchangeRateDetails")
    @Expose
    private String exchangeRateDetails;
    @SerializedName("paymentDetail")
    @Expose
    private String paymentDetail;
    @SerializedName("fulfillmentOption")
    @Expose
    private String fulfillmentOption;
    @SerializedName("accountDetail")
    @Expose
    private String accountDetail;
    @SerializedName("submissionType")
    @Expose
    private String submissionType;
    @SerializedName("quoteId")
    @Expose
    private String quoteId;
	public QuoteResponse getTransactionLog() {
		return transactionLog;
	}
	public void setTransactionLog(QuoteResponse transactionLog) {
		this.transactionLog = transactionLog;
	}
	public String getPurchaseRequest() {
		return purchaseRequest;
	}
	public void setPurchaseRequest(String purchaseRequest) {
		this.purchaseRequest = purchaseRequest;
	}
	public String getTrips() {
		return trips;
	}
	public void setTrips(String trips) {
		this.trips = trips;
	}
	public String getCustomElements() {
		return customElements;
	}
	public void setCustomElements(String customElements) {
		this.customElements = customElements;
	}
	public String getTravelers() {
		return travelers;
	}
	public void setTravelers(String travelers) {
		this.travelers = travelers;
	}
	public String getProductDetails() {
		return productDetails;
	}
	public void setProductDetails(String productDetails) {
		this.productDetails = productDetails;
	}
	public String getExchangeRateDetails() {
		return exchangeRateDetails;
	}
	public void setExchangeRateDetails(String exchangeRateDetails) {
		this.exchangeRateDetails = exchangeRateDetails;
	}
	public String getPaymentDetail() {
		return paymentDetail;
	}
	public void setPaymentDetail(String paymentDetail) {
		this.paymentDetail = paymentDetail;
	}
	public String getFulfillmentOption() {
		return fulfillmentOption;
	}
	public void setFulfillmentOption(String fulfillmentOption) {
		this.fulfillmentOption = fulfillmentOption;
	}
	public String getAccountDetail() {
		return accountDetail;
	}
	public void setAccountDetail(String accountDetail) {
		this.accountDetail = accountDetail;
	}
	public String getSubmissionType() {
		return submissionType;
	}
	public void setSubmissionType(String submissionType) {
		this.submissionType = submissionType;
	}
	public String getQuoteId() {
		return quoteId;
	}
	public void setQuoteId(String quoteId) {
		this.quoteId = quoteId;
	}
	
}
