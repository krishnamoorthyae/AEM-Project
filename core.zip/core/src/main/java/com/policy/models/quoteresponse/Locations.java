package com.policy.models.quoteresponse;

import java.util.ArrayList;
import java.util.List;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Locations {

	@SerializedName("type")
	@Expose
	private String type;
	@SerializedName("locationValue")
	@Expose
	private List<LocationValue> locationValue = null;
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public List<LocationValue> getLocationValue() {
		return (locationValue != null) ? new ArrayList<LocationValue>(locationValue) : null;
	}
	public void setLocationValue(List<LocationValue> locationValue) {
		this.locationValue = (locationValue != null) ? new ArrayList<LocationValue>(locationValue) : null;
	} 
}
