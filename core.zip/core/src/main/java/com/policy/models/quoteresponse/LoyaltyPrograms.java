package com.policy.models.quoteresponse;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

public class LoyaltyPrograms {
	@SerializedName("code")
    @Expose
	private String code;
	@SerializedName("displayName")
    @Expose
	private String display_name;
    @SerializedName("amountValues")
    @Expose
    private List<LoyaltyAmounts> amount_values;
    @SerializedName("description")
    @Expose
    private String description;
    @SerializedName("reference")
    @Expose
    private String reference;
    @SerializedName("earnTotalPoints")
    @Expose
    private String earn_total_points;

	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
    public String getDisplayName() {
        return display_name;
    }
    public void setDisplayName(String displayName) {
        this.display_name = displayName;
   	}
	public List<LoyaltyAmounts> getAmountValues() {
		return (amount_values != null) ? new ArrayList<LoyaltyAmounts>(amount_values) : null;
	}
	public void setAmountValues(List<LoyaltyAmounts> amountValues) {
		this.amount_values = (amountValues != null) ? new ArrayList<LoyaltyAmounts>(amountValues) : null;
	}
    public String getDescription() {
        return description;
    }
    public void setDescription(String description) {
        this.description = description;
    }
    public String getReference() {
        return reference;
    }
    public void setReference(String reference) {
        this.reference = reference;
    }
    public String getEarnTotalPoints() {
        return earn_total_points;
    }
    public void setEarnTotalPoints(String earnTotalPoints) {
        this.earn_total_points = earnTotalPoints;
    }
    public List<String> getKeys() {
	    List<String> result = new ArrayList<>();
        Field[] declaredFields = this.getClass().getDeclaredFields();
        for( Field field : declaredFields ) {
//            if( !field.isAccessible() ) {
            String[] nameArr = field.getName().split("_");
            String name = "";
            for( String s : nameArr ) {
                name = name + s.substring(0, 1).toUpperCase() + s.substring(1);
            }
            result.add( name );
//            }
        }
        return result;
    }
}
