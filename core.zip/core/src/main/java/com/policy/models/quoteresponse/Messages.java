package com.policy.models.quoteresponse;

import java.util.ArrayList;
import java.util.List;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Messages {

	@SerializedName("messageType")
    @Expose
	private String messageType;
	@SerializedName("messageValues")
    @Expose
	private List<MessageValues> messageValues = null;
	public String getMessageType() {
		return messageType;
	}
	public void setMessageType(String messageType) {
		this.messageType = messageType;
	}
	public List<MessageValues> getMessageValues() {
		return (messageValues != null) ? new ArrayList<MessageValues>(messageValues) : null;
	}
	public void setMessageValues(List<MessageValues> messageValues) {
		this.messageValues = (messageValues != null) ? new ArrayList<MessageValues>(messageValues) : null;
	}
}
