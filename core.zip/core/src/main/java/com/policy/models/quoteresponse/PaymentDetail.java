package com.policy.models.quoteresponse;

import java.util.ArrayList;
import java.util.List;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class PaymentDetail {

	@SerializedName("cardDetails")
    @Expose
	private List<Object> cardDetails = null;
	@SerializedName("cashDetail")
    @Expose
	private String cashDetail;
	@SerializedName("rewardDetails")
    @Expose
	private List<Object> rewardDetails = null;
	@SerializedName("bankTransferDetail")
    @Expose
	private String bankTransferDetail;
	@SerializedName("directDebitDetail")
    @Expose
	private String directDebitDetail;
	@SerializedName("convenienceStoreDetail")
    @Expose
	private String convenienceStoreDetail;
	@SerializedName("gmoDetail")
    @Expose
	private String gmoDetail;
	@SerializedName("billingFrequency")
    @Expose
	private String billingFrequency;
	public List<Object> getCardDetails() {
		return (cardDetails != null) ? new ArrayList<Object>(cardDetails) : null;
	}
	public void setCardDetails(List<Object> cardDetails) {
		this.cardDetails = (cardDetails != null) ? new ArrayList<Object>(cardDetails) : null;
	}
	public String getCashDetail() {
		return cashDetail;
	}
	public void setCashDetail(String cashDetail) {
		this.cashDetail = cashDetail;
	}
	public List<Object> getRewardDetails() {
		return (rewardDetails != null) ? new ArrayList<Object>(rewardDetails) : null;
	}
	public void setRewardDetails(List<Object> rewardDetails) {
		this.rewardDetails = (rewardDetails != null) ? new ArrayList<Object>(rewardDetails) : null;
	}
	public String getBankTransferDetail() {
		return bankTransferDetail;
	}
	public void setBankTransferDetail(String bankTransferDetail) {
		this.bankTransferDetail = bankTransferDetail;
	}
	public String getDirectDebitDetail() {
		return directDebitDetail;
	}
	public void setDirectDebitDetail(String directDebitDetail) {
		this.directDebitDetail = directDebitDetail;
	}
	public String getConvenienceStoreDetail() {
		return convenienceStoreDetail;
	}
	public void setConvenienceStoreDetail(String convenienceStoreDetail) {
		this.convenienceStoreDetail = convenienceStoreDetail;
	}
	public String getGmoDetail() {
		return gmoDetail;
	}
	public void setGmoDetail(String gmoDetail) {
		this.gmoDetail = gmoDetail;
	}
	public String getBillingFrequency() {
		return billingFrequency;
	}
	public void setBillingFrequency(String billingFrequency) {
		this.billingFrequency = billingFrequency;
	}
}
