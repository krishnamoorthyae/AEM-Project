package com.policy.models.quoteresponse;

import java.util.ArrayList;
import java.util.List;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class QuoteContent {
	
	@SerializedName("contentFormat")
	@Expose
	private String contentFormat;
	@SerializedName("contentItems")
	@Expose
	private List<ContentItems> contentItems = null;
	@SerializedName("contentType")
	@Expose
	private String contentType;
	public String getContentFormat() {
		return contentFormat;
	}

	public void setContentFormat(String contentFormat) {
		this.contentFormat = contentFormat;
	}

	public List<ContentItems> getContentItems() {
		return (contentItems != null) ? new ArrayList<ContentItems>(contentItems) : null;
	}

	public void setContentItems(List<ContentItems> contentItems) {
		this.contentItems = (contentItems != null) ? new ArrayList<ContentItems>(contentItems) : null;
	}

	public String getContentType() {
		return contentType;
	}

	public void setContentType(String contentType) {
		this.contentType = contentType;
	}
	
}
