package com.policy.models.quoteresponse;

import java.util.ArrayList;
import java.util.List;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class QuoteResponse {
	@SerializedName("transactionLog")
    @Expose
    private TransactionLog transactionLog;
    @SerializedName("quoteResponses")
    @Expose
    private List<QuoteResponses> quoteResponses = null;
    @SerializedName("quoteContent")
    @Expose
    private String quoteContent;
    @SerializedName("customElements")
    @Expose
    private List<CustomElements> customElements = null;

    public TransactionLog getTransactionLog() {
        return transactionLog;
    }

    public void setTransactionLog(TransactionLog transactionLog) {
        this.transactionLog = transactionLog;
    }

	public String getQuoteContent() {
		return quoteContent;
	}

	public void setQuoteContent(String quoteContent) {
		this.quoteContent = quoteContent;
	}
	
	public List<QuoteResponses> getQuoteResponses() {
		return (quoteResponses != null) ? new ArrayList<QuoteResponses>(quoteResponses) : null;
	}

	public void setQuoteResponses(List<QuoteResponses> quoteResponses) {
		this.quoteResponses = (quoteResponses != null) ? new ArrayList<QuoteResponses>(quoteResponses) : null;
	}

	public List<CustomElements> getCustomElements() {
		return (customElements != null) ? new ArrayList<CustomElements>(customElements) : null;
	}

	public void setCustomElements(List<CustomElements> customElements) {
		this.customElements = (customElements != null) ? new ArrayList<CustomElements>(customElements) : null;
	}	
    
}
