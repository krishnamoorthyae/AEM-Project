package com.policy.models.quoteresponse;


import java.util.ArrayList;
import java.util.List;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class TripIdentifiers {

	@SerializedName("tripIdentifier")
    @Expose
	private String tripIdentifier;
	@SerializedName("bookingItemIdentifiers")
    @Expose
	private List<BookingItemIdentifiers> bookingItemIdentifiers = null;
	public String getTripIdentifier() {
		return tripIdentifier;
	}
	public void setTripIdentifier(String tripIdentifier) {
		this.tripIdentifier = tripIdentifier;
	}
	public List<BookingItemIdentifiers> getBookingItemIdentifiers() {
		return (bookingItemIdentifiers != null) ? new ArrayList<BookingItemIdentifiers>(bookingItemIdentifiers) : null;
	}
	public void setBookingItemIdentifiers(List<BookingItemIdentifiers> bookingItemIdentifiers) {
		this.bookingItemIdentifiers = (bookingItemIdentifiers != null) ? new ArrayList<BookingItemIdentifiers>(bookingItemIdentifiers) : null;
	}
	
}
