package com.tgfoundation.core.decorators;

import com.day.cq.search.QueryBuilder;
import com.day.cq.wcm.api.WCMMode;
import com.tgfoundation.core.utils.RequestContextHolder;
import com.tgfoundation.core.wrappers.LiveCopyResourceWrapper;
import com.tgfoundation.core.wrappers.core.*;
import com.tgfoundation.core.wrappers.core.form.FormButtonResourceWrapper;
import com.tgfoundation.core.wrappers.core.form.FormHiddenResourceWrapper;
import com.tgfoundation.core.wrappers.core.form.FormTextResourceWrapper;
import com.tgfoundation.core.wrappers.custom.ModalResourceWrapper;
import com.tgfoundation.core.wrappers.custom.MultiSelectDropdownResourceWrapper;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceDecorator;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import javax.servlet.http.HttpServletRequest;
import java.util.*;

@Component( service = ResourceDecorator.class)
public class CoreComponentDecorator implements ResourceDecorator {
    private final Logger logger = LoggerFactory.getLogger(getClass());

    @Reference
    private QueryBuilder queryBuilder;

    @Override
    public @Nullable Resource decorate(@NotNull Resource resource) {
        HashSet<String> componentList = new HashSet<>();
        componentList.add( "tgfoundation/components/core/accordion" );
        componentList.add( "tgfoundation/components/core/breadcrumb" );
        componentList.add( "tgfoundation/components/core/button" );
        componentList.add( "tgfoundation/components/core/carousel" );
        componentList.add( "tgfoundation/components/core/experiencefragment");
        componentList.add( "tgfoundation/components/core/image" );
        componentList.add( "tgfoundation/components/core/tabs" );
        componentList.add( "tgfoundation/components/core/teaser" );
        componentList.add( "tgfoundation/components/core/text" );
        componentList.add( "tgfoundation/components/core/title" );

        componentList.add( "tgfoundation/components/core/form/button" );
        componentList.add( "tgfoundation/components/core/form/hidden" );
        componentList.add( "tgfoundation/components/core/form/text" );

        componentList.add( "tgfoundation/components/custom/modal/modalpopup" );
        componentList.add( "tgfoundation/components/custom/multiSelectDropdown/multiSelectDropdown" );

        if( !componentList.contains( resource.getResourceType() ) ) return null;

        SlingHttpServletRequest request = RequestContextHolder.getRequest();
        if( request == null ) return null;

//        WCMMode wcmMode = WCMMode.fromRequest( request );
//        if( wcmMode != null ) {
//            if( wcmMode.name().equals("EDIT") ) {
////                return null;
//                if( resource.isResourceType("tgfoundation/components/core/title") ) {
//                    return new LiveCopyResourceWrapper( resource, null );
//                }
//                else {
//                    return null;
//                }
//            }
//        }

        Map<String, String> dictionary = (Map<String, String>) request.getAttribute( "data-dictionary" );

        if( dictionary == null ) return null;

        switch ( resource.getResourceType() ) {
            case "tgfoundation/components/core/accordion":
                return new AccordionResourceWrapper( resource, dictionary );

            case "tgfoundation/components/core/breadcrumb":
                return new BreadcrumbResourceWrapper( resource, dictionary );

            case "tgfoundation/components/core/button":
                return new ButtonResourceWrapper( resource, dictionary );

            case "tgfoundation/components/core/carousel":
                return new CarouselResourceWrapper( resource, dictionary );

            case "tgfoundation/components/core/experiencefragment":
                return new ExperienceFragmentResourceWrapper( resource, dictionary );

            case "tgfoundation/components/core/image":
                return new ImageResourceWrapper( resource, dictionary );

            case "tgfoundation/components/core/form/button":
                return new FormButtonResourceWrapper( resource, dictionary );

            case "tgfoundation/components/core/form/hidden":
                return new FormHiddenResourceWrapper( resource, dictionary );

            case "tgfoundation/components/core/form/text":
                return new FormTextResourceWrapper( resource, dictionary );

            case "tgfoundation/components/core/tabs":
                return new TabsResourceWrapper( resource, dictionary );

            case "tgfoundation/components/core/teaser":
                return new TeaserResourceWrapper( resource, dictionary );

            case "tgfoundation/components/core/text":
                    return new TextResourceWrapper( resource, dictionary );

            case "tgfoundation/components/core/title":
                return new TitleResourceWrapper( resource, dictionary );

            case "tgfoundation/components/custom/modal/modalpopup":
                return new ModalResourceWrapper( resource, dictionary );

            case "tgfoundation/components/custom/multiSelectDropdown/multiSelectDropdown":
                return new MultiSelectDropdownResourceWrapper( resource, dictionary );

            default:
                return null;
        }
    }

    @Override
    public @Nullable Resource decorate(@NotNull Resource resource, @NotNull HttpServletRequest httpServletRequest) {
        return null;
    }
}
