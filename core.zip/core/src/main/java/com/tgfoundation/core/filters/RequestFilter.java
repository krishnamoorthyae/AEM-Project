/*
 *  Copyright 2015 Adobe Systems Incorporated
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */
package com.tgfoundation.core.filters;

import com.day.cq.search.QueryBuilder;
import com.day.cq.wcm.api.WCMMode;
import com.tgfoundation.core.models.SecretsManager;
import com.tgfoundation.core.utils.DataDictionary;
import com.tgfoundation.core.utils.RequestContextHolder;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.engine.EngineConstants;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.osgi.service.component.propertytypes.ServiceDescription;
import org.osgi.service.component.propertytypes.ServiceRanking;
import org.osgi.service.component.propertytypes.ServiceVendor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import javax.servlet.*;
import java.io.IOException;
import java.util.Map;

/**
 * Simple servlet filter component that logs incoming requests.
 */
@Component(service = Filter.class,
           property = {
                   EngineConstants.SLING_FILTER_SCOPE + "=" + EngineConstants.FILTER_SCOPE_REQUEST,
           })
@ServiceDescription("Filter Used to store request for Resource Decorators")
@ServiceRanking(-700)
@ServiceVendor("Travel Guard")
public class RequestFilter implements Filter {

    private final Logger logger = LoggerFactory.getLogger(getClass());

    @Reference
    private QueryBuilder queryBuilder;

    @Reference
    private transient SecretsManager secretsManager;

    @Override
    public void doFilter(final ServletRequest request, final ServletResponse response,
                         final FilterChain filterChain) throws IOException, ServletException {

        if( request instanceof SlingHttpServletRequest ) {
            if( ((SlingHttpServletRequest) request).getResource().isResourceType("cq:Page") || ((SlingHttpServletRequest) request).getCookie("selectors") != null ) {
                SlingHttpServletRequest slingRequest = (SlingHttpServletRequest) request;
                DataDictionary dictionary = new DataDictionary( queryBuilder );

                dictionary.getDataDictionary( slingRequest );
                Object dictionaryObj = request.getAttribute( "data-dictionary" );

                if( dictionaryObj != null ) {
                    Map<String, String> dictionaryMap = (Map<String, String>) dictionaryObj;

                    if( dictionaryMap != null && secretsManager != null) {
                        String env = secretsManager.getSecret("environment");
                        dictionaryMap.put( "{environment}", env );
                        request.setAttribute("data-dictionary", dictionaryMap );
                    }
                }

                if( request.getAttribute("data-dictionary") != null ) {
                    RequestContextHolder.setRequest( (SlingHttpServletRequest) request );
                }
            }
        }

        try {
            filterChain.doFilter(request, response);
        }
        finally {
            RequestContextHolder.clear();
        }
    }

    @Override
    public void init(FilterConfig filterConfig) {
    }

    @Override
    public void destroy() {
    }

}