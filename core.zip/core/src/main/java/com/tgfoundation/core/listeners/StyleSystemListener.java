package com.tgfoundation.core.listeners;

import com.day.cq.commons.jcr.JcrConstants;
import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.jcr.Node;
import javax.jcr.RepositoryException;
import javax.jcr.observation.Event;
import javax.jcr.observation.EventIterator;
import javax.jcr.observation.EventListener;
import java.util.Random;

@Component(service = EventListener.class, immediate = true)
public class StyleSystemListener implements EventListener {

    private static final Logger log = LoggerFactory.getLogger( StyleSystemListener.class );

    @Reference
    private ResourceResolverFactory resolverFactory;

    @Override
    public void onEvent(EventIterator eventIterator) {
        while ( eventIterator.hasNext() ) {
            Event event = eventIterator.nextEvent();

            try {
                if( event.getType() == Event.NODE_ADDED ) {
                    String nodePath = event.getPath();

                    if( nodePath.contains( JcrConstants.JCR_CONTENT ) ) {
                        ResourceResolver resolver = resolverFactory.getServiceResourceResolver(null);

                        Resource resource = resolver.getResource( nodePath );

                        if( resource == null ) continue;

                        Node node = resource.adaptTo( Node.class );

                        if( node == null ) continue;

                        if( node.hasProperty("cq:cssClass") ) {
                            String styleString = node.getProperty("cq:cssClass").getString();
                            String[] styleClasses = styleString.split(" ");
                            for( int i = 0; i < styleClasses.length; i++ ) {
                                String str = styleClasses[i];
                                if( str.contains("building-block") ) {
                                    Random rand = new Random();
                                    int n = rand.nextInt(999999999);

                                    String id = "aem-building-blocks_" + n + "_styles";
                                    styleClasses[i] = id;
                                }
                            }

                            node.setProperty("cq:cssClass", String.join( " ", styleClasses ) );
                        }
                    }
                }
            }
            catch (RepositoryException e) {
                log.error( "Repository Error | Style System Listener : {}", e.getMessage() );
                throw new RuntimeException(e);
            }
            catch (LoginException e) {
                log.error( "Login Exception | Style System Listener : {}", e.getMessage() );
                throw new RuntimeException(e);
            }
        }
    }
}
