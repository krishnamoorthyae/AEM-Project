package com.tgfoundation.core.models;

import java.util.List;
import java.util.Map;

public interface ModalPopup {

    public List<Map<String,String>> getModalPopupElements();

}
