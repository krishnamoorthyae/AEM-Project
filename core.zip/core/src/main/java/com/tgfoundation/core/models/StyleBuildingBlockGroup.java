package com.tgfoundation.core.models;

import java.util.Map;

public interface StyleBuildingBlockGroup {
    public Map<String, String> getMediaQueries();

    public Map<String, String> getTargets();

    public Map<String, GenericListModel> getStyleOptions();

    public String getName();

    public String getPath();
}
