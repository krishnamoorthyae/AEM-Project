package com.tgfoundation.core.models;

public interface StyleShortcut {
    public String getName();

    public String getPath();

    public GenericListItem getShortcut();
}
