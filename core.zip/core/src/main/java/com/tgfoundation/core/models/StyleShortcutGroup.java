package com.tgfoundation.core.models;

import java.util.List;

public interface StyleShortcutGroup {
    public List<StyleShortcut> getStyles();

    public String getName();

    public String getPath();
}
