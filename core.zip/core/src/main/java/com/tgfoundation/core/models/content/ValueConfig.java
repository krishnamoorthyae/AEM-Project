package com.tgfoundation.core.models.content;

import java.util.List;

public interface ValueConfig {
    public String getDefault();

    public String getDefaultType();

    public List<String> getSessionValues();

    public List<String> getInputNames();

    public List<String> getFunctionCalls();
}
