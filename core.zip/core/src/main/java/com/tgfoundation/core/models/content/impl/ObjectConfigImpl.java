package com.tgfoundation.core.models.content.impl;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.tgfoundation.core.models.content.ObjectConfig;
import com.tgfoundation.core.models.content.ValueConfig;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.SlingObject;
import javax.annotation.PostConstruct;
import javax.inject.Inject;
import javax.jcr.RepositoryException;

@Model(
        adaptables = {SlingHttpServletRequest.class, Resource.class},
        adapters = {ObjectConfig.class},
        defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL
)
public class ObjectConfigImpl implements ObjectConfig {
    @SlingObject
    private Resource resource;

    @Inject
    private ResourceResolver resourceResolver;

    private final String OBJECT_CONTENT_FRAGMENT_PATH = "/conf/tgfoundation/settings/dam/cfm/models/object-config";

    private final String VALUE_CONTENT_FRAGMENT_PATH = "/conf/tgfoundation/settings/dam/cfm/models/value-config";

    private Boolean isArrayTemplate = false;

    private JsonArray jsonArray = new JsonArray();

    @PostConstruct
    public void init() throws RepositoryException {
        if( resource == null ) return;

        ValueMap valueMap = resource.getValueMap();
        if( valueMap == null ) return;

        Object isArrayTemplateObj = valueMap.get("arrayTemplate");
        if (isArrayTemplateObj != null) {
            isArrayTemplate = "true".equals(isArrayTemplateObj.toString());
        }

        String[] keyValuePair = valueMap.get("keyValuePairCMF", String[].class);
        for( String str : keyValuePair ) {
            JsonObject obj = JsonParser.parseString( str ).getAsJsonObject();

            Resource data = resourceResolver.getResource( obj.get("value").getAsString() + "/jcr:content/data");
            if( data == null ) continue;

            Resource master = resourceResolver.getResource( data.getPath() + "/master");
            if( master == null ) continue;

            ValueMap dataValueMap = data.getValueMap();

            Object modelType = dataValueMap.get( "cq:model" );
            if( modelType == null ) continue;

            if( OBJECT_CONTENT_FRAGMENT_PATH.equals( modelType.toString() ) ) {
                //accounting for Object config
                ObjectConfig value = master.adaptTo( ObjectConfig.class );

                if( value == null ) continue;

                obj.add("value", generateValueFromObject( value ));
                jsonArray.add( obj );
            }
            else if ( VALUE_CONTENT_FRAGMENT_PATH.equals( modelType.toString() ) ) {
                //accounting for value config
                ValueConfig value = master.adaptTo( ValueConfig.class );

                if( value == null ) continue;

                obj.add("value", generateValueObject( value ));
                jsonArray.add( obj );
            }
        }
    }

    private JsonObject generateValueFromObject( ObjectConfig objectConfig ) {
        JsonObject object = new JsonObject();

        object.addProperty("isArrayTemplate", objectConfig.isArrayTemplate() );
        object.add("properties", objectConfig.getObjectJson() );

        return object;
    }

    private JsonObject generateValueObject( ValueConfig valueConfig ) {
        JsonObject jsonVal = new JsonObject();
        if( !"none".equals( valueConfig.getDefaultType() ) ) {
            jsonVal.addProperty( "default", valueConfig.getDefault() );
            jsonVal.addProperty( "defaultType", valueConfig.getDefaultType() );
        }

        JsonArray sessArr = new JsonArray();
        for( String sessStr : valueConfig.getSessionValues() ) {
            sessArr.add( sessStr );
        }
        if( !sessArr.isEmpty() ) {
            jsonVal.add("sessionNames", sessArr );
        }

        JsonArray inpArr = new JsonArray();
        for( String inpStr : valueConfig.getInputNames() ) {
            inpArr.add( inpStr );
        }
        if( !inpArr.isEmpty() ) {
            jsonVal.add("inputNames", inpArr );
        }

        JsonArray functionArr = new JsonArray();
        for( String funcStr : valueConfig.getFunctionCalls() ) {
            functionArr.add( funcStr );
        }
        if( !functionArr.isEmpty() ) {
            jsonVal.add("functionNames", functionArr );
        }

        return jsonVal;
    }

    @Override
    public Boolean isArrayTemplate() {
        return isArrayTemplate;
    }

    @Override
    public JsonArray getObjectJson() {
        return jsonArray;
    }
}
