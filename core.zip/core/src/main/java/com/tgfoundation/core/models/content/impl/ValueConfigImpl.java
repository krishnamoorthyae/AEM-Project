package com.tgfoundation.core.models.content.impl;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.tgfoundation.core.models.content.ValueConfig;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.SlingObject;
import javax.annotation.PostConstruct;
import javax.inject.Inject;
import javax.jcr.RepositoryException;
import java.util.ArrayList;
import java.util.List;

@Model(
        adaptables = {SlingHttpServletRequest.class, Resource.class},
        adapters = {ValueConfig.class},
        defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL
)
public class ValueConfigImpl implements ValueConfig {
    @SlingObject
    private Resource resource;

    @Inject
    private ResourceResolver resourceResolver;

    private String defaultVal = "";

    private String defaultType = "";

    private List<String> sessionVals = new ArrayList<>();

    private List<String> inputNames = new ArrayList<>();

    private List<String> functionCalls = new ArrayList<>();

    @PostConstruct
    public void init() throws RepositoryException {
        if( resource == null ) return;

        ValueMap valueMap = resource.getValueMap();
        if( valueMap == null ) return;

        Object defaultValObj = valueMap.get("default");
        if (defaultValObj != null) {
            defaultVal = defaultValObj.toString();
        }

        Object defaultTypeObj = valueMap.get("defaultType");
        if (defaultTypeObj != null) {
            defaultType = defaultTypeObj.toString();
        }

        String[] sessionArray = valueMap.get("sessionValuesCMF", String[].class);
        if (sessionArray != null) {
            for( String str : sessionArray ) {
                JsonObject jsonObject = JsonParser.parseString( str ).getAsJsonObject();
                JsonElement orderElem = jsonObject.get("sessionOrder");
                if( orderElem != null ) {
                    String order = orderElem.getAsString();
                    if( order != null && Integer.parseInt( order ) < sessionVals.size() ) {
                        sessionVals.add(Integer.parseInt( order ), jsonObject.get("sessionName").getAsString() );
                    }
                    else {
                        sessionVals.add( jsonObject.get("sessionName").getAsString() );
                    }
                }
                else {
                    sessionVals.add( jsonObject.get("sessionName").getAsString() );
                }
            }
        }

        String[] inputArray = valueMap.get("inputValuesCMF", String[].class);
        if (inputArray != null) {
            for( String str : inputArray ) {
                JsonObject jsonObject = JsonParser.parseString( str ).getAsJsonObject();
                JsonElement orderElem = jsonObject.get("inputOrder");
                if( orderElem != null ) {
                    String order = orderElem.getAsString();
                    if( order != null && Integer.parseInt( order ) < inputNames.size() ) {
                        inputNames.add(Integer.parseInt( order ), jsonObject.get("inputName").getAsString() );
                    }
                    else {
                        inputNames.add( jsonObject.get("inputName").getAsString() );
                    }
                }
                else {
                    inputNames.add( jsonObject.get("inputName").getAsString() );
                }
            }
        }

        String[] functionArray = valueMap.get("functionCallCMF", String[].class);
        if (functionArray != null) {
            for( String str : functionArray ) {
                JsonObject jsonObject = JsonParser.parseString( str ).getAsJsonObject();
                JsonElement orderElem = jsonObject.get("functionOrder");
                if( orderElem != null ) {
                    String order = orderElem.getAsString();
                    if( order != null && Integer.parseInt( order ) < functionCalls.size() ) {
                        functionCalls.add(Integer.parseInt( order ), jsonObject.get("functionName").getAsString() );
                    }
                    else {
                        functionCalls.add( jsonObject.get("functionName").getAsString() );
                    }
                }
                else {
                    functionCalls.add( jsonObject.get("functionName").getAsString() );
                }
            }
        }

    }

    @Override
    public String getDefault() {
        return defaultVal;
    }

    @Override
    public String getDefaultType() {
        return defaultType;
    }

    @Override
    public List<String> getSessionValues() {
        return new ArrayList<>( sessionVals );
    }

    @Override
    public List<String> getInputNames() {
        return new ArrayList<>( inputNames );
    }

    @Override
    public List<String> getFunctionCalls() {
        return new ArrayList<>( functionCalls );
    }
}
