package com.tgfoundation.core.models.functionality.impl;

import com.tgfoundation.core.models.functionality.HttpUtilResponse;
import org.apache.http.HttpResponse;

public class HttpUtilResponseImpl implements HttpUtilResponse {

    //data members
    private int status;
    private String body;
    private HttpResponse response;
    //getters 
    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public String getBody() {
        return (body != null) ? body : "";
    }

    //setters
    public void setBody(String body) {
        this.body = body;
    }

    public HttpResponse getResponse() {
        return response;
    }

    public void setResponse(HttpResponse response) {
        this.response = response;
    }
}
