package com.tgfoundation.core.models.impl;

import com.tgfoundation.core.models.ModalPopup;
import com.tgfoundation.core.utils.DataDictionarySwap;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.SlingObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import javax.inject.Inject;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Model(
        adaptables = SlingHttpServletRequest.class,
        adapters = ModalPopup.class,
        defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL
)

public class ModalPopupimpl implements ModalPopup{
    @SlingObject
    private SlingHttpServletRequest request;

	 private static final Logger LOG = LoggerFactory.getLogger(ModalPopupimpl.class);
	 public static final String MODAL_ID = "modalId";
	 public static final String FRAGMENT_VARIATION_PATH = "fragmentVariationPath";
	 public static final String MODAL_CORNER_STYLES = "modalCornerStyles";
	 public static final String MODAL_BACKGROUND_COLOR = "modalBackgroundColor";
	 public static final String SHORTCUTKEYS = "shortcutKeys";
	 @Inject
	 Resource componentResource;
	 
   @Override
   public List<Map<String, String>> getModalPopupElements() {
       List<Map<String, String>> modalElements=new ArrayList<>();
       Object dataObject = request.getAttribute("data-dictionary");
       try {
           Resource navElement=componentResource.getChild("modalItems");
           if(navElement!=null){
               for (Resource element : navElement.getChildren()) {
                   Map<String,String> elementMap=new HashMap<>();
                   elementMap.put(MODAL_ID,element.getValueMap().get(MODAL_ID,String.class));
                   elementMap.put(FRAGMENT_VARIATION_PATH,element.getValueMap().get(FRAGMENT_VARIATION_PATH,String.class));
                   elementMap.put(MODAL_CORNER_STYLES,element.getValueMap().get(MODAL_CORNER_STYLES,String.class));
                   elementMap.put(MODAL_BACKGROUND_COLOR,element.getValueMap().get(MODAL_BACKGROUND_COLOR,String.class));
				   elementMap.put(SHORTCUTKEYS,element.getValueMap().get(SHORTCUTKEYS,String.class));

                   if( dataObject != null ) {
                       Map<String, String> dictionary = (Map<String, String>) dataObject;

                       DataDictionarySwap dataDictionarySwap = new DataDictionarySwap( dictionary, element.getValueMap() );

                       dataDictionarySwap.updateValueMapStringSimple( elementMap, MODAL_ID );
                       dataDictionarySwap.updateValueMapStringSimple( elementMap, FRAGMENT_VARIATION_PATH );
                       dataDictionarySwap.updateValueMapStringSimple( elementMap, MODAL_CORNER_STYLES );
                       dataDictionarySwap.updateValueMapStringSimple( elementMap, MODAL_BACKGROUND_COLOR );
                       dataDictionarySwap.updateValueMapStringSimple( elementMap, SHORTCUTKEYS );

                       dataDictionarySwap.updateValueMapStringById( elementMap, MODAL_ID );
                       dataDictionarySwap.updateValueMapStringById( elementMap, FRAGMENT_VARIATION_PATH );
                       dataDictionarySwap.updateValueMapStringById( elementMap, MODAL_CORNER_STYLES );
                       dataDictionarySwap.updateValueMapStringById( elementMap, MODAL_BACKGROUND_COLOR );
                       dataDictionarySwap.updateValueMapStringById( elementMap, SHORTCUTKEYS );
                   }

                   modalElements.add(elementMap);
               }
           }

       } catch (RuntimeException e){
           LOG.error("ERROR while getting modal popup values {}",e.getMessage());
       }
       return modalElements;
   }
}
