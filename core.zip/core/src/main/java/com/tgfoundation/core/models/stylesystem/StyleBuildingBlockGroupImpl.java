package com.tgfoundation.core.models.stylesystem;

import com.day.cq.search.QueryBuilder;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.tgfoundation.core.models.GenericListModel;
import com.tgfoundation.core.models.StyleBuildingBlock;
import com.tgfoundation.core.models.StyleBuildingBlockGroup;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.RequestAttribute;
import org.apache.sling.models.annotations.injectorspecific.SlingObject;
import javax.annotation.PostConstruct;
import javax.inject.Inject;
import javax.jcr.RepositoryException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Model(
        adaptables = {SlingHttpServletRequest.class, Resource.class},
        adapters = {StyleBuildingBlockGroup.class},
        defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL
)
public class StyleBuildingBlockGroupImpl implements StyleBuildingBlockGroup {
    @SlingObject
    private Resource resource;

    @Inject
    private ResourceResolver resourceResolver;

    @RequestAttribute
    String path;

    @RequestAttribute
    String resourceType;

    private final Map<String, String> mediaQueries = new HashMap<>();

    private final Map<String, String> targetConfig = new HashMap<>();

    private final Map<String, GenericListModel> styleValueConfig = new HashMap<>();

    @PostConstruct
    public void init() throws RepositoryException {
        if( resource == null ) return;

        Resource master = resource.getChild( "jcr:content/data/master" );

        if( master == null ) return;

        ValueMap valueMap = master.getValueMap();

        setupMediaQueries( valueMap.get("mediaQueryConfig", String[].class));

        setupTargets( valueMap.get("targetConfig", String[].class));

        setupStyleValues( valueMap.get("styleValuesConfig", String[].class));
    }

    private void setupStyleValues( String[] contentFragments ) {
        if( contentFragments == null ) return;

        for( String path : contentFragments ) {
            Resource fragment = resourceResolver.getResource( path );

            if( fragment == null ) continue;

            Resource master = fragment.getChild("jcr:content/data/master");

            if( master == null ) continue;

            ValueMap masterMap = master.getValueMap();

            String propertyName = masterMap.get("propertyName", String.class );

            if( propertyName == null ) continue;

            String[] styleValues = masterMap.get("styleValueCMF", String[].class );

            if( styleValues == null ) continue;

            for( String s : styleValues ) {
                JsonObject object = JsonParser.parseString( s ).getAsJsonObject();

                String listPath = object.get("styleValuesGenericList").getAsString();

                Resource listResource = resourceResolver.getResource( listPath );

                if( listResource == null ) continue;

                GenericListModel list = listResource.adaptTo( GenericListModel.class );

                if( list == null ) continue;

                styleValueConfig.put( propertyName, list );
            }
        }
    }

    private void setupTargets( String[] paths ) {
        if (paths == null) return;

        for (String path : paths) {
            Resource fragment = resourceResolver.getResource(path);

            if (fragment == null) continue;

            Resource master = fragment.getChild("jcr:content/data/master");

            if (master == null) continue;

            ValueMap masterMap = master.getValueMap();

            String displayValue = masterMap.get("displayValue", String.class );

            if( displayValue == null || displayValue.isEmpty() ) continue;

            StringBuilder targetBuilder = new StringBuilder();
            targetBuilder.append("{dynamic}");

            if( masterMap.get("styleTargetsCMF") != null ) {
                String[] targets = masterMap.get("styleTargetsCMF", String[].class);

                for( String target : targets ) {
                    JsonObject object = JsonParser.parseString( target ).getAsJsonObject();

                    String location = object.get("location").getAsString();
                    switch (location) {
                        case "immediate":
                            targetBuilder.append(" > ");
                            break;
                        case "all":
                            targetBuilder.append(" ");
                            break;
                        case "and":
                            targetBuilder.append(", {dynamic} ");
                            break;
                        case "plus":
                            targetBuilder.append(" + ");
                    }

                    String type = object.get("type").getAsString();
                    switch ( type ) {
                        case "class":
                            targetBuilder.append(" .");
                            break;
                        case "id":
                            targetBuilder.append(" #");
                            break;
                        case "tag":
                            targetBuilder.append(" ");
                    }

                    String name = object.get("name").getAsString();
                    targetBuilder.append( name );
                }
            }

            targetBuilder.append(" {");

            targetConfig.put( displayValue, targetBuilder.toString() );
        }
    }

    private void setupMediaQueries( String[] contentFragments ) {
        if( contentFragments == null ) return;

        for( String path : contentFragments ) {
            Resource fragment = resourceResolver.getResource( path );

            if( fragment == null ) continue;

            Resource master = fragment.getChild("jcr:content/data/master");

            if( master == null ) continue;

            ValueMap masterMap = master.getValueMap();

            String displayValue = masterMap.get("displayValue", String.class );

            if( displayValue == null ) continue;

            String queryOptions = masterMap.get("queryOptions", String.class );

            if( queryOptions == null ) continue;

            if( "default".equals( queryOptions ) ) {
                String option = masterMap.get( "cssOptionValueGenericList", String.class );

                if( option == null ) continue;

                if( "(blank)".equals( option ) || option.isEmpty() ) {
                    option = " ";
                }
                else {
                    option += " {";
                }

                mediaQueries.put( displayValue, option );
            }
            else if ( "custom".equals( queryOptions ) ) {
                StringBuilder mediaBuilder = new StringBuilder();
                mediaBuilder.append( "@media " );

                String[] custom = masterMap.get("cssValueCustomCMF", String[].class );

                if( custom == null ) continue;

                for( int i = 0; i < custom.length; i++ ) {
                    String s = custom[i];

                    if( i != 0 ) {
                        mediaBuilder.append( "and " );
                    }

                    JsonObject object = JsonParser.parseString( s ).getAsJsonObject();
                    boolean isScreen = "true".equals( object.get("screen").getAsString() );
                    boolean isPrint = "true".equals( object.get("print").getAsString() );

                    if( isScreen ) {
                        mediaBuilder.append("screen ");
                    }
                    if( isScreen && isPrint ) {
                        mediaBuilder.append("and print ");
                    }
                    else {
                        mediaBuilder.append("print ");
                    }

                    String width = object.get("cssFeatureGenericList").getAsString();
                    String pixel = object.get("pixel").getAsString();

                    mediaBuilder.append("(").append(width).append(": ");
                    mediaBuilder.append(pixel).append("px").append(") ");
                }
                mediaBuilder.append("{");

                mediaQueries.put( displayValue, mediaBuilder.toString() );
            }
        }
    }

    @Override
    public Map<String, String> getMediaQueries() {
        return new HashMap<>( mediaQueries );
    }

    @Override
    public Map<String, String> getTargets() {
        return new HashMap<>( targetConfig );
    }

    @Override
    public Map<String, GenericListModel> getStyleOptions() {
        return new HashMap<>( styleValueConfig );
    }

    @Override
    public String getName() {
        return null;
    }

    @Override
    public String getPath() {
        return null;
    }
}
