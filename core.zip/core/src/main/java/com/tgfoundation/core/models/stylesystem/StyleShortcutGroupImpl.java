package com.tgfoundation.core.models.stylesystem;

import com.day.cq.commons.jcr.JcrConstants;
import com.tgfoundation.core.models.StyleShortcut;
import com.tgfoundation.core.models.StyleShortcutGroup;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.SlingObject;
import javax.annotation.PostConstruct;
import javax.jcr.RepositoryException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

@Model(
        adaptables = {SlingHttpServletRequest.class, Resource.class},
        adapters = {StyleShortcutGroup.class},
        defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL
)
public class StyleShortcutGroupImpl implements StyleShortcutGroup {
    @SlingObject
    private Resource resource;

    private String path;

    private String name;

    private final List<StyleShortcut> shortcuts = new ArrayList<>();

    @PostConstruct
    public void init() throws RepositoryException {
        if( resource == null ) return;

        ValueMap valueMap = resource.getValueMap();

        path = resource.getPath();
        name = valueMap.get(JcrConstants.JCR_TITLE, String.class);

        Iterator<Resource> iterator = resource.listChildren();
        while ( iterator.hasNext() ) {
            Resource shortcutResource = iterator.next();

            if( shortcutResource == null ) continue;

            StyleShortcut styleShortcut = shortcutResource.adaptTo( StyleShortcut.class );

            if( styleShortcut == null ) continue;

            shortcuts.add( styleShortcut );
        }
    }

    @Override
    public List<StyleShortcut> getStyles() {
        return new ArrayList<>( shortcuts );
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public String getPath() {
        return path;
    }
}
