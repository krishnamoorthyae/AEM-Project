package com.tgfoundation.core.models.stylesystem;

import com.day.cq.commons.jcr.JcrConstants;
import com.tgfoundation.core.models.GenericListItem;
import com.tgfoundation.core.models.GenericListModel;
import com.tgfoundation.core.models.StyleShortcut;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.SlingObject;
import javax.annotation.PostConstruct;
import javax.jcr.RepositoryException;
import java.util.List;

@Model(
        adaptables = {SlingHttpServletRequest.class, Resource.class},
        adapters = {StyleShortcut.class},
        defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL
)
public class StyleShortcutImpl implements StyleShortcut {
    @SlingObject
    private Resource resource;

    private String path;

    private String name;

    private GenericListItem item;

    @PostConstruct
    public void init() throws RepositoryException {
        if( resource == null ) return;

        ValueMap valueMap = resource.getValueMap();

        path = resource.getPath();
        name = valueMap.get(JcrConstants.JCR_TITLE, String.class);

        if( name == null ) {
            name = resource.getName();
        }

        GenericListModel genericListModel = resource.adaptTo( GenericListModel.class );

        List< GenericListItem > genericListItems = genericListModel.getItems();

        if( genericListItems == null ) return;

        item = genericListItems.get( 0 );
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public String getPath() {
        return path;
    }

    @Override
    public GenericListItem getShortcut() {
        return item;
    }
}
