package com.tgfoundation.core.scripts;

import com.adobe.cq.dam.cfm.*;
import com.day.cq.commons.jcr.JcrConstants;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.PersistenceException;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.apache.sling.servlets.annotations.SlingServletPaths;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.Marker;

import javax.jcr.Node;
import javax.jcr.NodeIterator;
import javax.jcr.RepositoryException;
import javax.jcr.Session;
import javax.servlet.Servlet;
import java.io.IOException;
import java.util.ArrayList;

@Component(service = { Servlet.class })
@SlingServletPaths("/bin/foundation/migrate/acs")
public class ACSCommonMigration extends SlingAllMethodsServlet {
    private static Logger log = LoggerFactory.getLogger(ACSCommonMigration.class);
    private static Marker marker;

    @Reference
    ContentFragmentManager contentFragmentManager;

    @Override
    protected void doGet( SlingHttpServletRequest request, SlingHttpServletResponse response ) throws IOException {
        ResourceResolver resolver = request.getResourceResolver();
        Session session = resolver.adaptTo( Session.class );

        String lists = "/etc/acs-commons/lists";
        String fragmentParentPath = "/content/dam/generic-lists";

        try {
            createContentFragments( resolver.getResource(lists).adaptTo(Node.class), resolver, resolver.getResource(fragmentParentPath).adaptTo(Node.class) );
            resolver.commit();
        } catch (RepositoryException e) {
            throw new RuntimeException(e);
        }
    }

    public void createContentFragments(Node listNode, ResourceResolver resolver, Node contentNode) throws RepositoryException, PersistenceException {
        String tempaltePath = "/conf/tgfoundation/settings/dam/cfm/models/generic-list";

        if( listNode == null ) return;

        NodeIterator nodeIterator = listNode.getNodes();
        while ( nodeIterator.hasNext() ) {
            Node next = nodeIterator.nextNode();
            Resource resource = resolver.getResource( next.getPath() );

            if( "cq:Page".equals( resource.getValueMap().get("jcr:primaryType", String.class) ) ) {
                String fragmentName = next.getName();
                Node jcrContent = next.getNode( "jcr:content" );

                if( !jcrContent.hasNode("list" ) ) {
                    continue;
                }

                Node list = jcrContent.getNode("list");

                String title = next.getName();
                if( jcrContent.hasProperty( "jcr:title") ) {
                    title = jcrContent.getProperty("jcr:title").getString();
                }

                if( !contentNode.hasNode( fragmentName ) ) {
                    Resource fragmentParent = resolver.getResource( contentNode.getPath() );
                    Resource templateResource = resolver.getResource( tempaltePath );
                    FragmentTemplate  fragmentTemplate = templateResource.adaptTo(FragmentTemplate.class);

                    try {
                        ContentFragment contentFragment = fragmentTemplate.createFragment(fragmentParent , fragmentName, title );
                        ContentElement contentElement = contentFragment.getElement("genericListCMF");
                        FragmentData data = contentElement.getValue();
                        data.setValue( getGenericListAsContentFragment( list ) );
                        contentElement.setValue( data );
                        resolver.commit();
                    } catch (ContentFragmentException e) {
                        throw new RuntimeException(e);
                    }
                }
            }
            else if ( "nt:unstructured".equals( resource.getValueMap().get("jcr:primaryType", String.class) ) ) {
                continue;
            }
            else if( !contentNode.hasNode( next.getName() ) ){
                Node nextContent;
                if( next.hasProperty(JcrConstants.JCR_TITLE) ) {
                    nextContent = createFolder(contentNode, next.getName(), next.getProperty(JcrConstants.JCR_TITLE).getString());
                }
                else {
                    nextContent = createFolder(contentNode, next.getName(), next.getName());
                }
                createContentFragments( next, resolver, nextContent );
            }
        }

    }

    private String[] getGenericListAsContentFragment( Node list ) throws RepositoryException {
        NodeIterator nodeIterator = list.getNodes();

        ArrayList<String> genericList = new ArrayList<>();
        while( nodeIterator.hasNext() ) {
            Node item = nodeIterator.nextNode();
            String title = "";
            String value = "";
            if( item.hasProperty("jcr:title") ){
                title = item.getProperty("jcr:title").getString();
            }
            if( item.hasProperty("value") ) {
                value = item.getProperty("value").getString();
            }
            String str = "{\"title\":\"" + title + "\",\"value\":\"" + value + "\"}";
            genericList.add( str );
        }
        return genericList.toArray( new String[0] );
    }

    private Node createFolder( Node parent, String name, String title) throws RepositoryException {
        if( parent != null && !parent.hasNode(name) ) {
            Node folder =  parent.addNode(name, "sling:OrderedFolder");
            folder.setProperty(JcrConstants.JCR_TITLE, title);
        }
        return  parent.getNode( name );
    }
}
