package com.tgfoundation.core.scripts;

import com.adobe.cq.dam.cfm.*;
import com.day.cq.commons.jcr.JcrConstants;
import com.tgfoundation.core.models.GenericListItem;
import com.tgfoundation.core.models.StyleShortcut;
import com.tgfoundation.core.models.StyleShortcutGroup;
import com.tgfoundation.core.models.StyleSystem;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.PersistenceException;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.apache.sling.servlets.annotations.SlingServletPaths;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.Marker;

import javax.jcr.*;
import javax.servlet.Servlet;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

@Component(service = { Servlet.class })
@SlingServletPaths("/bin/foundation/migrate/sites")
public class ContentMappingMigration extends SlingAllMethodsServlet {
    private static Logger log = LoggerFactory.getLogger(ContentMappingMigration.class);
    private static Marker marker;

    @Reference
    ContentFragmentManager contentFragmentManager;

    @Override
    protected void doGet( SlingHttpServletRequest request, SlingHttpServletResponse response ) throws IOException {
        try {
            ResourceResolver resolver = request.getResourceResolver();
            String path = request.getParameter("path");

            if( path == null || path.isEmpty() ) {
                response.setStatus(SlingHttpServletResponse.SC_BAD_REQUEST);
                response.getWriter().write("Parameter 'path' is required.");
                return;
            }

            Resource pageResource = resolver.getResource( path );

            if( pageResource == null ) {
                response.setStatus(SlingHttpServletResponse.SC_BAD_REQUEST);
                response.getWriter().write("Please ensure that path exists");
                return;
            }

            Node pageNode = pageResource.adaptTo( Node.class );

            if( pageNode == null ) return;

            PrintWriter writer = response.getWriter();

            migrateNodeData( pageNode, resolver, writer );

            migrateStyles( pageNode, resolver );

            resolver.commit();

        }
        catch (RepositoryException e) {
            throw new RuntimeException(e);
        }
    }

    private void migrateStyles( Node current, ResourceResolver resolver ) throws RepositoryException {
        if( current.hasProperty("cq:cssClass" ) ) {
            updateStyleSystem( current, resolver );
        }

        NodeIterator nodeIterator = current.getNodes();
        while (nodeIterator.hasNext()) {
            migrateStyles(nodeIterator.nextNode(), resolver);
        }
    }

    private void migrateNodeData( Node current, ResourceResolver resolver, PrintWriter writer ) throws RepositoryException, PersistenceException {
        PropertyIterator propertyIterator = current.getProperties();

        if( "cq:responsive".equals( current.getName() ) || "nextPage".equals( current.getName() ) || "main.css".equals( current.getName() ) ) {
            current.remove();
            return;
        }

        if( current.getPrimaryNodeType().isNodeType( "cq:Page") && current.getPath().contains("experience-fragments") ) {
            if( !current.hasNode("jcr:content" ) ) {
                addExperienceFragmentContent( current );
            }
        }

        while ( propertyIterator.hasNext() ) {
            Property property = propertyIterator.nextProperty();

            switch ( property.getName() ) {
                case "brandingStylesheet":
                    updateBrandingStylesheet( property );
                    continue;
                case "clearSessionBeforePrefill":
                    updateSessionBeforePrefill( current );
                    continue;
                case "featureClearSession":
                    updateClearSession( current );
                    continue;
                case "featurePurchasePath":
                case "hasStylesheet":
                case "javaRedirect":
                case "stylesheetVersion":
                case "layout":
                case "tripDepDateSelect":
                case "tripRtnDateSelect":
                case "serviceType":
                    property.remove();
                    continue;
                case "source":
                    if( "genericList".equals( property.getString() ) || "datasource".equals( property.getString() ) ) {
                        Property property1 = current.getProperty("genericListLT");

                        if( property1 != null ) {
                            Value v = property1.getValue();

                            if( v != null ) {
                                String list = v.getString();

                                if( list != null ) {
                                    current.setProperty("datasourceRT", "/bin/foundation/generic-list/datasource");
                                    list = list.replace("/etc/acs-commons/lists", "/content/dam/generic-list/ams-list");

                                    current.setProperty("datasourcePath", list);
                                }
                            }
                        }
                        writer.write(current.getPath() + "\n\t" + " Datasource Needs to be Updated\n\t" + property.getValue() + "\n\n");
                    }
                    continue;
                case "cq:template":
                    updateCqTemplate( property, current );
                    continue;
                case "sling:resourceType":
                    updateResourceType( property, current, writer );
                    continue;
                case "fragmentPath":
                    updateFragmentPath( current );
                    continue;
                case "cq:styleIds":
                    writer.write(current.getPath() + "\n\t" + "style selections need attention\n\n");
                    continue;
                case "displayCondition":
                    writer.write(current.getPath() + "\n\t" + "Show Hide Functionality needs re-authoring\n\n");
                    continue;
                case "retrieveQuoteURLRedirectMapping":
                    writer.write(current.getPath() + "\n\t" + "retrieveQuoteURLRedirectMapping need re-authoring\n\n");
                    continue;
                case "valuesToSaveFromSessionStorage":
                    writer.write(current.getPath() + "\n\t" + "valuesToSaveFromSessionStorage need re-authoring\n\n");
                    continue;
                case "claimQuesToSTPCodes":
                    writer.write(current.getPath() + "\n\t" + "claimQuesToSTPCodes need re-authoring\n\n");
                    continue;
                case "clearFieldNamesOnClaimReason":
                    writer.write(current.getPath() + "\n\t" + "clearFieldNamesOnClaimReason need re-authoring\n\n");
                    continue;
                case "clearFieldNamesOnClaimType":
                    writer.write(current.getPath() + "\n\t" + "clearFieldNamesOnClaimType need re-authoring\n\n");
                    continue;
                case "formTypeMappingList":
                    writer.write(current.getPath() + "\n\t" + "formTypeMappingList need re-authoring\n\n");
                    continue;
                case "numberOfDuplicates":
                    writer.write(current.getPath() + "\n\t" + "Repeatable component need re-authoring\n\n");
                    continue;
            }
            resolver.commit();
        }

        NodeIterator nodeIterator = current.getNodes();
        while (nodeIterator.hasNext()) {
            migrateNodeData(nodeIterator.nextNode(), resolver, writer );
        }
    }

    private void addExperienceFragmentContent( Node node ) throws RepositoryException {
        Node content = node.addNode("jcr:content", "cq:PageContent" );
        content.setProperty("sling:resourceType", "cq/experience-fragments/components/experiencefragment" );
        content.setProperty("cq:template", "/libs/cq/experience-fragments/components/experiencefragment/template");
    }

    private void updateClearSession( Node node ) throws RepositoryException {
        Property property = node.getProperty("featureClearSession");

        if( property == null ) return;

        if( "true".equals( property.getString() ) ) {
            node.setProperty( "featureClearSession", "Enabled" );
            node.setProperty( "clearTime", "5000" );
        }
        else {
            node.setProperty( "featureClearSession", "Disabled" );
        }
    }

    private void updateSessionBeforePrefill( Node node ) throws RepositoryException {
        Property property = node.getProperty("clearSessionBeforePrefill");

        if( property == null ) return;

        if( "true".equals( property.getString() ) ) {
            node.setProperty( "featureClearSession", "Enabled" );
        }
        else {
            node.setProperty( "featureClearSession", "Disabled" );
        }
    }

    private void updateFragmentPath( Node node ) throws RepositoryException {
        Property fragmentPath = node.getProperty( "fragmentPath" );

        node.setProperty("fragmentVariationPath", fragmentPath.getString() );
        fragmentPath.remove();
    }

    private void updateStyleSystem( Node node, ResourceResolver resolver ) throws RepositoryException {
        Resource resource = resolver.getResource( node.getPath() );

        if( resource == null ) return;

        StyleSystem styleSystem = resource.adaptTo( StyleSystem.class );

        if( styleSystem == null ) return;

        List<String> appliedShortcuts = styleSystem.getSelectedShortcuts();
        List<StyleShortcutGroup> styleShortcutGroups = styleSystem.getShortcutGroups();
        StringBuilder shortcutString = new StringBuilder();

        for( StyleShortcutGroup group : styleShortcutGroups ) {
            List<StyleShortcut> shortcuts = group.getStyles();

            for( StyleShortcut shortcut : shortcuts ) {
                GenericListItem item = shortcut.getShortcut();
                if( appliedShortcuts.contains( item.getTitle() ) ) {
                    shortcutString.append( shortcut.getShortcut().getValue() ).append( " " );
                }
            }
        }

        String id = styleSystem.getComponentId();

        if( id != null && node.hasProperty(id) ) {
            Property property = node.getProperty( id );
            node.setProperty("buildingBlocks", property.getString() );
            property.remove();
        }

        node.setProperty( "shortcutStyles", shortcutString.toString().trim() );
    }

    private void updateResourceType( Property property, Node node, PrintWriter writer ) throws RepositoryException {
        String name = property.getString();

        switch ( name ) {
            case "wcm/foundation/components/responsivegrid":
            case "tg-common/components/core/container/v1/container":
                property.setValue( "tgfoundation/components/core/container" );
                return;
            case "tg-common/components/core/button/v1/button":
                property.setValue( "tgfoundation/components/core/button" );
                return;
            case "tg-common/components/core/image/v2/image":
                property.setValue( "tgfoundation/components/core/image" );
                return;
            case "tg-common/components/core/experiencefragment/v1/experiencefragment":
                property.setValue( "tgfoundation/components/core/experiencefragment" );
                return;
            case "tg-common/components/custom/form/container/v2/container":
                property.setValue("tgfoundation/components/core/form/container");
                writer.write(node.getPath() + "\n\t" + "Form Dialog need attention\n\n");
                return;
            case "tg-common/components/core/form/button/v2/button":
                property.setValue("tgfoundation/components/core/form/button");
                return;
            case "tg-common/components/core/form/hidden/v2/hidden":
                property.setValue("tgfoundation/components/core/form/hidden");
                return;
            case "tg-direct/components/core/text/v2/text":
                property.setValue("tgfoundation/components/core/text");
                return;
            case "tg-common/components/core/form/text/v2/text":
                property.setValue("tgfoundation/components/core/form/text");
                return;
            case "tg-common/components/core/form/options/v2/options":
                property.setValue("tgfoundation/components/core/form/options");
                return;
            case "tg-common/components/structure/page":
                if( node.getPath().contains("experience-fragments") ) {
                    property.setValue("tgfoundation/components/core/xfpage");
                    node.setProperty("cq:xfVariantType", "web");
                }
                else {
                    property.setValue("tgfoundation/components/core/page");
                }
                return;
            case "tg-common/components/structure/xfpage":
                property.setValue("tgfoundation/components/core/xfpage");
                node.setProperty("cq:xfVariantType", "web");
                return;
            case "tg-common/components/custom/utilityprimarynav/utilityprimarynav":
                writer.write(node.getPath() + "\n\t" + "Header Images may need attention\n\n");
                property.setValue("tgfoundation/components/custom/utilityprimarynav/utilityprimarynav");
                return;
            case "tg-common/components/custom/modal/modalpopup":
                property.setValue("tgfoundation/components/custom/modal/modalpopup");
                return;
            case "tg-common/components/core/title/v2/title":
                property.setValue("tgfoundation/components/core/title");
                return;
            case "tg-common/components/custom/progressBarDropdown/v1/progressBarDropdown":
                property.setValue("tgfoundation/components/custom/progressBarDropdown/v1/progressBarDropdown");
                return;
            case "tg-common/components/custom/personalization/java-personalization":
                property.setValue("tgfoundation/components/custom/personalization");
        }
    }

    private void updateCqTemplate( Property property, Node node ) throws RepositoryException {
        Value v = property.getValue();

        if( v == null ) return;

        String name = v.getString();

        if( !name.startsWith("/libs") ) {
            if ( node.getPath().contains("experience-fragment")) {
                property.setValue("/conf/tgfoundation/settings/wcm/templates/xf-web-variation");
            } else {
                property.setValue("/conf/tgfoundation/settings/wcm/templates/page-content");
            }
        }
    }

    private void updateBrandingStylesheet( Property property ) throws RepositoryException {
        Value value = property.getValue();

        if( value == null ) return;

        String valueString = value.getString();

        if( valueString == null ) return;

        String[] splitValue = valueString.split(",");
        StringBuilder stringBuilder = new StringBuilder();

        for( String str : splitValue ) {
            switch ( str ) {
                case "agents-travelguard-branding-clientlib":
                    stringBuilder.append( "tgfoundation.clientlib.travelguard.agents.branding" ).append(",");
                    continue;
                case "fnol-branding-clientlib":
                    stringBuilder.append( "tgfoundation.clientlib.fnol.branding" ).append(",");
                    continue;
                case "qantas-branding-clientlib":
                    stringBuilder.append( "tgfoundation.clientlib.qantas.branding" ).append(",");
                    continue;
                case "qantas-fnol-branding-clientlib":
                    stringBuilder.append( "tgfoundation.clientlib.qantas.fnol.branding" ).append(",");
                    continue;
                case "travelguard-branding-clientlib":
                    stringBuilder.append( "tgfoundation.clientlib.travelguard.branding" ).append(",");
                    continue;
                default:
                    stringBuilder.append( str ).append(",");
            }
        }

        String newVal = stringBuilder.toString();
        newVal = newVal.substring( 0, newVal.length() - 1 );

        property.setValue( newVal );
    }
}
