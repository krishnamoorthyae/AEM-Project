package com.tgfoundation.core.scripts;

import com.adobe.cq.dam.cfm.ContentFragmentManager;
import com.day.cq.commons.jcr.JcrConstants;
import com.day.cq.dam.api.DamConstants;
import com.day.cq.search.PredicateGroup;
import com.day.cq.search.Query;
import com.day.cq.search.QueryBuilder;
import com.day.cq.search.result.Hit;
import com.day.cq.search.result.SearchResult;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.apache.sling.servlets.annotations.SlingServletPaths;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.Marker;

import javax.jcr.*;
import javax.servlet.Servlet;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Component(service = { Servlet.class })
@SlingServletPaths("/bin/foundation/fragment/duplication")
public class ExperienceFragmentDuplication extends SlingAllMethodsServlet {
    private static Logger log = LoggerFactory.getLogger(ExperienceFragmentDuplication.class);
    private static Marker marker;

    private static HashMap<String, String> languageMap = new HashMap<>();

    @Override
    protected void doGet( SlingHttpServletRequest request, SlingHttpServletResponse response ) throws IOException {
        ResourceResolver resolver = request.getResourceResolver();
        PrintWriter writer = response.getWriter();

        String source = request.getParameter("source");

        if( source == null || source.isEmpty() ) {
            writer.write("Please Provide a Source Folder");
            return;
        }

        String name = request.getParameter("name");

        if( name == null || name.isEmpty() ) {
            writer.write("Please Provide a name for target Folder");
            return;
        }

        String title = request.getParameter("title");

        if( title == null || title.isEmpty() ) {
            writer.write("Please Provide a title for target Folder");
            return;
        }

        String languagees = request.getParameter("languages");

        if( languagees == null || languagees.isEmpty() ) {
            writer.write("Please Provide languages for variations");
            return;
        }

        languageMap.put("ar", "Arabic");
        languageMap.put("cs", "Czech");
        languageMap.put("da", "Danish");
        languageMap.put("de", "German");
        languageMap.put("el", "Greek");
        languageMap.put("en", "English");
        languageMap.put("es", "Spanish");
        languageMap.put("fi", "Finnish");
        languageMap.put("fr", "French");
        languageMap.put("hu", "Hungarian");
        languageMap.put("id", "Indonesian");
        languageMap.put("it", "Italian");
        languageMap.put("ja", "Japanese");
        languageMap.put("lv", "Latvian");
        languageMap.put("ms", "Malay");
        languageMap.put("nb", "Norwegian Bokmål");
        languageMap.put("nl", "Dutch");
        languageMap.put("pl", "Polish");
        languageMap.put("pt", "Portuguese");
        languageMap.put("ro", "Romanian");
        languageMap.put("sv", "Swedish");
        languageMap.put("th", "Thai");
        languageMap.put("tr", "Turkish");
        languageMap.put("vi", "Vietnamese");
        languageMap.put("zh", "Chinese");

        Resource sourceResource = resolver.getResource( source );
        if( sourceResource == null ) {
            writer.write("Found no resource at the provided source path");
            return;
        }

        Resource parent = sourceResource.getParent();

        Node sourceNode = sourceResource.adaptTo( Node.class );
        Node targetNode = parent.adaptTo( Node.class );
        Session session = resolver.adaptTo( Session.class );

        try {
            initialCopy( session, sourceNode, targetNode, name, title, languagees );

            session.save();
        } catch (RepositoryException e) {
            writer.write("Something went wrong when attempting to save the changes");
            throw new RuntimeException(e);
        }
    }

    private void initialCopy( Session session, Node source, Node target, String name, String title, String languages ) throws RepositoryException {
        Node newNode = null;

        if( !target.hasNode( name ) ) {
            newNode = target.addNode( name, source.getPrimaryNodeType().getName() );

            PropertyIterator propertyIterator = source.getProperties();
            while(propertyIterator.hasNext()) {
                Property property = propertyIterator.nextProperty();

                if( !property.getDefinition().isProtected() ) {
                    if( property.getDefinition().isMultiple() ) {
                        newNode.setProperty( property.getName(), property.getValues() );
                    }
                    else {
                        newNode.setProperty( property.getName(), property.getValue() );
                    }
                }
            }

            newNode.setProperty(JcrConstants.JCR_TITLE, title );
        }
        else {
            newNode = target.getNode( name );
        }

        NodeIterator nodeIterator = source.getNodes();
        while ( nodeIterator.hasNext() ) {
            Node child = nodeIterator.nextNode();

            copyNode( session, child, newNode, languages );
        }
    }

    private void copyNode( Session session, Node source, Node target, String languages ) throws RepositoryException {
        Node newNode = null;
        String name = source.getName();
        String parentName = target.getName();

        if( !target.hasNode( name ) ) {
            if( name.length() == 2 && "en".equals( name ) ) {
                addLanguageVariations( session, source, target, languages );
            }

            if( name.length() != 2 || "en".equals( name ) ) {
                newNode = target.addNode( name, source.getPrimaryNodeType().getName() );

                PropertyIterator propertyIterator = source.getProperties();
                while(propertyIterator.hasNext()) {
                    Property property = propertyIterator.nextProperty();

                    if( !property.getDefinition().isProtected() ) {
                        if( property.getDefinition().isMultiple() ) {
                            newNode.setProperty( property.getName(), property.getValues() );
                        }
                        else {
                            newNode.setProperty( property.getName(), property.getValue() );
                        }
                    }
                }

                if( JcrConstants.JCR_CONTENT.equals( newNode.getName() ) && parentName.length() == 2 ) {
                    newNode.setProperty( JcrConstants.JCR_TITLE, languageMap.get( parentName ));
                }
            }
        }
        else {
            newNode = target.getNode( name );
        }

        NodeIterator nodeIterator = source.getNodes();
        while ( nodeIterator.hasNext() ) {
            Node child = nodeIterator.nextNode();

            if( newNode != null ) {
                copyNode( session, child, newNode, languages );
            }
        }
    }

    private void addLanguageVariations( Session session, Node source, Node target, String languages ) throws RepositoryException {
        for( String language : languages.split(",") ) {
            Node newNode = null;

            if( languageMap.get( language ) != null ) {
                if( !target.hasNode( language ) ) {
                    newNode = target.addNode( language, source.getPrimaryNodeType().getName() );

                    PropertyIterator propertyIterator = source.getProperties();
                    while(propertyIterator.hasNext()) {
                        Property property = propertyIterator.nextProperty();

                        if( !property.getDefinition().isProtected() ) {
                            if( property.getDefinition().isMultiple() ) {
                                newNode.setProperty( property.getName(), property.getValues() );
                            }
                            else {
                                newNode.setProperty( property.getName(), property.getValue() );
                            }
                        }
                    }
                }
                else {
                    newNode = target.getNode( language );
                }

                NodeIterator nodeIterator = source.getNodes();
                while ( nodeIterator.hasNext() ) {
                    Node child = nodeIterator.nextNode();

                    copyNode( session, child, newNode, languages );
                }
            }
        }
    }
}
