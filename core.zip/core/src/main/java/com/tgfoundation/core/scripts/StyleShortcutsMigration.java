package com.tgfoundation.core.scripts;

import com.adobe.cq.dam.cfm.*;
import com.day.cq.commons.jcr.JcrConstants;
import com.day.cq.tagging.Tag;
import com.day.cq.tagging.TagManager;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.PersistenceException;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.apache.sling.jcr.resource.api.JcrResourceConstants;
import org.apache.sling.servlets.annotations.SlingServletPaths;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.Marker;

import javax.jcr.Node;
import javax.jcr.NodeIterator;
import javax.jcr.RepositoryException;
import javax.jcr.Session;
import javax.servlet.Servlet;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

import static com.day.cq.tagging.TagConstants.NT_TAG;

@Component(service = { Servlet.class })
@SlingServletPaths("/bin/foundation/migrate/style/shortcuts")
public class StyleShortcutsMigration extends SlingAllMethodsServlet {
    private static Logger log = LoggerFactory.getLogger(StyleShortcutsMigration.class);
    private static Marker marker;

    @Reference
    ContentFragmentManager contentFragmentManager;

    @Override
    protected void doGet( SlingHttpServletRequest request, SlingHttpServletResponse response ) throws IOException {
        ResourceResolver resolver = request.getResourceResolver();

        HashMap<String, String> paths = new HashMap();
        paths.put("/conf/tg-direct/settings/wcm/policies/tg-common/components/core/form/text/v2/text/policy_1646082089696/shortcuts", "/core/form/text");
        paths.put("/conf/tg-direct/settings/wcm/policies/tg-common/components/core/form/button/v2/button/policy_1646080193649/shortcuts", "/core/form/button");
        paths.put("/conf/tg-direct/settings/wcm/policies/tg-common/components/core/form/options/v2/options/policy_1646082314232/shortcuts", "/core/form/options");
        paths.put("/conf/tg-direct/settings/wcm/policies/tg-common/components/core/container/v1/container/policy_1646081521736/shortcuts", "/core/container");
        paths.put("/conf/tg-direct/settings/wcm/policies/tg-common/components/core/image/v2/image/policy_1646082828760/shortcuts", "/core/image");
        paths.put("/conf/tg-direct/settings/wcm/policies/tg-common/components/core/title/v2/title/policy_1646083352495/shortcuts", "/core/title");
        paths.put("/conf/tg-direct/settings/wcm/policies/tg-common/components/core/button/v1/button/policy_1646080445033/shortcuts", "/core/button");
        paths.put("/conf/tg-direct/settings/wcm/policies/tg-common/components/core/separator/v1/separator/policy_1646082959709/shortcuts", "/core/separator");
        paths.put("/conf/tg-direct/settings/wcm/policies/tg-common/components/core/breadcrumb/v2/breadcrumb/policy_1646080760021/shortcuts", "/core/breadcrumb");
        paths.put("/conf/tg-direct/settings/wcm/policies/tg-common/components/core/accordion/v1/accordion/policy_1646079883801/shortcuts", "/core/accordion");
        paths.put("/conf/tg-direct/settings/wcm/policies/tg-common/components/core/experiencefragment/v1/experiencefragment/policy_1646083758130/shortcuts", "/core/experiencefragment");
        paths.put("/conf/tg-direct/settings/wcm/policies/tg-common/components/core/list/v2/list/policy_8537264597671951/shortcuts", "/core/list");
        paths.put("/conf/tg-direct/settings/wcm/policies/tg-common/components/custom/token/Tokenize/policy_1648589842807/shortcuts", "/custom/tokenize");
        paths.put("/conf/tg-direct/settings/wcm/policies/tg-common/components/custom/product-display/v1/product-display/policy_1657719227483/shortcuts", "/custom/productdisplay");
        paths.put("/conf/tg-direct/settings/wcm/policies/tg-common/components/custom/modal/modalpopup/policy_1658341443399/shortcuts", "/custom/modal/modalpopup");
        paths.put("/conf/tg-direct/settings/wcm/policies/tg-common/components/custom/back-to-top-Button/back-to-top/policy_1072453725426060/shortcuts", "/custom/back-to-top-/back-to-top/");
        paths.put("/conf/tg-direct/settings/wcm/policies/tg-direct/components/core/text/v2/text/policy_1646083178584/shortcuts", "/core/text");

        try {
            Resource styleResource = resolver.getResource( "/content/dam/config/style-system" );

            if( styleResource == null ) return;

            for( String key : paths.keySet() ) {
                String destination = paths.get( key );
                String[] splitDestination = destination.split("/");

                Node contentNode = styleResource.adaptTo( Node.class );

                for( String str: splitDestination ) {
                    if( !str.isEmpty() ) {
                        contentNode = createFolder( contentNode, str, str );
                    }
                }

                createContentFragments( resolver.getResource( key ).adaptTo(Node.class), resolver, contentNode, destination.substring(1)  );
            }

            resolver.commit();
        } catch (RepositoryException e) {
            throw new RuntimeException(e);
        }
    }

    public void createContentFragments(Node listNode, ResourceResolver resolver, Node contentNode, String destination) throws RepositoryException, PersistenceException {
        String tempaltePath = "/conf/tgfoundation/settings/dam/cfm/models/generic-list";

        if( listNode == null ) return;

        NodeIterator nodeIterator = listNode.getNodes();
        while ( nodeIterator.hasNext() ) {
            Node groupNode = nodeIterator.nextNode();

            Node groupFolder = createFolder(contentNode, groupNode.getName().toLowerCase().replace(" ", "-"), groupNode.getName());

            NodeIterator groupItr = groupNode.getNodes();
            while (groupItr.hasNext()) {
                Node shortcut = groupItr.nextNode();

                createShortcut( groupFolder, resolver, shortcut, destination);
            }
        }
    }

    private Node createFolder( Node parent, String name, String title) throws RepositoryException {
        if( parent != null && !parent.hasNode(name) ) {
            Node folder =  parent.addNode(name, "sling:OrderedFolder");
            folder.setProperty(JcrConstants.JCR_TITLE, title);
        }
        return  parent.getNode( name );
    }

    private void createShortcut( Node parent, ResourceResolver resolver, Node shortcut, String destination) throws RepositoryException {
        String fragmentName = shortcut.getName();
        String tempaltePath = "/conf/tgfoundation/settings/dam/cfm/models/generic-list";

        Resource fragmentParent = resolver.getResource(parent.getPath());
        Resource templateResource = resolver.getResource(tempaltePath);
        FragmentTemplate fragmentTemplate = templateResource.adaptTo(FragmentTemplate.class);

        try {
            ContentFragment contentFragment = fragmentTemplate.createFragment(fragmentParent, fragmentName, fragmentName);
            ContentElement contentElement = contentFragment.getElement("genericListCMF");
            FragmentData data = contentElement.getValue();
            data.setValue(getGenericListAsContentFragment(shortcut));
            contentElement.setValue(data);

            resolver.commit();

            Node contentNode = resolver.getResource(fragmentParent.getPath() + "/" + fragmentName).adaptTo(Node.class);

            String tagParent = "";
            String[] destinationSplit = destination.split("/");
            for( int i = 0; i < destinationSplit.length - 1; i++ ) {
                tagParent += ("/" + destinationSplit[i]);
            }

            tagParent = tagParent.substring( 1 );
            String tagName = destinationSplit[ destinationSplit.length - 1];

            String tag = createContentTag(tagName, tagName, tagParent, resolver.adaptTo( Session.class ));

            contentNode = contentNode.getNode( "jcr:content/metadata" );
            contentNode.setProperty("cq:tags", new String[]{ tag } );

            resolver.commit();
        } catch (ContentFragmentException | IOException e) {
            throw new RuntimeException(e);
        }
    }

    private String[] getGenericListAsContentFragment( Node shortcut ) throws RepositoryException {
        ArrayList<String> genericList = new ArrayList<>();

        String title = "";
        String value = "";
        if( shortcut.hasProperty("styleId") ){
            title = shortcut.getProperty("styleId").getString();
        }
        if( shortcut.hasProperty("cssStyles") ) {
            value = shortcut.getProperty("cssStyles").getString();
        }
        String str = "{\"title\":\"" + title + "\",\"value\":\"" + value + "\"}";
        genericList.add( str );

        return genericList.toArray( new String[0] );
    }

    String createContentTag(String name, String title, String location, Session session) throws IOException, RepositoryException {
        name = name.trim();
        title = title.trim();
        Node tags = session.getNode("/content/cq:tags");
        Node contentTags, shortcutFolder, tagFolder;

        if(tags.hasNode("style-system")) {
            contentTags = tags.getNode("style-system");
        }
        else {
            contentTags = tags.addNode("style-system", NT_TAG);
            contentTags.setProperty(JcrResourceConstants.SLING_RESOURCE_TYPE_PROPERTY, "cq/tagging/components/tag");
            contentTags.setProperty(JcrConstants.JCR_TITLE, "Style System");
            contentTags.setProperty(JcrConstants.JCR_DESCRIPTION, "Tags for Style System");
        }

        tagFolder = contentTags;
        for( String indLoc : location.split("/" ) ) {
            if(tagFolder.hasNode(indLoc)) {
                tagFolder = tagFolder.getNode(indLoc);
            }
            else {
                tagFolder = tagFolder.addNode(indLoc, NT_TAG);
                tagFolder.setProperty(JcrResourceConstants.SLING_RESOURCE_TYPE_PROPERTY, "cq/tagging/components/tag");
                tagFolder.setProperty(JcrConstants.JCR_TITLE, indLoc);
                tagFolder.setProperty(JcrConstants.JCR_DESCRIPTION, "Tags for Style Shortcut");
            }
        }

        Node tag;
        if(tagFolder.hasNode(name)) {
            tag = tagFolder.getNode( name.trim() );
        }
        else {
            tag = tagFolder.addNode(name, NT_TAG);
            tag.setProperty(JcrConstants.JCR_TITLE, title.trim());
        }

        session.save();

        return tag.getPath();
    }
}
