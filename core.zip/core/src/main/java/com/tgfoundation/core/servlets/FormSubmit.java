package com.tgfoundation.core.servlets;

import com.day.cq.commons.inherit.HierarchyNodeInheritanceValueMap;
import com.day.cq.commons.inherit.InheritanceValueMap;
import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.PageManager;
import com.tgfoundation.core.utils.session.SessionStorage;
import org.apache.http.HttpHeaders;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.*;
import org.apache.sling.api.servlets.HttpConstants;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.apache.sling.servlets.annotations.SlingServletPaths;
import org.osgi.framework.Constants;
import org.osgi.service.cm.ConfigurationAdmin;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.Marker;
import javax.jcr.RepositoryException;
import javax.servlet.Servlet;
import java.io.*;
import java.util.*;

@Component(
    service= Servlet.class,
    property={
        Constants.SERVICE_DESCRIPTION + "=Java Form Submit Handler",
        "sling.servlet.methods=" + HttpConstants.METHOD_POST
    })
@SlingServletPaths("/bin/foundation/form-submit")
public class FormSubmit extends SlingAllMethodsServlet {
    private final long serialVersionUID = 1L;

    private transient Logger log = LoggerFactory.getLogger(FormSubmit.class);

    private Marker marker;

    @Reference
    private transient ConfigurationAdmin configAdmin;

    @Reference
    transient ResourceResolverFactory resolverFactory;

    @Override
    protected void doPost(SlingHttpServletRequest request, SlingHttpServletResponse response) {
        try {
            response.setHeader("Dispatcher", "no-cache");
            doCall( request, response );
        }
        catch (RepositoryException e) {
            log.error(marker, "Form Submit Repository Exception Error : {}", e.getMessage());
            response.setStatus(500);
        }
        catch (IOException e) {
            log.error(marker, "Form Submit IO Exception Error : {}", e.getMessage());
            response.setStatus(500);
        }
    }

    private void doCall(SlingHttpServletRequest request, SlingHttpServletResponse response) throws RepositoryException, IOException {
        log.info(marker, "Starting doCall() function" );

        ResourceResolver resourceResolver = request.getResourceResolver();
        Resource resource = Objects.requireNonNull( getFormResource( request, resourceResolver ) );
        //getting the calling page for page property information
        Page page = getRequestPage(resourceResolver, resource);
        log.info(marker, "Got the Page" );

        String nextPage = resource.getValueMap().get("nextPagePath", String.class);
        SessionStorage sessionStorage = new SessionStorage();
        //update the following function 
        saveValuesToSessionStorage( resourceResolver, sessionStorage, request, page, resource);
        log.info(marker, "Finished Saving to Session Storage" );

        if( nextPage != null ) {
            redirectPage(nextPage, sessionStorage, request, response);
        }
    }

    private Resource getFormResource( SlingHttpServletRequest request, ResourceResolver resourceResolver ) {
        //setting the resource for future use
        String formPath = request.getParameter( ":form-path");
        return resourceResolver.getResource( formPath );
    }

    private void redirectPage(String redirectPath, SessionStorage sessionStorage, SlingHttpServletRequest request, SlingHttpServletResponse response) throws RepositoryException, IOException {
        
        if( !redirectPath.endsWith(".html") ) {
            redirectPath += ".html";
        }

        //getting the shortened url
        String absoluteURL = request.getResourceResolver().map( redirectPath ).trim();
        log.info( "absolute url is " + absoluteURL );

        if( absoluteURL.contains("selectors=") ) {
            absoluteURL = "";
        }

        if( absoluteURL.startsWith("https:") ) {
            log.info( "absolute url if statement entered" );
            int ordinalIdx = ordinalIndexOf( absoluteURL, "/", 2);
            log.info( "Ordinal index is " + ordinalIdx );
            redirectPath = absoluteURL.substring( ordinalIdx );
            log.info( "absolute url => redirect path is " + redirectPath );
        }

        response.setStatus(200);

        //at this point we have https://travel.insurance.qantas.com/https://qantas.qa.travelguard.com/buy/login
        log.info( "redirect path is " + redirectPath );
        response.sendRedirect( redirectPath );
    }

    public static int ordinalIndexOf(String str, String substr, int n) {
        int pos = -1;
        do {
            pos = str.indexOf(substr, pos + 1);
        } while (n-- > 0 && pos != -1);
        return pos;
    }

    public static Page getRequestPage(ResourceResolver resourceResolver,Resource resource){
        PageManager pageManager = resourceResolver.adaptTo(PageManager.class);
        return pageManager.getContainingPage(resource); 
    }

    public void saveValuesToSessionStorage( ResourceResolver resourceResolver, SessionStorage sessionStorage, SlingHttpServletRequest request,Page page, Resource resource) throws RepositoryException{
         //saving each request parameter to the session
         Map parameterMap = request.getParameterMap();
         Set<String> keySet = parameterMap.keySet();
         String[] pageInputs = new String[ parameterMap.size() ];
         boolean saveValue = true;
         //moving outside the for loop to prevent resource resolver closed
         InheritanceValueMap ivm = new HierarchyNodeInheritanceValueMap(page.getContentResource());
 
         if( sessionStorage.getItem(request, page.getPath()) != null ) {
             Object sessionItem = sessionStorage.getItem(request, page.getPath());
             List<?> pageValues = new ArrayList<>();
             if( sessionItem != null ) {
                 if( sessionItem.getClass().equals(ArrayList.class) ) {
                     pageValues = (ArrayList) sessionItem;
                 }
                 else {
                     pageValues = Arrays.asList((Object[]) sessionItem);
                 }
             }
             for( int i = 0; i < pageValues.size(); i++ ) {
                 sessionStorage.removeItem(request, pageValues.get(i).toString() );
             }
             sessionStorage.removeItem( request, page.getPath() );
         }
         int idx = 0;
         for( String key : keySet ) {
             String[] temp = (String[]) parameterMap.get( key );
             String[] values = null;
 
             //saving value in session storage
             if( saveValue ) {
                 if( key.equalsIgnoreCase(":form-path") ) {
                     values = temp;
                 }
                 else {
                     List<String> parameterList = Arrays.asList( temp );
                     Object sessionItem = sessionStorage.getItem(request, key);
                     List<?> sessionList = new ArrayList<>();
                     if( sessionItem != null ) {
                         if( sessionItem.getClass().equals(ArrayList.class) ) {
                             sessionList = (ArrayList) sessionItem;
                         }
                         else if ( sessionItem.getClass().equals( String.class ) ){
                             sessionList = Arrays.asList((String) sessionItem);
                         }
                         else {
                             sessionList = Arrays.asList((Object[]) sessionItem);
                         }
                     }
 
                     List<String> newList = new ArrayList<>();
                     for( int i = 0; i < sessionList.size(); i++ ) {
                         newList.add( sessionList.get(i).toString() );
                     }
                     for( int i = 0; i < parameterList.size(); i++ ) {
                         newList.add( parameterList.get(i).toString() );
                     }
                     values = newList.toArray(new String[0]);
                 }
                 sessionStorage.setItem(request, key, values);
             }
             pageInputs[ idx++ ] = key;
         }
         sessionStorage.setItem( request, page.getPath(), pageInputs);
    }

    @Override
    protected void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response) {
        log.info("in get call");
    }

}

