package com.tgfoundation.core.servlets;

import com.day.cq.commons.jcr.JcrConstants;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.apache.sling.servlets.annotations.SlingServletPaths;
import org.osgi.service.component.annotations.Component;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.Marker;
import javax.servlet.Servlet;
import java.io.IOException;
import java.util.Arrays;

@Component(service = { Servlet.class })
@SlingServletPaths("/bin/foundation/generic-list")
public class GenericList extends SlingAllMethodsServlet {
    private static Logger log = LoggerFactory.getLogger(GenericList.class);
    private static Marker marker;

    @Override
    protected void doGet( SlingHttpServletRequest request, SlingHttpServletResponse response ) throws IOException {
        String listPath = request.getParameter("list");

        if( listPath == null || listPath.isEmpty() ) {
            response.setStatus(SlingHttpServletResponse.SC_BAD_REQUEST);
            response.getWriter().write("Parameter 'list' is required.");
            log.debug("Found no generic list path");
            return;
        }

        ResourceResolver resourceResolver = request.getResourceResolver();
        Resource resource = resourceResolver.getResource( listPath + "/jcr:content/data/master" );

        if( resource == null ) {
            response.setStatus(SlingHttpServletResponse.SC_NOT_FOUND);
            response.getWriter().write("Resource not found at the provided path.");
            log.debug("Found no resource in path {}", listPath);
            return;
        }

        ValueMap valueMap = resource.getValueMap();
        String[] listItems = valueMap.get("genericListCMF", String[].class);

        if( listItems == null ) {
            response.setStatus(SlingHttpServletResponse.SC_NOT_FOUND);
            response.getWriter().write("This is not a valid generic list content fragment");
            log.debug("Found invalid resource in path {}", listPath);
            return;
        }

        response.setContentType("application/json");
        response.getWriter().write( Arrays.toString( listItems ));
    }
}
