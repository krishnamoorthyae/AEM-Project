package com.tgfoundation.core.servlets;

import com.adobe.granite.ui.components.ds.DataSource;
import com.adobe.granite.ui.components.ds.SimpleDataSource;
import com.adobe.granite.ui.components.ds.ValueMapResource;
import com.day.cq.commons.jcr.JcrConstants;
import com.tgfoundation.core.models.GenericListItem;
import com.tgfoundation.core.models.GenericListModel;
import org.apache.commons.collections4.iterators.TransformIterator;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceMetadata;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.apache.sling.api.wrappers.ValueMapDecorator;
import org.apache.sling.servlets.annotations.SlingServletPaths;
import org.osgi.service.component.annotations.Component;
import java.util.ArrayList;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.Marker;
import javax.servlet.Servlet;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;

@Component(service = { Servlet.class })
@SlingServletPaths("/bin/foundation/generic-list/datasource")
public class GenericListDatasource extends SlingAllMethodsServlet {
    private static Logger log = LoggerFactory.getLogger(GenericListDatasource.class);
    private static Marker marker;

    @Override
    protected void doGet( SlingHttpServletRequest request, SlingHttpServletResponse response ) throws IOException {
        //This is used when calling this as a servlet
        String listPath = request.getParameter("path");

        if( listPath == null || listPath.isEmpty() ) {
           ResourceResolver resolver = request.getResourceResolver();

           String resourcePath = request.getRequestPathInfo().getResourcePath();
           Resource options = resolver.getResource( resourcePath );
           if( options != null ) {
               //this is used when it is a Form Options datasource
               listPath = options.getValueMap().get("datasourcePath", String.class);
           }

           Resource datasource = resolver.getResource( resourcePath + "/datasource" );
           if( datasource != null ) {
               //this is used when it is an xml datasource for dialogs
               ValueMap dsProperties = datasource.getValueMap();
               listPath = dsProperties.get("path", String.class );
           }
        }

        if( listPath == null || listPath.isEmpty() ) {
            response.setStatus(SlingHttpServletResponse.SC_BAD_REQUEST);
            response.getWriter().write("Parameter 'path' is required.");
            log.debug("Found no generic list path");
            
        }

        ResourceResolver resourceResolver = request.getResourceResolver();
        Resource resource = resourceResolver.getResource( listPath  );

        if( resource == null ) {
            response.setStatus(SlingHttpServletResponse.SC_NOT_FOUND);
            response.getWriter().write("Resource not found at the provided path.");
            log.debug("Found no resource in path {}", listPath);
            
        }

        List<GenericListItem> listItems = new ArrayList<>();

        if(resource != null){
            GenericListModel genericListModel = resource.adaptTo( GenericListModel.class );
             listItems = genericListModel.getItems();

            if( listItems == null ) {
                response.setStatus(SlingHttpServletResponse.SC_NOT_FOUND);
                response.getWriter().write("This is not a valid generic list content fragment");
                log.debug("Found invalid resource in path {}", listPath);   
            }
        }
        
        @SuppressWarnings("unchecked")
        DataSource ds = new SimpleDataSource(new TransformIterator(listItems.iterator(), input -> {
            GenericListItem item = (GenericListItem) input;
            ValueMap vm = new ValueMapDecorator(new HashMap<>());
            vm.put("value", item.getValue());
            vm.put("text", item.getTitle());
            return new ValueMapResource(resourceResolver, new ResourceMetadata(), JcrConstants.NT_UNSTRUCTURED, vm);
        }));
        request.setAttribute(DataSource.class.getName(), ds);
    }
}
