package com.tgfoundation.core.servlets.stylesystem;

import com.adobe.granite.ui.clientlibs.ClientLibrary;
import com.adobe.granite.ui.clientlibs.HtmlLibraryManager;
import com.adobe.granite.ui.components.ds.DataSource;
import com.adobe.granite.ui.components.ds.SimpleDataSource;
import com.adobe.granite.ui.components.ds.ValueMapResource;
import com.day.cq.commons.jcr.JcrConstants;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.tgfoundation.core.models.GenericListItem;
import com.tgfoundation.core.models.StyleShortcut;
import com.tgfoundation.core.models.StyleShortcutGroup;
import com.tgfoundation.core.models.StyleSystem;
import org.apache.commons.collections4.iterators.TransformIterator;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceMetadata;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.apache.sling.api.wrappers.ValueMapDecorator;
import org.apache.sling.servlets.annotations.SlingServletPaths;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.Marker;

import javax.jcr.Node;
import javax.jcr.RepositoryException;
import javax.servlet.Servlet;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Component(service = { Servlet.class })
@SlingServletPaths("/bin/style-system/branding")
public class BrandingDatasource extends SlingAllMethodsServlet {
    private static Logger log = LoggerFactory.getLogger(BrandingDatasource.class);
    private static Marker marker;

    /** The Library Manager. */
    @Reference
    private transient HtmlLibraryManager htmlLibraryManager;

    @Override
    protected void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response) throws IOException {
        try {
            ResourceResolver resourceResolver = request.getResourceResolver();

            Map<String, ClientLibrary> clientLibraries = htmlLibraryManager.getLibraries()
                    .entrySet()
                    .stream()
                    .filter( map -> Arrays.stream(map.getValue().getCategories()).collect(Collectors.joining()).endsWith("branding") && !Arrays.stream(map.getValue().getCategories()).collect(Collectors.joining()).endsWith("master.branding"))
                    .collect(Collectors.toMap(p -> p.getKey(), p -> p.getValue()));

            @SuppressWarnings("unchecked")
            DataSource ds = new SimpleDataSource(new TransformIterator(clientLibraries.entrySet().iterator(), input -> {
                ValueMap vm = new ValueMapDecorator(new HashMap<>());
                ClientLibrary clientLibrary = (ClientLibrary)((Map.Entry)input).getValue();
                String value = Arrays.stream(clientLibrary.getCategories()).collect(Collectors.joining());

                String key = ((Map.Entry) input).getKey().toString();
                Resource resource = request.getResourceResolver().getResource( key );
                String name = value;
                if( resource != null ) {
                    name = resource.getValueMap().get("title", String.class);
                }

                if( name == null ) {
                    name = value;
                }

                vm.put("value", value);
                vm.put("text", name);
                return new ValueMapResource(resourceResolver, new ResourceMetadata(), JcrConstants.NT_UNSTRUCTURED, vm);
            }));

            request.setAttribute(DataSource.class.getName(), ds);

        } catch (RuntimeException e) {
            log.error(marker, "Servlet Error - RuntimeException: {}", e.getMessage());
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
        }
    }
}
