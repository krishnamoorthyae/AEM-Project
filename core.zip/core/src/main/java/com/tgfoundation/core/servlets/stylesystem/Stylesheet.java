package com.tgfoundation.core.servlets.stylesystem;

import com.day.cq.commons.jcr.JcrConstants;
import com.day.cq.search.PredicateGroup;
import com.day.cq.search.Query;
import com.day.cq.search.QueryBuilder;
import com.day.cq.search.result.Hit;
import com.day.cq.search.result.SearchResult;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.tgfoundation.core.models.GenericListItem;
import com.tgfoundation.core.models.StyleShortcut;
import com.tgfoundation.core.models.StyleShortcutGroup;
import com.tgfoundation.core.models.StyleSystem;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.apache.sling.servlets.annotations.SlingServletPaths;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.Marker;

import javax.jcr.Node;
import javax.jcr.NodeIterator;
import javax.jcr.RepositoryException;
import javax.jcr.Session;
import javax.servlet.Servlet;
import java.io.IOException;
import java.util.*;

@Component(service = { Servlet.class })
@SlingServletPaths("/bin/foundation/stylesheet")
public class Stylesheet extends SlingAllMethodsServlet {
    private static Logger log = LoggerFactory.getLogger(Stylesheet.class);
    private static Marker marker;

    @Reference
    private QueryBuilder queryBuilder;

    @Override
    protected void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response) throws IOException {
        String resourcePath = request.getParameter( "path" );

        response.setContentType("text/css");

        if( resourcePath != null ) {
            String css = getAllPageCSSStyles( request.getResourceResolver(), resourcePath );
            response.getWriter().write( css );
        }
        else {
            response.getWriter().write("");
        }
    }

    public String getAllPageCSSStyles(ResourceResolver resolver, String path) {
        String cssText = "";

        try {
            cssText = getShortcutStyles( resolver, path );
            cssText += getBuildingBlockStyles( resolver, path );
        }
        catch (RepositoryException E) {
            log.error(marker, "Repository Exception Error: {}", E.getMessage());
            return "";
        }

        return cssText;
    }

    private String getBuildingBlockStyles(ResourceResolver resolver, String path) throws RepositoryException {
        StringBuilder cssText = new StringBuilder();

        List<Hit> hits = getStyleHits(resolver, path, "buildingBlocks");
        List<Hit> xfHits = getExperienceFragmentShortcuts( resolver, path, "buildingBlocks" );

        hits.addAll( xfHits );

        for( Hit hit : hits ) {
            Resource resource = hit.getResource();
            ValueMap valueMap = resource.getValueMap();

            String styleBuildingBlock = valueMap.get("buildingBlocks", String.class);

            if( styleBuildingBlock == null ) continue;

            cssText.append( styleBuildingBlock.trim() ).append("\n\r");
        }

        return cssText.toString();
    }

    private String getShortcutStyles(ResourceResolver resolver, String path) throws RepositoryException {
        Set<String> visited = new HashSet<>();
        StringBuilder cssText = new StringBuilder();

        List<Hit> hits = getStyleHits(resolver, path, "shortcutStyles");
        List<Hit> xfHits = getExperienceFragmentShortcuts( resolver, path, "shortcutStyles" );

        hits.addAll( xfHits );

        for( Hit hit : hits ) {
            Resource resource = hit.getResource();
            ValueMap valueMap = resource.getValueMap();

            String componentShortcut = valueMap.get("shortcutStyles", String.class);

            if( componentShortcut == null ) continue;

            for( String style : componentShortcut.split("\n\r") ) {
                if( !visited.contains( style.trim() ) ) {
                    visited.add( style.trim() );

                    cssText.append( style.trim() ).append("\n\r");
                }
            }
        }

        return cssText.toString();
    }

    private List<Hit> getExperienceFragmentShortcuts( ResourceResolver resolver, String path, String style ) throws RepositoryException {
        List<Hit> allHits = new ArrayList<>();

        List<Hit> xfHits = getStyleHits(resolver, path, "fragmentVariationPath");
        List<Hit> xfHits2 = getStyleHits(resolver, path, "fragmentPath");
        List<Hit> xfHits3 = getStyleHits(resolver, path, "defaultFragmentPath");

        xfHits.addAll(xfHits2);
        xfHits.addAll(xfHits3);

        for( Hit hit : xfHits ) {
            Resource resource = hit.getResource();
            ValueMap valueMap = resource.getValueMap();
            String searchPath = "";

            if( valueMap.get("fragmentVariationPath") != null ) {
                searchPath = valueMap.get("fragmentVariationPath", String.class);
            }
            else if( valueMap.get("fragmentPath") != null ) {
                searchPath = valueMap.get("fragmentPath", String.class);
            }
            else if( valueMap.get("defaultFragmentPath") != null ) {
                searchPath = valueMap.get("defaultFragmentPath", String.class);
            }

            if( searchPath == null ) continue;

            List<Hit> styleHits = getStyleHits(resolver, searchPath, style);
            List<Hit> xfLoop = getExperienceFragmentShortcuts( resolver, searchPath, style );

            allHits.addAll( styleHits );
            allHits.addAll( xfLoop );
        }

        return allHits;
    }

    private List<Hit> getStyleHits( ResourceResolver resolver, String path, String property ) {
        Map<String, String> predicateMap = new HashMap<>();
        predicateMap.put("path", path);
        predicateMap.put("type", JcrConstants.NT_UNSTRUCTURED);
        predicateMap.put("property", property);
        predicateMap.put("property.operation", "exists");
        predicateMap.put("p.limit", String.valueOf( 10 ) );
        predicateMap.put("p.offset", "0" );

        Session session = resolver.adaptTo(Session.class);
        Query defaultQuery = queryBuilder.createQuery( PredicateGroup.create(predicateMap), session );
        SearchResult searchResult = defaultQuery.getResult();

        List<Hit> hits = new ArrayList<>( searchResult.getHits() );

        for(int i = 10; i < searchResult.getTotalMatches(); i = i + 10 ) {
            predicateMap.put("p.offset", String.valueOf( i ) );
            Query query = queryBuilder.createQuery( PredicateGroup.create(predicateMap), session );
            SearchResult result = query.getResult();

            hits.addAll( result.getHits() );
        }

        return hits;
    }
}
