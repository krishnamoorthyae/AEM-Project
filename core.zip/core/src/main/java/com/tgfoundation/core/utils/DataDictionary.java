package com.tgfoundation.core.utils;

import com.day.cq.search.QueryBuilder;
import com.day.cq.search.result.Hit;
import com.day.cq.tagging.TagConstants;
import com.tgfoundation.core.models.GenericListItem;
import com.tgfoundation.core.models.GenericListModel;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;

import javax.jcr.RepositoryException;
import javax.servlet.http.Cookie;
import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

public class DataDictionary {
    private final QueryBuilder queryBuilder;

    public DataDictionary( QueryBuilder queryBuilder ) {
        this.queryBuilder = queryBuilder;
    }

    public void getDataDictionary( SlingHttpServletRequest request ) {
        ResourceResolver resolver = request.getResource().getResourceResolver();

        String[] selectors = request.getRequestPathInfo().getSelectors();

        if( selectors.length == 0 ) {
            String selectorString = request.getParameter( "selectors" );

            if( selectorString == null ) {
                Cookie selectorCookie = request.getCookie("selectors");

                if( selectorCookie != null ) {
                    selectorString = selectorCookie.getValue();
                }
            }

            if( selectorString != null ) {
                selectors = selectorString.split("\\.");
            }
        }

        if( selectors.length > 0 ) {
            if( request.getAttribute("data-dictionary") == null ) {
                Map<String, String> dictionary = getDataDictionary( resolver, selectors );
                request.setAttribute("data-dictionary", dictionary);
            }
        }
    }

    private Map<String, String> getDataDictionary( ResourceResolver resolver, String[] selectors ) {
        ContentFragmentLookup lookup = new ContentFragmentLookup(queryBuilder);
        Map<String, String> dictionary = new HashMap<>();

        StringBuilder tagPath = new StringBuilder();
        tagPath.append( "/content/cq:tags/data-dictionary" );

        StringBuilder dictionaryPath = new StringBuilder();
        dictionaryPath.append( "/content/dam/data-dictionary/xf-mapping" );

        StringBuilder mvsPath = new StringBuilder();
        mvsPath.append( "/content/dam/data-dictionary/content-configuration" );

        for( String selector : selectors ) {
            tagPath.append("/");
            dictionaryPath.append("/");
            mvsPath.append("/");

            tagPath.append( selector );
            dictionaryPath.append( selector );
            mvsPath.append( selector );

            List<Hit> xf = lookup.lookupFragmentByTag(resolver, dictionaryPath.toString(), tagPath.toString());
            List<Hit> mvs = lookup.lookupFragmentByTag(resolver, mvsPath.toString(), tagPath.toString());

            Map<String, String> xfContent = generateDictionaryFromContentFragmentList(xf);
            Map<String, String> mvsContent = generateDictionaryFromContentFragmentList(mvs);

            if( xfContent != null ) {
                dictionary.putAll(xfContent);
            }

            if( mvsContent != null ) {
                dictionary.putAll(mvsContent);
            }
        }
        return dictionary;
    }

    private Map<String, String> generateDictionaryFromContentFragmentList( List<Hit> hits ) {
        try{
            if( hits != null && hits.isEmpty() ) return null;

            List<GenericListItem> masterList = new ArrayList<>();
            for( Hit hit : hits ) {
                Resource hitResource = hit.getResource();

                if( hitResource == null ) continue;

                GenericListModel genericList = hitResource.adaptTo( GenericListModel.class );

                if( genericList != null ) {
                    masterList.addAll( genericList.getItems() );
                }
            }

            if( masterList.isEmpty() ) return null;

            Map<String, String> dictionary = masterList.stream()
                    .collect(Collectors.toMap(
                            GenericListItem::getTitle,
                            GenericListItem::getValue,
                            (existing, replacement) -> existing
                    ));

            Map<String, String> addedHandlebars = new HashMap<>();
            Set<String> keys = dictionary.keySet();
            for( String key : keys ) {
                if( !key.contains(":") && !key.contains("/") ) {
                    addedHandlebars.put("{{" + key + "}}", dictionary.get( key ) );
                }
                else {
                    addedHandlebars.put(key, dictionary.get( key ) );
                }
            }

            //adding year to data-dictionary
            addedHandlebars.put("{{currentYear}}", Integer.toString( LocalDate.now().getYear() ) );

            return addedHandlebars;
        }
        catch (RepositoryException exception ) {
            return null;
        }
    }
}
