package com.tgfoundation.core.utils;

import com.tgfoundation.core.models.functionality.HttpUtilResponse;
import com.tgfoundation.core.models.functionality.impl.HttpUtilResponseImpl;
import com.tgfoundation.core.models.SecretsManager;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpDelete;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.util.EntityUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.osgi.service.cm.ConfigurationAdmin;
import org.osgi.service.cm.Configuration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.Marker;

import java.io.IOException;

import javax.servlet.http.Cookie;



public class HttpUtil {
    private static final String EMPTY = "";

	//Data members
    private static Logger log = LoggerFactory.getLogger(HttpUtil.class);

    private static Marker marker;
    
    public static final String API_KEY = "apikey";
    
    private static final String HOST = "host";

	private String hostUrl;
    
    private String apiKey = EMPTY;
    
    private String proxyPath;
    
    private String jwt = EMPTY;
    
    private String offerId = EMPTY;
    
    private ConfigurationAdmin configurationAdmin;

    private SecretsManager secretManager; 

    public HttpUtil(Configuration conf, String proxyName, SecretsManager secretsManager) {
        //set secretManager variable 
        this.secretManager = secretsManager;
        // check if host avalaible via Secret manager else get it directly from config file 
        String hostVar = conf.getProperties().get(HOST).toString();
        hostUrl = secretManager.getSecret(hostVar);
        if(hostUrl == null){
            hostUrl = (conf.getProperties().get(HOST).toString() != null) ? conf.getProperties().get(HOST).toString() : EMPTY;
        }
        // get api Key from Secret Manger 
        String apiKeyVar = conf.getProperties().get(API_KEY).toString();
        apiKey = (secretManager.getSecret(apiKeyVar) != null) ? secretManager.getSecret(apiKeyVar) : EMPTY ;
        //get proxy path from the config file 
        proxyPath = !EMPTY.equals(proxyName) ? conf.getProperties().get(proxyName).toString() : EMPTY;
	}
    
	//getters
    public String getJWT(){
        return this.jwt;
    }
    
    public String getProxyPath(){
        return this.proxyPath;
    }
    
    public String getOfferID(){
        return this.offerId;
    }

    //setters
    public void setJWT(String jwt){
        this.jwt = jwt;
    }
    
    public void setProxyPath(String proxyPath){
        this.proxyPath = proxyPath;
    }

    public void setOfferID(String offerId){
        this.offerId = offerId;
    }

    public void setConfigAdmin (ConfigurationAdmin configAdmin){
        this.configurationAdmin = configAdmin; 
    }

    /**
    * Executes a HttpURI Request
    *
    * @param  request  an HttpUriRequest
    * @return      Http Response Object
    */
    private HttpUtilResponse execute(HttpUriRequest request) {
        try {
            HttpUtilResponse utilResponse = new HttpUtilResponseImpl();
 
            int timeout = 90;
 
            RequestConfig config = RequestConfig.custom()
                    .setConnectTimeout(timeout * 1000)
                    .setConnectionRequestTimeout(timeout * 1000)
                    .setSocketTimeout(timeout * 1000)
                    .build();
 
            CloseableHttpClient client = HttpClientBuilder.create()
                    .setDefaultRequestConfig(config)
                    .build();
 
            CloseableHttpResponse httpResponse = client.execute(request);
 
            utilResponse.setStatus(httpResponse.getStatusLine().getStatusCode());
 
            log.info(marker, "Status Code : {} ",  utilResponse.getStatus());
 
            if(httpResponse.getHeaders("X-TransactionId").length > 0 ){
                log.info(marker, "X-TransactionId : {} ", httpResponse.getHeaders("X-TransactionId")[0]);
            }

            /*******************************************************************
 
             ********** Replacing to allow for All Special Characters **********
 
             *******************************************************************/
 
            String responseBody = EntityUtils.toString(httpResponse.getEntity());
 
            utilResponse.setBody(responseBody);
 
            utilResponse.setResponse(httpResponse);
 
            return utilResponse;
        } 
        catch (RuntimeException e) {
            log.error(marker, "Execute Error - RuntimeException : {}", e.getMessage());

            return new HttpUtilResponseImpl();
        } 
        catch (ClientProtocolException e) {
            log.error(marker, "Execute Error - ClientProtocolException : {}", e.getMessage());
 
            return new HttpUtilResponseImpl();
        } 
        catch (IOException e) {
            log.error(marker, "Execute Error - IOException : {}", e.getMessage());
 
            return new HttpUtilResponseImpl();
        }
    }

    /**
    * Takes a JSON string representing the util request data and parses it to execute a POST http request
    *
    * @param  data  a JSON string object representing the POST request
    * @return      Http Response Object
    */
    public HttpUtilResponse executePost(String data) {
        HttpPost post = new HttpPost(hostUrl + proxyPath);

        log.info(marker, "Host Path : {} ", post);

        post.setHeader(API_KEY, apiKey);

        post.setHeader("Content-Type", "application/json");

        if (jwt != null && !jwt.isEmpty()) {
            post.setHeader("Authorization", "Bearer " + jwt);
        }

        if (offerId != null && !offerId.isEmpty()) {
            post.setHeader("offerId", offerId);
        }

        StringEntity jsonRequest = new StringEntity(data, "UTF-8");

        post.setEntity(jsonRequest);

        return execute(post);
    }

    /**
    * Execute a GET http request to the API 
    * @return      Http Response Object
    */
    public HttpUtilResponse executeGet() {
        HttpGet get = new HttpGet(hostUrl + proxyPath);
 
        log.info(marker, "Host Path : {} ", get);
 
        get.setHeader(API_KEY, apiKey);
 
        get.setHeader("Content-Type", "application/json");
 
        if (!jwt.isEmpty()) {
            get.setHeader("Authorization", "Bearer " + jwt);
        }
 
        return execute(get);
    }

    /**
    * Takes a JSON string representing the util response data and parses it to execute a PUT http request
    *
    * @param  data  a JSON string object representing the PUT request
    * @return      Http Response Object
    */
    public HttpUtilResponse executePut(String data) {
        HttpPut put = new HttpPut(hostUrl + proxyPath);
 
        log.info(marker, "Host Path : {} ", put);
 
        put.setHeader(API_KEY, apiKey);
 
        put.setHeader("Content-Type", "application/json");
 
        if (!jwt.isEmpty()) {
            put.setHeader("Authorization", "Bearer " + jwt);
        }
 
        StringEntity jsonRequest = new StringEntity(data, "UTF-8");
 
        put.setEntity(jsonRequest);
 
        return execute(put);
    }

    /**
    * Takes a JSON string representing the util response data and parses it to execute a DELETE http request
    *
    * @param  data  a JSON string object representing the DELETE request
    * @return      Http Response Object
    */
    public HttpUtilResponse executeDelete(String data) {
        HttpDelete delete = new HttpDelete(hostUrl + proxyPath);
 
        log.info(marker, "Host Path : {} ", delete);
 
        delete.setHeader(API_KEY, apiKey);
 
        delete.setHeader("Content-Type", "application/json");
 
        if (!jwt.isEmpty()) {
            delete.setHeader("Authorization", "Bearer " + jwt);
        }
 
        return execute(delete);
    }

    /**
     * Takes the request object and sets the jwt token based on the request parameter
     * 
     * @param request a SlingHttpServletRequest object to extract jwt request parameter
     * @return void
     */
    public void setJWT(SlingHttpServletRequest request){
    	String jwtParam = request.getParameter("jwt");
        
    	if(jwtParam == null) {
            jwt = EMPTY;
        }
        else if(jwtParam.startsWith("__Secure-")){
            jwt = getCookieJwt(request, jwtParam);
        }
        else if(!jwtParam.isEmpty()){
            jwt = guestToken(jwtParam);
        }
        else {
            jwt = EMPTY;
        }
    }
    
	/**
	 * Takes the request object and tries to retrieve the jwt token from the cookie
	 * 
	 * @param request a SlingHttpServletRequest object
	 * @param jwtParam a String object
	 * @return the jwt token from the cookie or an empty string
	 */
	private String getCookieJwt(SlingHttpServletRequest request, String jwtParam) {
		Cookie jwtCookie = request.getCookie(jwtParam);
        return (jwtCookie != null) ? jwtCookie.getValue() : EMPTY; 
    }
	
	/**
	 * Takes the jwtparam object and tries to generate a token with guest credentials
	 * 
	 * @param jwtParam a String object 
	 * @return guest token or an empty string
	 */
	private String guestToken(String jwtParam) {
		try {
            Configuration appCredentials = configurationAdmin.getConfiguration("com.travelguard.appCredentials");
            String loginRequest = (secretManager.getSecret(jwtParam) != null) ? secretManager.getSecret(jwtParam) : EMPTY;
            HttpUtil httpUtil = new HttpUtil(appCredentials, "jwt", secretManager);
            HttpUtilResponse loginResponse = httpUtil.executePost(loginRequest);
            
            if (loginResponse.getStatus() != 200) {
                return EMPTY;
            }
            
            return loginResponse.getBody();
        } catch (IOException e) {
            return EMPTY;
        }
	}

    public void setSlingResponseHeaders(SlingHttpServletResponse response, HttpUtilResponse utilresponse){
        if (utilresponse.getResponse().getHeaders("X-TransactionId").length > 0) {
            response.setHeader("X-TransactionId", (utilresponse.getResponse().getHeaders("X-TransactionId")[0].toString()).split(":")[1].trim());
        }
    }
}
