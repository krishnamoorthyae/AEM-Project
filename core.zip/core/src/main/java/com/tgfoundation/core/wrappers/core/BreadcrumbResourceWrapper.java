package com.tgfoundation.core.wrappers.core;

import com.tgfoundation.core.utils.DataDictionarySwap;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceWrapper;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.api.wrappers.ValueMapDecorator;
import org.jetbrains.annotations.NotNull;

import java.util.HashMap;
import java.util.Map;

public class BreadcrumbResourceWrapper extends ResourceWrapper {

    private final Map<String, String> dictionary;

    public BreadcrumbResourceWrapper(@NotNull Resource resource, @NotNull Map<String, String> dictionary) {
        super(resource);
        this.dictionary = dictionary;
    }

    @Override
    public @NotNull ValueMap getValueMap() {
        ValueMap originalValueMap = super.getValueMap();

        HashMap<String, Object> overriddenMap = new HashMap<>( originalValueMap );

        DataDictionarySwap dataDictionarySwap = new DataDictionarySwap( dictionary, originalValueMap );

        dataDictionarySwap.updateValueMapSimple( overriddenMap, "id" );
        dataDictionarySwap.updateValueMapSimple( overriddenMap, "disableShadowing" );
        dataDictionarySwap.updateValueMapSimple( overriddenMap, "hideCurrent" );
        dataDictionarySwap.updateValueMapSimple( overriddenMap, "showHidden" );
        dataDictionarySwap.updateValueMapSimple( overriddenMap, "startLevel" );

        dataDictionarySwap.updateValueMapById( overriddenMap, "id" );
        dataDictionarySwap.updateValueMapById( overriddenMap, "disableShadowing" );
        dataDictionarySwap.updateValueMapById( overriddenMap, "hideCurrent" );
        dataDictionarySwap.updateValueMapById( overriddenMap, "showHidden" );
        dataDictionarySwap.updateValueMapById( overriddenMap, "startLevel" );

        return new ValueMapDecorator( overriddenMap );
    }
}
