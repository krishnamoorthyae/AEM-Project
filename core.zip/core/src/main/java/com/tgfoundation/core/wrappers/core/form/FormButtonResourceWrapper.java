package com.tgfoundation.core.wrappers.core.form;

import com.day.cq.commons.jcr.JcrConstants;
import com.tgfoundation.core.utils.DataDictionarySwap;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceWrapper;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.api.wrappers.ValueMapDecorator;
import org.jetbrains.annotations.NotNull;

import java.util.HashMap;
import java.util.Map;

public class FormButtonResourceWrapper extends ResourceWrapper {

    private final Map<String, String> dictionary;

    public FormButtonResourceWrapper(@NotNull Resource resource, @NotNull Map<String, String> dictionary) {
        super(resource);
        this.dictionary = dictionary;
    }

    @Override
    public @NotNull ValueMap getValueMap() {
        ValueMap originalValueMap = super.getValueMap();

        HashMap<String, Object> overriddenMap = new HashMap<>( originalValueMap );

        DataDictionarySwap dataDictionarySwap = new DataDictionarySwap( dictionary, originalValueMap );

        dataDictionarySwap.updateValueMapSimple( overriddenMap, "id" );
        dataDictionarySwap.updateValueMapSimple( overriddenMap, "name" );
        dataDictionarySwap.updateValueMapSimple( overriddenMap, "type" );
        dataDictionarySwap.updateValueMapSimple( overriddenMap, "value" );
        dataDictionarySwap.updateValueMapSimple( overriddenMap, JcrConstants.JCR_TITLE );

        dataDictionarySwap.updateValueMapById( overriddenMap, "id" );
        dataDictionarySwap.updateValueMapById( overriddenMap, "name" );
        dataDictionarySwap.updateValueMapById( overriddenMap, "type" );
        dataDictionarySwap.updateValueMapById( overriddenMap, "value" );
        dataDictionarySwap.updateValueMapById( overriddenMap, JcrConstants.JCR_TITLE );

        return new ValueMapDecorator( overriddenMap );
    }
}
