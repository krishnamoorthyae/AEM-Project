package com.tgfoundation.core.wrappers.custom;

import com.tgfoundation.core.utils.DataDictionarySwap;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceWrapper;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.api.wrappers.ValueMapDecorator;
import org.jetbrains.annotations.NotNull;

import java.util.HashMap;
import java.util.Map;

public class MultiSelectDropdownResourceWrapper extends ResourceWrapper {

    private final Map<String, String> dictionary;

    public MultiSelectDropdownResourceWrapper(@NotNull Resource resource, @NotNull Map<String, String> dictionary) {
        super(resource);
        this.dictionary = dictionary;
    }

    @Override
    public @NotNull ValueMap getValueMap() {
        ValueMap originalValueMap = super.getValueMap();

        HashMap<String, Object> overriddenMap = new HashMap<>( originalValueMap );

        DataDictionarySwap dataDictionarySwap = new DataDictionarySwap( dictionary, originalValueMap );

        dataDictionarySwap.updateValueMapSimple( overriddenMap, "id" );
        dataDictionarySwap.updateValueMapSimple( overriddenMap, "customErrorMessage" );
        dataDictionarySwap.updateValueMapSimple( overriddenMap, "elementName" );
        dataDictionarySwap.updateValueMapSimple( overriddenMap, "errorCheck" );
        dataDictionarySwap.updateValueMapSimple( overriddenMap, "helpMessage" );
        dataDictionarySwap.updateValueMapSimple( overriddenMap, "label" );
        dataDictionarySwap.updateValueMapSimple( overriddenMap, "maxSelections" );
        dataDictionarySwap.updateValueMapSimple( overriddenMap, "multiSelectGenericList" );
        dataDictionarySwap.updateValueMapSimple( overriddenMap, "required" );
        dataDictionarySwap.updateValueMapSimple( overriddenMap, "requiredMessage" );
        dataDictionarySwap.updateValueMapSimple( overriddenMap, "uniqueId" );

        dataDictionarySwap.updateValueMapById( overriddenMap, "id" );
        dataDictionarySwap.updateValueMapById( overriddenMap, "customErrorMessage" );
        dataDictionarySwap.updateValueMapById( overriddenMap, "elementName" );
        dataDictionarySwap.updateValueMapById( overriddenMap, "errorCheck" );
        dataDictionarySwap.updateValueMapById( overriddenMap, "helpMessage" );
        dataDictionarySwap.updateValueMapById( overriddenMap, "label" );
        dataDictionarySwap.updateValueMapById( overriddenMap, "maxSelections" );
        dataDictionarySwap.updateValueMapById( overriddenMap, "multiSelectGenericList" );
        dataDictionarySwap.updateValueMapById( overriddenMap, "required" );
        dataDictionarySwap.updateValueMapById( overriddenMap, "requiredMessage" );
        dataDictionarySwap.updateValueMapById( overriddenMap, "uniqueId" );

        return new ValueMapDecorator( overriddenMap );
    }
}
