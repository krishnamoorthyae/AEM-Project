package com.tgfoundation.core.models.impl;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.List;
import org.apache.sling.api.wrappers.ValueMapDecorator;
import org.apache.sling.api.resource.Resource;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import com.day.cq.wcm.api.Page;
import com.google.common.collect.ImmutableMap;
import com.tgfoundation.core.models.GenericListItem;

import io.wcm.testing.mock.aem.junit5.AemContext;
import io.wcm.testing.mock.aem.junit5.AemContextExtension;

@ExtendWith({ AemContextExtension.class, MockitoExtension.class })
class GenericListItemImplTest {

	private final AemContext ctx = new AemContext();
	private GenericListItem genericListItem;

	@BeforeEach
	void setUp() throws Exception {
		ctx.addModelsForClasses(ModalPopupimpl.class);
		ctx.load().json("/com/tgfoundation/core/models/impl/GenericListItem.json", "/content");       
	    
	}

	@Test
	void testInit() {

		// fail("Not yet implemented");
	}

	@Test
	void testSetValue() {

		// assertNotNull(modalpopup.getModalPopupElements());
		// fail("Not yet implemented");
	}

	@Test
	void testSetTitle() {
		// fail("Not yet implemented");
	}

	@Test
	void testGetValue() {
		ctx.currentResource("/content");
		genericListItem = ctx.request().adaptTo(GenericListItem.class);
	//	assertEquals("sharethis", genericListItem.getValue());

	}

	@Test
	void testGetTitle() {
		
		  ctx.currentResource("/content");
		  genericListItem = ctx.request().adaptTo(GenericListItem.class); 
		//  assertEquals("ShareThis", genericListItem.getTitle());
		 
		
		/*
		 * Resource myPage = ctx.create().resource("/content", new
		 * ValueMapDecorator(ImmutableMap.<String, Object> of( "value", "sharethis",
		 * "title", "ShareThis"))); genericListItem =
		 * myPage.adaptTo(GenericListItem.class); assertEquals("enhello",
		 * genericListItem.getTitle());
		 */

	}

}
