package com.tgfoundation.core.models.impl;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.fail;

import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import com.tgfoundation.core.models.GenericListModel;

import io.wcm.testing.mock.aem.junit5.AemContext;
import io.wcm.testing.mock.aem.junit5.AemContextExtension;
@ExtendWith({AemContextExtension.class, MockitoExtension.class})
class GenericListModelImplTest {

	 private final AemContext ctx = new AemContext();
	    private GenericListModel genericlistmodel;
	    
	@BeforeEach
	void setUp() throws Exception {
		ctx.addModelsForClasses(GenericListItemImpl.class);
     ctx.load().json("/com/tgfoundation/core/models/impl/GenericListModel.json", "/content");
 	
	}
	
	@Test
	void testInit() {
	//	fail("Not yet implemented");
	}

	@Test
	void testGetItems() {
		ctx.currentResource("/content");
		genericlistmodel=ctx.request().adaptTo(GenericListModel.class);
		assertNotNull(genericlistmodel.getItems());
	//	assertEquals("1",genericlistmodel.getItems().get(0));
		
//	        assertEquals(4,genericlistmodel.getItems().size());
	        
	      
	}

}
