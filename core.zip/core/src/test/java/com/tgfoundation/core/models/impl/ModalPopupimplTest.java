package com.tgfoundation.core.models.impl;


import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.apache.sling.api.resource.ValueMap;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import com.tgfoundation.core.models.ModalPopup;

import io.wcm.testing.mock.aem.junit5.AemContext;
import io.wcm.testing.mock.aem.junit5.AemContextExtension;
@ExtendWith({AemContextExtension.class, MockitoExtension.class})
class ModalPopupimplTest {

	 private final AemContext ctx = new AemContext();
	    private ModalPopup modalpopup;
	    
	@BeforeEach
	void setUp() throws Exception {
		ctx.addModelsForClasses(ModalPopupimpl.class);
        ctx.load().json("/com/tgfoundation/core/models/impl/ModalPopup.json", "/content");
    	
	}

	@Test
	void testGetModalPopupElements() {
		ctx.currentResource("/content/modalpopup");
		modalpopup = ctx.request().adaptTo(ModalPopup.class);
		assertNotNull(modalpopup.getModalPopupElements());


/*
		assertEquals(4, modalpopup.getModalPopupElements().size());
		assertEquals("success-popup", modalpopup.getModalPopupElements().get(0).get("modalId"));
		assertEquals("true", modalpopup.getModalPopupElements().get(0).get("enableShortcutKeys"));
		assertEquals("true", modalpopup.getModalPopupElements().get(0).get("shortcutKeys"));
*/		 
        
	}

}
