package com.tgfoundation.core.servlets;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;

import org.apache.sling.testing.mock.sling.servlet.MockSlingHttpServletRequest;
import org.apache.sling.testing.mock.sling.servlet.MockSlingHttpServletResponse;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import io.wcm.testing.mock.aem.junit5.AemContext;
import io.wcm.testing.mock.aem.junit5.AemContextExtension;

@ExtendWith(AemContextExtension.class)
class GenericListTest {

	AemContext context = new AemContext();
	private GenericList genericList = new GenericList();

	@Test
	void doGet() throws IOException {
		context.build().resource("/content/genericList", "jcr:title", "media-query").commit();
		context.currentResource("/content/genericList");
	//	context.load().json("/genericList.json", "/content/dam/generic-lists/config/style-system/media-query/default");
		MockSlingHttpServletRequest request = context.request();
		MockSlingHttpServletResponse response = context.response();

		genericList.doGet(request, response);
		assertEquals("Parameter 'list' is required.", response.getOutputAsString());

	}

}
